import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import AutoImport from 'unplugin-auto-import/vite'
import Components from 'unplugin-vue-components/vite'
import { ElementPlusResolver } from 'unplugin-vue-components/resolvers'

// https://vitejs.dev/config/
export default defineConfig({
  base: './',
  plugins: [vue(), AutoImport({
    resolvers: [ElementPlusResolver()],
    imports: ['vue'],
    dts: 'src/auto-import.d.ts'
  }),
  Components({
    dirs: ['src'],
    resolvers: [ElementPlusResolver()],
    extensions: ['vue'],
    // 配置文件生成位置
    dts: 'src/components.d.ts',
  })],
  css: {
    postcss: {
      plugins: [
        {
          postcssPlugin: 'internal:charset-removal',
          AtRule: {
            charset: (atRule) => {
              if (atRule.name === 'charset') {
                atRule.remove();
              }
            }
          }
        }
      ],
    },
  },
  build: {
    chunkSizeWarningLimit: 1000
  },
  server: {
    port: 8080,
    host: '0.0.0.0',
    proxy: {
      '/api': {
        target: 'http://116.63.132.34:3000',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, '')
      }
    }
  }
})


