<script setup lang="ts">
import index from './components/index.vue'
import menuTop from './components/menu.vue'
import advertise from './components/advertise.vue'
import toTop from './components/toTop.vue'
import ToTop from './components/toTop.vue'
</script>

<template>
  <menu-top></menu-top>
  <index></index>
  <advertise></advertise>
  <to-top :visibility-height="46" class="circle" :back-position="0" transition-name="fade"></to-top>
</template>

<style></style>
