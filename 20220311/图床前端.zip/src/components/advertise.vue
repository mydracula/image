<template>
  <div id="highlights">
    <div class="inner">
      <div class="point">
        <h2>易用</h2>
        <p>已经会了 HTML、CSS、JavaScript？即刻阅读指南开始构建应用！</p>
      </div>

      <div class="point">
        <h2>灵活</h2>
        <p>不断繁荣的生态系统，可以在一个库和一套完整框架之间自如伸缩。</p>
      </div>

      <div class="point">
        <h2>高效</h2>
        <p>
          20kB min+gzip 运行大小<br />
          超快虚拟 DOM <br />
          最省心的优化
        </p>
      </div>
    </div>
  </div>

  <footer id="footer" role="contentinfo">
    <p>
      遵循 <a href="#" rel="noopener">MIT 开源协议</a><br />
      Copyright © 2014-2022 Moon
    </p>
  </footer>
</template>

<style scoped>
#highlights {
  background-color: #fff;
  padding-bottom: 70px;
}

#highlights .inner {
  max-width: 900px;
  margin: 0 auto;
  text-align: center;
}
#highlights .point {
  width: 33%;
  display: inline-block;
  vertical-align: top;
  box-sizing: border-box;
  padding: 0 2em;
}

#highlights .point h2 {
  color: #42b983;
  font-size: 1.5em;
  font-weight: 400;
  margin: 0;
  padding: 0.5em 0;
}

#highlights .point p {
  color: #4f5959;
}
p {
  word-spacing: 0.05em;
}

#footer {
  box-sizing: border-box;
  padding: 40px 0;
  background: #475050;
  color: #fff;
  text-align: center;
  width: 100%;
  height: 132px;
  position: absolute;
  bottom: 0;
  width: 100%;
}

#footer a {
  font-weight: 700;
  color: #fff;
}
</style>
