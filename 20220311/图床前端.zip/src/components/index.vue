<template>
  <el-upload ref="uploadRef" class="upload-demo" :http-request="upload" :limit="4" :on-exceed="handleExceed" :before-upload="beforeAvatarUpload" drag multiple :action="url">
    <icon name="uploadFilled" :size="80"></icon>
    <div class="el-upload__text">Drop file here or cv or <em>click to upload</em></div>
  </el-upload>

  <div class="list">
    <el-tabs type="card" v-model="activeName" class="demo-tabs">
      <el-tab-pane label="JsDelivr" name="JsDelivr">
        <ul>
          <li class="code" @click="copy(i)" v-for="i in uploadList" :key="i.name">
            <div
              class="status"
              :class="{
                blue: i.isSuccess === 0,
                green: i.isSuccess === 1,
                red: i.isSuccess === 2
              }"
            ></div>
            <span>{{ i.name }}</span>
            <el-progress :percentage="i.percent" v-if="i.isSuccess !== 1" />
            <div v-if="i.isSuccess == 1">{{ i.url }}</div>
          </li>
        </ul>
      </el-tab-pane>
    </el-tabs>
  </div>

  <el-dialog v-model="dialogVisible" title="提示:" width="30%" draggable>
    <span>检测到了您粘贴了图片是否上传?</span>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button @click="submit">确定</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { ElMessage } from 'element-plus'
import type { UploadFile, UploadRawFile, UploadProgressEvent } from 'element-plus'
import axios from 'axios'

const url = ref<string>(import.meta.env.VITE_APP_BASEURL + '/github')
const uploadRef = ref()
const uploadList: any = ref([])
const file: any = ref(null)
const dialogVisible = ref(false)
const activeName = ref('JsDelivr')

const beforeAvatarUpload = (file: UploadRawFile): any => {
  return new Promise((resolve, reject) => {
    const back = ['exe']
    let sExtensionName = file.name.substring(file.name.lastIndexOf('.') + 1).toLowerCase()
    console.log(sExtensionName, 'sExtensionName')

    const isBlack = back.includes(sExtensionName)
    const isLt = file.size / 1024 / 1024 >= 15
    console.log(isBlack, 'isBlack')

    if (isBlack) {
      ElMessage({
        message: 'Not supported file format.',
        grouping: true,
        type: 'warning'
      })
      return reject(false)
    }
    if (isLt) {
      ElMessage({
        message: 'Restricted within 15m.',
        grouping: true,
        type: 'warning'
      })
      return reject(false)
    }

    return resolve(true)
  })
}

onMounted(() => {
  document.addEventListener('paste', function (event) {
    const items = (event.clipboardData || window.clipboardData).items
    file.value = null
    if (!items || items.length === 0) {
      return
    }

    if (dialogVisible.value) return

    for (let i = 0; i < items.length; i++) {
      if (items[i].type.indexOf('image') !== -1) {
        file.value = items[i].getAsFile()
        break
      }
    }

    if (!file) {
      ElMessage({
        message: 'Only support pictures.',
        grouping: true,
        type: 'warning'
      })
      return
    }

    dialogVisible.value = true
  })
})

const handleExceed = (files: File[], fileList: UploadFile[]) => {
  ElMessage.warning(`The limit is 4, you selected ${files.length} files this time, add up to ${files.length + fileList.length} totally`)
}

const copy = (i: any) => {
  if (i.isSuccess !== 1) return
  let OrderNumber = i.url
  let newInput = document.createElement('input')
  newInput.value = OrderNumber
  document.body.appendChild(newInput)
  newInput.select()
  document.execCommand('Copy')
  newInput.remove()
}

// type uploadData = {
//   name: string
//   size: number
//   percent: number
//   date: any
//   isSuccess: number //0上传中，1成功，2失败
//   url?: string
// }

const upload: any = (f: any) => {
  let formdata = new FormData()
  formdata.append('file', f.file)
  const index = uploadList.value.length

  uploadList.value.push({
    name: f.file.name,
    size: f.file.size,
    date: f.file.lastModified,
    percent: 0,
    isSuccess: 0
  })

  try {
    axios({
      url: url.value,
      method: 'post',
      data: formdata,
      headers: { 'Content-Type': 'multipart/form-data' },
      onUploadProgress: (progressEvent) => {
        uploadList.value[index].percent = (progressEvent.loaded / progressEvent.total) * 100
      }
    }).then((res) => {
      console.log(res.data, '==')

      if (res.data.code == '200') {
        uploadList.value[index].url = res.data.data
        uploadList.value[index].isSuccess = 1
      }
    })
  } catch (error) {
    uploadList.value[index].isSuccess = 2
  }
}

const submit = () => {
  const f = {
    file: toRaw(file.value)
  }

  upload(f)
  file.value = null
  dialogVisible.value = false
}
</script>

<style scoped>
.upload-demo {
  display: flex;
  max-width: 700px;
  margin: 113px auto 0 auto;
}

.upload-demo >>> .el-upload-list {
  display: none;
}
.upload-demo >>> .el-upload {
  width: 100%;
}
.upload-demo >>> .el-upload-dragger {
  height: 210px;
  padding: 30px 10px;
  width: 100%;
  border-radius: 10px;
}
.list {
  margin: 20px auto 0 auto;
  max-width: 700px;
  min-height: 320px;
}

ul {
  list-style-type: none;
  padding: 0;
}

.list .code {
  user-select: none;
  cursor: pointer;
  position: relative;
  margin-top: 0.5rem;
  padding: 1rem;
  border: 1px solid #dadada;
  background-color: #f7f7f7;
  font-size: 14px;
  color: #555;
  white-space: pre-wrap;
  word-break: break-all;
  word-wrap: break-word;
  border-radius: 0;
  font-family: Menlo, Monaco, Consolas, 'Courier New', monospace;
}
.list .code .status {
  right: 10px;
  top: 10px;
  position: absolute;
  display: inline-block;
  width: 6px;
  height: 6px;
  vertical-align: middle;
  border-radius: 50%;
}

.list .code .status.blue {
  border: 1px solid #1890ff;
  background-color: #1890ff;
}

.list .code .status.red {
  border: 1px solid #f56c6c;
  background-color: #f56c6c;
}
.list .code .status.green {
  border: 1px solid #67c23a;
  background-color: #67c23a;
}

.list .code .status.blue::after {
  order: 1px solid #1890ff;
}

.list .code .status.red::after {
  border: 1px solid #f56c6c;
}
.list .code .status.green::after {
  border: 1px solid #67c23a;
}

.list .code .status::after {
  position: absolute;
  top: -1px;
  left: -1px;
  width: 100%;
  height: 100%;
  border-radius: 50%;
  animation: antStatusProcessing 1.2s infinite ease-in-out;
  content: '';
}

@keyframes antStatusProcessing {
  0% {
    transform: scale(0.8);
    opacity: 0.5;
  }
  to {
    transform: scale(2.4);
    opacity: 0;
  }
}
</style>
