import { createApp } from 'vue'
import App from './App.vue'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import '/src/assets/index.css'
import icon from '../src/components/icon.vue'



createApp(App).component('icon', icon).use(ElementPlus).mount('#app')
