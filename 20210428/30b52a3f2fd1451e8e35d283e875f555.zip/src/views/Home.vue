<template>
  <div>2021年4月21日</div>
</template>

<script>
export default {}
</script>

<style scoped></style>
