import Vue from 'vue'
import App from './App.vue'
import router from './router'
import VCharts from 'v-charts'
import VideoPlayer from 'vue-video-player'

Vue.config.productionTip = false
Vue.use(VCharts)

Vue.use(VideoPlayer)

require('video.js/dist/video-js.css')
require('vue-video-player/src/custom-theme.css')
const hls = require('videojs-contrib-hls')
Vue.use(hls)

new Vue({
  router,
  render: h => h(App)
}).$mount('#app')
