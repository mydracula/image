---
title: Quruli
---

Quruli (くるり Kururi) is a Japanese music group formed in 1996. As of March 2018, the lineup consists of Shigeru Kishida, Masashi Sato, and Fanfan. Their music is produced and distributed by Victor Entertainment.

<link-to-wikipedia path="quruli" title="Quruli" />
