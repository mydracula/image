"${0%/*}"/Core/CuteBi start
#iptables -t mangle -I TUN_OUTPUT -m owner ! --uid 3003 -j ACCEPT