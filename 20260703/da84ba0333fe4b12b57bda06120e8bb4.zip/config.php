<?php
define('DB_HOST','127.0.0.1');define('DB_NAME','123456');define('DB_USER','123456');define('DB_PASS','123456');define('DB_CHARSET','utf8mb4');