<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

// 如果已经登录，跳转到首页
if (is_logged_in()) {
    header('Location: index.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $email = $_POST['email'] ?? '';
    
    // 验证
    if (strlen($username) < 3) {
        $error = '用户名至少需要3个字符';
    } elseif (strlen($password) < 6) {
        $error = '密码至少需要6个字符';
    } elseif ($password != $confirm_password) {
        $error = '两次输入的密码不一致';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) && !empty($email)) {
        $error = '邮箱格式不正确';
    } else {
        $result = register($username, $password, $email);
        
        if ($result === true) {
            $success = '注册成功！正在跳转...';
            header('refresh:2;url=index.php');
        } elseif ($result == 'username_exists') {
            $error = '用户名已存在';
        } elseif ($result == 'email_exists') {
            $error = '邮箱已被使用';
        } else {
            $error = '注册失败，请稍后重试';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>注册 - 静态网站托管平台</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-gray-50">
    <div class="min-h-screen flex items-center justify-center">
        <div class="bg-white p-8 rounded-lg shadow-md w-96">
            <h1 class="text-2xl font-bold text-center mb-6">注册账户</h1>
            <p class="text-center text-sm text-gray-600 mb-4">注册即送 <?php echo REGISTER_POINTS; ?> 积分</p>
            
            <?php if ($error): ?>
                <div class="bg-red-100 text-red-700 p-3 rounded mb-4 text-sm">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="bg-green-100 text-green-700 p-3 rounded mb-4 text-sm">
                    <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="mb-4">
                    <label class="block text-sm font-medium mb-2">用户名 <span class="text-red-500">*</span></label>
                    <input type="text" name="username" required minlength="3"
                           class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:border-primary">
                </div>
                
                <div class="mb-4">
                    <label class="block text-sm font-medium mb-2">邮箱</label>
                    <input type="email" name="email" 
                           class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:border-primary">
                </div>
                
                <div class="mb-4">
                    <label class="block text-sm font-medium mb-2">密码 <span class="text-red-500">*</span></label>
                    <input type="password" name="password" required minlength="6"
                           class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:border-primary">
                </div>
                
                <div class="mb-6">
                    <label class="block text-sm font-medium mb-2">确认密码 <span class="text-red-500">*</span></label>
                    <input type="password" name="confirm_password" required
                           class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:border-primary">
                </div>
                
                <button type="submit" 
                        class="w-full bg-primary text-white py-2 rounded hover:bg-primary/90 transition">
                    注册
                </button>
            </form>
            
            <div class="mt-4 text-center text-sm">
                <span class="text-gray-600">已有账户？</span>
                <a href="login.php" class="text-primary hover:underline">立即登录</a>
            </div>
            
            <div class="mt-6 text-center">
                <a href="index.php" class="text-sm text-gray-500 hover:underline">返回首页</a>
            </div>
        </div>
    </div>
</body>
</html>