<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

// 获取分页参数
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 15;
$offset = ($page - 1) * $per_page;

// 获取所有勾选展示的网站（按最新排序）
$all_sites = db_get_where('sites', ['is_showcase' => 1]);
// 按时间排序（最新在前）
usort($all_sites, function($a, $b) {
    return strtotime($b['created_at']) - strtotime($a['created_at']);
});
$total_sites = count($all_sites);
$total_pages = ceil($total_sites / $per_page);

// 获取当前页的网站
$sites = array_slice($all_sites, $offset, $per_page);

// 是否显示作品列表
$show_showcase = isset($_GET['showcase']) || isset($_POST['showcase']);
?>
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>静态网站托管平台 - 免费静态网站托管服务</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        /* 背景图片样式 */
        body {
            background-image: url('img/bj.png');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            background-repeat: no-repeat;
            position: relative;
        }
        
        /* 添加半透明遮罩层 */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(255, 255, 255, 0.85);
            z-index: -1;
        }
        
        /* 主要内容区域背景透明 */
        .min-h-screen {
            background: transparent !important;
        }
        
        /* 导航栏背景半透明 */
        nav.sticky {
            background: rgba(255, 255, 255, 0.95) !important;
            backdrop-filter: blur(8px);
        }
        
        /* 卡片半透明效果 */
        .showcase-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(4px);
        }
        
        .empty-showcase {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(4px);
        }
        
        /* 价格方案卡片 */
        #pricing .border {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(4px);
        }
        
        /* 分页样式 */
        .pagination a, .pagination span {
            background: rgba(255, 255, 255, 0.9);
        }
        
        /* Footer背景 */
        footer {
            background: rgba(255, 255, 255, 0.9) !important;
            backdrop-filter: blur(4px);
        }
        
        .user-avatar-link {
            cursor: pointer;
            transition: transform 0.2s;
        }
        .user-avatar-link:hover {
            transform: scale(1.1);
        }
        .pagination {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 30px;
        }
        .pagination a, .pagination span {
            padding: 8px 16px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            text-decoration: none;
            color: #4a5568;
            transition: all 0.2s;
        }
        .pagination a:hover {
            background: #3b82f6;
            color: white;
            border-color: #3b82f6;
        }
        .pagination .current {
            background: #3b82f6;
            color: white;
            border-color: #3b82f6;
        }
        .showcase-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 2px solid #e2e8f0;
        }
        .showcase-header h2 {
            font-size: 2rem;
            font-weight: 700;
            background: linear-gradient(135deg, #3b82f6, #8b5cf6);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        .view-toggle-btn {
            background: #3b82f6;
            color: white;
            padding: 8px 20px;
            border-radius: 30px;
            text-decoration: none;
            font-weight: 500;
            font-size: 14px;
            transition: all 0.2s;
            border: none;
            cursor: pointer;
        }
        .view-toggle-btn:hover {
            background: #2563eb;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }
        
        .btn-small {
            padding: 8px 24px !important;
            font-size: 14px !important;
        }
        
        .hero-buttons {
            display: flex;
            justify-content: center;
            gap: 12px;
        }
        
        .brand-text {
            font-size: 1.25rem;
            font-weight: 700;
            color: #3b82f6;
            text-decoration: none;
        }
        
        .brand-text:hover {
            text-decoration: underline;
        }

        .showcase-grid {
            display: grid;
            grid-template-columns: repeat(1, 1fr);
            gap: 24px;
            margin-bottom: 30px;
        }
        
        @media (min-width: 768px) {
            .showcase-grid {
                grid-template-columns: repeat(3, 1fr);
            }
        }
        
        @media (min-width: 1024px) {
            .showcase-grid {
                grid-template-columns: repeat(4, 1fr);
            }
        }
        
        .showcase-card {
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -1px rgba(0,0,0,0.06);
            transition: all 0.3s ease;
            border: 1px solid #e2e8f0;
            display: flex;
            flex-direction: column;
        }
        
        .showcase-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1), 0 10px 10px -5px rgba(0,0,0,0.04);
            border-color: #3b82f6;
        }
        
        .card-preview {
            height: 160px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }
        
        .card-preview::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.1);
            z-index: 1;
        }
        
        .preview-icon {
            font-size: 48px;
            z-index: 2;
            filter: drop-shadow(0 4px 6px rgba(0,0,0,0.1));
        }
        
        .card-content {
            padding: 16px;
            flex: 1;
        }
        
        .card-user {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 12px;
            padding-bottom: 12px;
            border-bottom: 1px solid #edf2f7;
        }
        
        .user-avatar-small {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid white;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        
        .user-info-small {
            display: flex;
            flex-direction: column;
        }
        
        .user-name-small {
            font-size: 13px;
            font-weight: 600;
            color: #2d3748;
        }
        
        .user-role-small {
            font-size: 11px;
            color: #718096;
        }
        
        .card-title {
            font-size: 16px;
            font-weight: 600;
            color: #1a202c;
            margin-bottom: 8px;
            line-height: 1.4;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        
        .card-description {
            font-size: 13px;
            color: #718096;
            margin-bottom: 16px;
            line-height: 1.5;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        
        .card-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 16px;
            background: #f7fafc;
            border-top: 1px solid #edf2f7;
        }
        
        .card-stats {
            display: flex;
            gap: 12px;
            font-size: 12px;
            color: #718096;
        }
        
        .card-stats span {
            display: flex;
            align-items: center;
            gap: 4px;
        }
        
        .card-link {
            background: #3b82f6;
            color: white;
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.2s;
        }
        
        .card-link:hover {
            background: #2563eb;
            transform: translateX(4px);
        }
        
        .empty-showcase {
            text-align: center;
            padding: 60px 20px;
            border-radius: 24px;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
        }
        
        .empty-icon {
            font-size: 64px;
            margin-bottom: 20px;
            opacity: 0.5;
        }
        
        .empty-title {
            font-size: 20px;
            font-weight: 600;
            color: #2d3748;
            margin-bottom: 8px;
        }
        
        .empty-desc {
            font-size: 14px;
            color: #718096;
        }
        
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        
        .loading {
            animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }
    </style>
</head>
<body>
    <div class="min-h-screen">
        <!-- 导航栏 -->
        <nav class="sticky top-0 z-50 w-full border-b">
            <div class="container mx-auto px-4">
                <div class="flex h-16 items-center justify-between">
                    <div class="w-32">
                        <?php if (!is_logged_in()): ?>
                            <a href="index.php" class="brand-text">静态网站托管</a>
                        <?php endif; ?>
                    </div>
                    
                    <div class="hidden md:flex items-center space-x-8">
                        <a href="index.php" class="text-sm font-medium text-foreground">首页</a>
                        <?php if ($show_showcase): ?>
                            <a href="index.php" class="text-sm font-medium text-muted-foreground hover:text-foreground">返回首页</a>
                        <?php endif; ?>
                    </div>
                    
                    <div class="flex items-center gap-4">
                        <?php if (is_logged_in()): ?>
                            <?php $user = get_logged_user(); ?>
                            <?php if ($user): ?>
                                <div class="flex items-center gap-3">
                                    <a href="dashboard.php" class="user-avatar-link">
                                        <img src="<?php echo $user['avatar'] ?: 'img/touxiang.png'; ?>" class="w-8 h-8 rounded-full" alt="avatar">
                                    </a>
                                    <span class="text-sm"><?php echo htmlspecialchars($user['username']); ?> (积分: <?php echo $user['points']; ?>)</span>
                                    <a href="dashboard.php" class="text-sm bg-primary text-white px-3 py-1 rounded">我的作品</a>
                                    <a href="logout.php" class="text-sm text-muted-foreground">退出</a>
                                </div>
                            <?php else: ?>
                                <a href="login.php" class="text-sm font-medium">登录</a>
                                <a href="register.php" class="text-sm bg-primary text-white px-4 py-2 rounded">注册</a>
                            <?php endif; ?>
                        <?php else: ?>
                            <a href="login.php" class="text-sm font-medium">登录</a>
                            <a href="register.php" class="text-sm bg-primary text-white px-4 py-2 rounded">注册</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </nav>

        <main class="container mx-auto px-4 py-8 space-y-16">
            <!-- Hero Section -->
            <section class="text-center py-8">
                <div class="max-w-4xl mx-auto">
                    <h1 class="text-4xl md:text-6xl font-bold mb-6 text-primary">让你的网页即刻上线</h1>
                    <p class="text-xl md:text-2xl text-muted-foreground mb-8">专业的静态网站托管服务，上传您的 HTML、CSS 和 JavaScript 文件，立即创建精美网站</p>
                    
                    <div class="hero-buttons">
                        <?php if (is_logged_in()): ?>
                            <a href="create.php" class="bg-primary text-white btn-small rounded-lg font-medium hover:bg-primary/90">
                                立即创建网站
                            </a>
                        <?php else: ?>
                            <a href="register.php" class="bg-primary text-white btn-small rounded-lg font-medium hover:bg-primary/90">
                                注册开始使用
                            </a>
                        <?php endif; ?>
                        
                        <form method="POST" style="display: inline;">
                            <button type="submit" name="showcase" value="1" class="border border-gray-300 btn-small rounded-lg font-medium hover:bg-gray-50">
                                查看他人的作品
                            </button>
                        </form>
                    </div>
                </div>
            </section>

            <!-- 精选作品 -->
            <?php if ($show_showcase): ?>
            <section id="showcase" class="scroll-mt-20">
                <div class="showcase-header">
                    <h2>他人作品</h2>
                    <a href="index.php" class="view-toggle-btn">← 返回首页</a>
                </div>
                
                <?php if (empty($sites)): ?>
                    <div class="empty-showcase">
                        <div class="empty-icon">📭</div>
                        <h3 class="empty-title">暂无作品</h3>
                        <p class="empty-desc">还没有人创建网站，快来成为第一个吧！</p>
                    </div>
                <?php else: ?>
                    <div class="showcase-grid">
                        <?php foreach ($sites as $site): 
                            $creator = db_get_one('users', ['id' => $site['user_id']]);
                            $avatar = !empty($creator['avatar']) ? $creator['avatar'] : 'img/touxiang.png';
                            $creator_name = $creator['username'] ?? '未知用户';
                            $creator_role = ($creator['role'] ?? 'user') == 'admin' ? '管理员' : '普通用户';
                            $file_count = count($site['files'] ?? []);
                            $views = $site['views'] ?? 0;
                        ?>
                            <div class="showcase-card">
                                <div class="card-preview">
                                    <span class="preview-icon">🌐</span>
                                </div>
                                <div class="card-content">
                                    <div class="card-user">
                                        <img src="<?php echo $avatar; ?>" class="user-avatar-small" alt="avatar" onerror="this.src='img/touxiang.png'">
                                        <div class="user-info-small">
                                            <span class="user-name-small"><?php echo htmlspecialchars($creator_name); ?></span>
                                            <span class="user-role-small"><?php echo $creator_role; ?></span>
                                        </div>
                                    </div>
                                    
                                    <h3 class="card-title"><?php echo htmlspecialchars($site['title']); ?></h3>
                                    
                                    <?php if (!empty($site['description'])): ?>
                                        <p class="card-description"><?php echo htmlspecialchars($site['description']); ?></p>
                                    <?php else: ?>
                                        <p class="card-description" style="color: #a0aec0;">暂无描述</p>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="card-footer">
                                    <div class="card-stats">
                                        <span title="文件数量">📁 <?php echo $file_count; ?></span>
                                        <span title="访问量">👁️ <?php echo $views; ?></span>
                                    </div>
                                    <a href="site.php?id=<?php echo $site['id']; ?>" class="card-link" target="_blank">
                                        查看TA的网站 →
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <?php if ($total_pages > 1): ?>
                    <div class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="?page=<?php echo $page-1; ?>&showcase=1">← 上一页</a>
                        <?php endif; ?>
                        
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <?php if ($i == $page): ?>
                                <span class="current"><?php echo $i; ?></span>
                            <?php else: ?>
                                <a href="?page=<?php echo $i; ?>&showcase=1"><?php echo $i; ?></a>
                            <?php endif; ?>
                        <?php endfor; ?>
                        
                        <?php if ($page < $total_pages): ?>
                            <a href="?page=<?php echo $page+1; ?>&showcase=1">下一页 →</a>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                <?php endif; ?>
            </section>
            <?php endif; ?>

            <!-- 价格方案 -->
            <?php if (!$show_showcase): ?>
            <section id="pricing" class="scroll-mt-20">
                <h2 class="text-3xl font-bold text-center mb-8">价格方案</h2>
                
                <div class="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
                    <div class="border rounded-lg p-6 text-center">
                        <h3 class="text-xl font-bold mb-2">免费体验</h3>
                        <p class="text-3xl font-bold text-primary mb-4">¥0</p>
                        <ul class="text-left space-y-2 mb-6">
                            <li>✓ 首次注册送 10 积分</li>
                            <li>✓ 每次创建消耗 10 积分</li>
                            <li>✓ 基础托管服务</li>
                            <li>✓ 默认域名</li>
                        </ul>
                        <?php if (is_logged_in()): ?>
                            <a href="create.php" class="block w-full bg-primary text-white py-2 rounded">立即使用</a>
                        <?php else: ?>
                            <a href="register.php" class="block w-full bg-primary text-white py-2 rounded">立即注册</a>
                        <?php endif; ?>
                    </div>
                    
                    <div class="border rounded-lg p-6 text-center border-primary shadow-lg relative">
                        <span class="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-primary text-white px-3 py-1 text-sm rounded-full">热门</span>
                        <h3 class="text-xl font-bold mb-2">基础套餐</h3>
                        <p class="text-3xl font-bold text-primary mb-4">¥10</p>
                        <ul class="text-left space-y-2 mb-6">
                            <li>✓ 100 积分</li>
                            <li>✓ 可创建 10 个网站</li>
                            <li>✓ 基础托管服务</li>
                            <li>✓ 默认域名</li>
                        </ul>
                        <?php if (is_logged_in()): ?>
                            <a href="dashboard.php#recharge" class="block w-full bg-primary text-white py-2 rounded">立即充值</a>
                        <?php else: ?>
                            <a href="login.php" class="block w-full bg-primary text-white py-2 rounded">立即购买</a>
                        <?php endif; ?>
                    </div>
                    
                    <div class="border rounded-lg p-6 text-center">
                        <h3 class="text-xl font-bold mb-2">高级套餐</h3>
                        <p class="text-3xl font-bold text-primary mb-4">¥50</p>
                        <ul class="text-left space-y-2 mb-6">
                            <li>✓ 600 积分</li>
                            <li>✓ 可创建 60 个网站</li>
                            <li>✓ 优先托管服务</li>
                            <li>✓ 默认域名</li>
                        </ul>
                        <?php if (is_logged_in()): ?>
                            <a href="dashboard.php#recharge" class="block w-full bg-primary text-white py-2 rounded">立即充值</a>
                        <?php else: ?>
                            <a href="login.php" class="block w-full bg-primary text-white py-2 rounded">立即购买</a>
                        <?php endif; ?>
                    </div>
                </div>
            </section>
            <?php endif; ?>
        </main>

        <!-- Footer -->
        <footer class="border-t py-8 mt-16">
            <div class="container mx-auto px-4 text-center text-sm text-gray-600">
                <p>© 2026 鸿盟创客-静态网站托管平台</p>
            </div>
        </footer>
    </div>
</body>
</html>