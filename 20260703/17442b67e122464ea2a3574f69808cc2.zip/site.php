<?php
require_once 'includes/config.php';
require_once 'includes/db.php';

$site_id = $_GET['id'] ?? '';

if (!$site_id) {
    header('HTTP/1.0 404 Not Found');
    die('网站不存在');
}

$site = db_get_one('sites', ['id' => $site_id]);

if (!$site || $site['status'] != 'active') {
    header('HTTP/1.0 404 Not Found');
    die('网站不存在或已被禁用');
}

// 更新访问量
db_update('sites', $site_id, ['views' => ($site['views'] ?? 0) + 1]);

// 查找 index.html
$site_path = UPLOAD_PATH . $site_id . '/';
$index_file = $site_path . 'index.html';

if (file_exists($index_file)) {
    // 读取并输出 HTML
    $content = file_get_contents($index_file);
    
    // 处理相对路径
    $base_url = '/data/uploads/' . $site_id . '/';
    $content = preg_replace('/(src|href)=(["\'])(?!https?:\/\/|\/\/)/', '$1=$2' . $base_url, $content);
    
    echo $content;
} else {
    // 显示文件列表
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title><?php echo htmlspecialchars($site['title']); ?></title>
        <meta charset="utf-8">
        <style>
            body { font-family: sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; }
            h1 { color: #333; }
            ul { list-style: none; padding: 0; }
            li { margin: 10px 0; }
            a { color: #0066cc; text-decoration: none; }
            a:hover { text-decoration: underline; }
            .file-icon { display: inline-block; width: 20px; text-align: center; margin-right: 8px; }
        </style>
    </head>
    <body>
        <h1><?php echo htmlspecialchars($site['title']); ?></h1>
        <p>网站文件列表：</p>
        
        <ul>
            <?php
            $files = scandir($site_path);
            $files = array_diff($files, ['.', '..']);
            
            foreach ($files as $file):
                $ext = pathinfo($file, PATHINFO_EXTENSION);
                $icon = '📄';
                if ($ext == 'html' || $ext == 'htm') $icon = '🌐';
                elseif ($ext == 'css') $icon = '🎨';
                elseif ($ext == 'js') $icon = '⚡';
                elseif ($ext == 'png' || $ext == 'jpg' || $ext == 'jpeg' || $ext == 'gif') $icon = '🖼️';
                elseif ($ext == 'pdf') $icon = '📑';
                elseif ($ext == 'zip') $icon = '📦';
            ?>
                <li>
                    <span class="file-icon"><?php echo $icon; ?></span>
                    <a href="/data/uploads/<?php echo $site_id; ?>/<?php echo $file; ?>" target="_blank">
                        <?php echo $file; ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
        
        <p style="margin-top: 30px; color: #666; font-size: 0.9em;">
            提示：如果您的网站有 index.html 文件，将自动显示首页。
        </p>
    </body>
    </html>
    <?php
}
?>