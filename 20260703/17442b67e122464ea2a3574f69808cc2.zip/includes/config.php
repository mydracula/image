<?php
// 配置文件
session_start();

// 获取当前脚本的目录路径
$script_dir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
if ($script_dir == '/' || $script_dir == '\\') {
    $script_dir = '';
}

// 站点配置 - 修复URL路径
define('SITE_URL', 'http://' . $_SERVER['HTTP_HOST'] . $script_dir);
define('SITE_PATH', $script_dir); // 添加站点路径常量，如 /web
define('UPLOAD_PATH', __DIR__ . '/../data/uploads/');
define('DATA_PATH', __DIR__ . '/../data/');

// 积分配置
define('REGISTER_POINTS', 10);
define('CREATE_COST', 10);

// 错误报告
error_reporting(E_ALL);
ini_set('display_errors', 1);

// 时区
date_default_timezone_set('Asia/Shanghai');

// 创建数据目录
if (!file_exists(DATA_PATH)) {
    mkdir(DATA_PATH, 0777, true);
}
if (!file_exists(UPLOAD_PATH)) {
    mkdir(UPLOAD_PATH, 0777, true);
}

// 初始化数据文件
$init_files = [
    'users.json' => '[]',
    'sites.json' => '[]',
    'orders.json' => '[]'
];

foreach ($init_files as $file => $content) {
    $file_path = DATA_PATH . $file;
    if (!file_exists($file_path)) {
        file_put_contents($file_path, $content);
    }
}
?>