<?php
/**
 * 检查是否登录
 */
function is_logged_in() {
    return get_logged_user() !== null;
}

/**
 * 获取当前登录用户，如果用户不存在则自动注销
 */
function get_logged_user() {
    static $user = null; // 静态缓存，避免重复查询
    
    if ($user !== null) {
        return $user;
    }
    
    if (!isset($_SESSION['user_id'])) {
        return null;
    }
    
    $user = db_get_one('users', ['id' => $_SESSION['user_id']]);
    
    if (!$user) {
        // 用户不存在，清理 session
        unset($_SESSION['user_id']);
        $user = null;
    }
    
    return $user;
}

/**
 * 检查是否为管理员
 */
function is_admin() {
    $user = get_logged_user();
    return $user && isset($user['role']) && $user['role'] == 'admin';
}

/**
 * 登录
 */
function login($username, $password) {
    $user = db_get_one('users', ['username' => $username]);
    
    if ($user && password_verify($password, $user['password'])) {
        if (isset($user['status']) && $user['status'] == 'banned') {
            return 'account_banned';
        }
        $_SESSION['user_id'] = $user['id'];
        return true;
    }
    
    return false;
}

/**
 * 注册
 */
function register($username, $password, $email = '') {
    // 检查用户是否存在
    $existing = db_get_one('users', ['username' => $username]);
    if ($existing) {
        return 'username_exists';
    }
    
    if ($email) {
        $existing_email = db_get_one('users', ['email' => $email]);
        if ($existing_email) {
            return 'email_exists';
        }
    }
    
    // 创建用户
    $user = [
        'username' => $username,
        'password' => password_hash($password, PASSWORD_DEFAULT),
        'email' => $email,
        'avatar' => 'img/touxiang.png',
        'points' => REGISTER_POINTS,
        'role' => 'user',
        'status' => 'active',
        'created_at' => date('Y-m-d H:i:s')
    ];
    
    $user_id = db_insert('users', $user);
    
    if ($user_id) {
        $_SESSION['user_id'] = $user_id;
        return true;
    }
    
    return false;
}

/**
 * 扣除积分
 */
function deduct_points($user_id, $points) {
    $user = db_get_one('users', ['id' => $user_id]);
    if (!$user || $user['points'] < $points) {
        return false;
    }
    
    $new_points = $user['points'] - $points;
    return db_update('users', $user_id, ['points' => $new_points]);
}

/**
 * 添加积分
 */
function add_points($user_id, $points) {
    $user = db_get_one('users', ['id' => $user_id]);
    if (!$user) {
        return false;
    }
    
    $new_points = $user['points'] + $points;
    return db_update('users', $user_id, ['points' => $new_points]);
}
?>