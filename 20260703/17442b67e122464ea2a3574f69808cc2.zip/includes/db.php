<?php
// 简单的 JSON 数据库操作

/**
 * 获取所有数据
 */
function db_get_all($table, $order_by = '', $limit = 0) {
    $data = json_decode(file_get_contents(DATA_PATH . $table . '.json'), true) ?: [];
    
    // 排序
    if ($order_by) {
        list($field, $direction) = explode(' ', $order_by);
        usort($data, function($a, $b) use ($field, $direction) {
            if ($direction == 'DESC') {
                return strtotime($b[$field] ?? 0) - strtotime($a[$field] ?? 0);
            }
            return strtotime($a[$field] ?? 0) - strtotime($b[$field] ?? 0);
        });
    }
    
    // 限制数量
    if ($limit > 0) {
        $data = array_slice($data, 0, $limit);
    }
    
    return $data;
}

/**
 * 根据条件获取数据
 */
function db_get_where($table, $conditions) {
    $data = json_decode(file_get_contents(DATA_PATH . $table . '.json'), true) ?: [];
    
    return array_filter($data, function($item) use ($conditions) {
        foreach ($conditions as $key => $value) {
            if (!isset($item[$key]) || $item[$key] != $value) {
                return false;
            }
        }
        return true;
    });
}

/**
 * 获取单条数据
 */
function db_get_one($table, $conditions) {
    $results = db_get_where($table, $conditions);
    return reset($results) ?: null;
}

/**
 * 插入数据
 */
function db_insert($table, $data) {
    $file_path = DATA_PATH . $table . '.json';
    $items = json_decode(file_get_contents($file_path), true) ?: [];
    
    // 生成 ID
    $data['id'] = uniqid();
    $data['created_at'] = date('Y-m-d H:i:s');
    $data['updated_at'] = date('Y-m-d H:i:s');
    
    $items[] = $data;
    
    return file_put_contents($file_path, json_encode($items, JSON_PRETTY_PRINT)) ? $data['id'] : false;
}

/**
 * 更新数据
 */
function db_update($table, $id, $data) {
    $file_path = DATA_PATH . $table . '.json';
    $items = json_decode(file_get_contents($file_path), true) ?: [];
    
    foreach ($items as &$item) {
        if ($item['id'] == $id) {
            $item = array_merge($item, $data);
            $item['updated_at'] = date('Y-m-d H:i:s');
            break;
        }
    }
    
    return file_put_contents($file_path, json_encode($items, JSON_PRETTY_PRINT));
}

/**
 * 删除数据
 */
function db_delete($table, $id) {
    $file_path = DATA_PATH . $table . '.json';
    $items = json_decode(file_get_contents($file_path), true) ?: [];
    
    $items = array_filter($items, function($item) use ($id) {
        return $item['id'] != $id;
    });
    
    return file_put_contents($file_path, json_encode(array_values($items), JSON_PRETTY_PRINT));
}

/**
 * 根据条件删除数据
 */
function db_delete_where($table, $conditions) {
    $file_path = DATA_PATH . $table . '.json';
    $items = json_decode(file_get_contents($file_path), true) ?: [];
    
    $items = array_filter($items, function($item) use ($conditions) {
        foreach ($conditions as $key => $value) {
            if (isset($item[$key]) && $item[$key] == $value) {
                return false;
            }
        }
        return true;
    });
    
    return file_put_contents($file_path, json_encode(array_values($items), JSON_PRETTY_PRINT));
}
?>