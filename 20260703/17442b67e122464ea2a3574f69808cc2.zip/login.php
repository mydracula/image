<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

// 如果已经登录，跳转到首页
if (is_logged_in()) {
    header('Location: index.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    $result = login($username, $password);
    
    if ($result === true) {
        header('Location: index.php');
        exit;
    } elseif ($result === 'account_banned') {
        $error = '您的账号已被封禁';
    } else {
        $error = '用户名或密码错误';
    }
}
?>
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>登录 - 静态网站托管平台</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-gray-50">
    <div class="min-h-screen flex items-center justify-center">
        <div class="bg-white p-8 rounded-lg shadow-md w-96">
            <h1 class="text-2xl font-bold text-center mb-6">登录账户</h1>
            
            <?php if ($error): ?>
                <div class="bg-red-100 text-red-700 p-3 rounded mb-4 text-sm">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="mb-4">
                    <label class="block text-sm font-medium mb-2">用户名</label>
                    <input type="text" name="username" required 
                           class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:border-primary">
                </div>
                
                <div class="mb-6">
                    <label class="block text-sm font-medium mb-2">密码</label>
                    <input type="password" name="password" required 
                           class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:border-primary">
                </div>
                
                <button type="submit" 
                        class="w-full bg-primary text-white py-2 rounded hover:bg-primary/90 transition">
                    登录
                </button>
            </form>
            
            <div class="mt-4 text-center text-sm">
                <span class="text-gray-600">还没有账户？</span>
                <a href="register.php" class="text-primary hover:underline">立即注册</a>
            </div>
            
            <div class="mt-6 text-center">
                <a href="index.php" class="text-sm text-gray-500 hover:underline">返回首页</a>
            </div>
        </div>
    </div>
</body>
</html>