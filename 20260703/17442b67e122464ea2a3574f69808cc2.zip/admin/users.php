<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

// 检查管理员权限
if (!is_admin()) {
    header('Location: ../login.php');
    exit;
}

$users = db_get_all('users', 'created_at DESC');
$current_user = get_logged_user(); // 获取当前登录的管理员
?>
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>用户管理 - 后台管理</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        /* 全局样式 */
        :root {
            --primary: #3b82f6;
            --primary-dark: #2563eb;
            --success: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
            --info: #3b82f6;
            --gray-50: #f9fafb;
            --gray-100: #f3f4f6;
            --gray-200: #e5e7eb;
            --gray-300: #d4d6d9;
            --gray-400: #9ca3af;
            --gray-500: #6b7280;
            --gray-600: #4b5563;
            --gray-700: #374151;
            --gray-800: #1f2937;
            --gray-900: #111827;
        }

        /* 自定义提示框 */
        .custom-toast {
            position: fixed;
            top: 20px;
            right: 20px;
            min-width: 280px;
            max-width: 90%;
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1), 0 10px 10px -5px rgba(0,0,0,0.04);
            padding: 16px 20px;
            transform: translateX(400px);
            transition: transform 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55);
            z-index: 9999;
            border-left: 4px solid;
            backdrop-filter: blur(10px);
            background: rgba(255,255,255,0.98);
        }
        
        .custom-toast.show {
            transform: translateX(0);
        }
        
        .custom-toast.success {
            border-left-color: var(--success);
        }
        
        .custom-toast.error {
            border-left-color: var(--danger);
        }
        
        .custom-toast.warning {
            border-left-color: var(--warning);
        }
        
        .custom-toast.info {
            border-left-color: var(--info);
        }
        
        .toast-content {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .toast-icon {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            font-weight: bold;
            flex-shrink: 0;
        }
        
        .success .toast-icon {
            background: var(--success);
            color: white;
        }
        
        .error .toast-icon {
            background: var(--danger);
            color: white;
        }
        
        .warning .toast-icon {
            background: var(--warning);
            color: white;
        }
        
        .info .toast-icon {
            background: var(--info);
            color: white;
        }
        
        .toast-message {
            flex: 1;
            font-size: 14px;
            color: var(--gray-800);
            font-weight: 500;
            line-height: 1.5;
            word-break: break-word;
        }
        
        .toast-close {
            cursor: pointer;
            color: var(--gray-400);
            font-size: 20px;
            line-height: 1;
            transition: color 0.2s;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            flex-shrink: 0;
        }
        
        .toast-close:hover {
            color: var(--gray-600);
            background: var(--gray-100);
        }
        
        /* 确认对话框 */
        .confirm-dialog-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 10000;
            backdrop-filter: blur(4px);
            padding: 16px;
        }
        
        .confirm-dialog {
            background: white;
            border-radius: 24px;
            width: 90%;
            max-width: 400px;
            padding: 32px 24px;
            box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);
            transform: scale(0.9);
            transition: transform 0.2s;
        }
        
        .confirm-dialog.show {
            transform: scale(1);
        }
        
        .confirm-dialog-icon {
            width: 64px;
            height: 64px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 32px;
        }
        
        .confirm-dialog-icon.warning {
            background: #fef3c7;
            color: var(--warning);
        }
        
        .confirm-dialog-icon.error {
            background: #fee2e2;
            color: var(--danger);
        }
        
        .confirm-dialog-title {
            font-size: 20px;
            font-weight: 600;
            color: var(--gray-900);
            text-align: center;
            margin-bottom: 8px;
        }
        
        .confirm-dialog-message {
            font-size: 14px;
            color: var(--gray-500);
            text-align: center;
            margin-bottom: 24px;
            line-height: 1.6;
            word-break: break-word;
        }
        
        .confirm-dialog-actions {
            display: flex;
            gap: 12px;
        }
        
        .confirm-dialog-btn {
            flex: 1;
            padding: 12px;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            border: none;
            transition: all 0.2s;
        }
        
        .confirm-dialog-btn.cancel {
            background: var(--gray-100);
            color: var(--gray-700);
        }
        
        .confirm-dialog-btn.cancel:hover {
            background: var(--gray-200);
        }
        
        .confirm-dialog-btn.delete {
            background: var(--danger);
            color: white;
        }
        
        .confirm-dialog-btn.delete:hover {
            background: #dc2626;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
        }
        
        /* 导航栏美化 */
        .navbar {
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
            box-shadow: 0 4px 20px rgba(0,0,0,0.02);
            border-bottom: 1px solid rgba(59, 130, 246, 0.08);
            backdrop-filter: blur(10px);
        }
        
        .navbar-brand {
            font-size: 1.3rem;
            font-weight: 700;
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            letter-spacing: -0.5px;
            position: relative;
            padding-left: 12px;
        }
        
        .navbar-brand::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 4px;
            height: 24px;
            background: linear-gradient(135deg, var(--primary), #8b5cf6);
            border-radius: 4px;
        }
        
        .nav-links {
            display: flex;
            gap: 8px;
        }
        
        .nav-link {
            color: var(--gray-600);
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
            padding: 6px 12px;
            border-radius: 30px;
            transition: all 0.2s;
            background: rgba(255,255,255,0.8);
            border: 1px solid rgba(100, 116, 139, 0.1);
            white-space: nowrap;
        }
        
        .nav-link:hover {
            background: white;
            color: var(--primary);
            border-color: var(--primary);
            transform: translateY(-1px);
        }
        
        /* 页面标题美化 */
        .page-header {
            background: white;
            border-radius: 24px;
            padding: 24px 20px;
            margin-bottom: 24px;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -1px rgba(0,0,0,0.06);
            border: 1px solid rgba(59, 130, 246, 0.1);
        }
        
        .page-title {
            font-size: 2rem;
            font-weight: 700;
            background: linear-gradient(135deg, var(--gray-900) 0%, var(--gray-700) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 8px;
        }
        
        .page-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 12px;
            margin-top: 20px;
        }
        
        .stat-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
            background: var(--gray-50);
            border-radius: 16px;
            border: 1px solid var(--gray-200);
        }
        
        .stat-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary), #8b5cf6);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 20px;
            flex-shrink: 0;
        }
        
        .stat-info h3 {
            font-size: 12px;
            color: var(--gray-500);
            font-weight: 400;
        }
        
        .stat-info p {
            font-size: 20px;
            font-weight: 600;
            color: var(--gray-900);
            line-height: 1.2;
        }
        
        /* 卡片美化 */
        .card {
            background: white;
            border-radius: 24px;
            box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1), 0 8px 10px -6px rgba(0,0,0,0.02);
            overflow: hidden;
            border: 1px solid rgba(59, 130, 246, 0.1);
        }
        
        .card-header {
            padding: 20px;
            border-bottom: 1px solid var(--gray-200);
            background: linear-gradient(135deg, #ffffff 0%, #fafafa 100%);
        }
        
        .card-header h2 {
            font-size: 18px;
            font-weight: 600;
            color: var(--gray-900);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .card-body {
            padding: 16px;
            overflow-x: auto;
        }
        
        /* 表格美化 - 手机适配 */
        .users-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .users-table th {
            text-align: left;
            padding: 12px 8px;
            font-size: 12px;
            font-weight: 600;
            color: var(--gray-500);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            background: var(--gray-50);
            white-space: nowrap;
        }
        
        .users-table td {
            padding: 12px 8px;
            background: white;
            border-bottom: 1px solid var(--gray-200);
            vertical-align: middle;
        }
        
        .users-table tr:last-child td {
            border-bottom: none;
        }
        
        /* 用户信息 - 修复头像显示 */
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
            min-width: 140px;
        }
        
        .user-avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            object-fit: cover;
            background: var(--gray-100);
            border: 2px solid var(--gray-200);
            flex-shrink: 0;
        }
        
        .user-name {
            font-size: 14px;
            font-weight: 500;
            color: var(--gray-800);
            max-width: 100px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        
        /* 邮箱样式 */
        .user-email {
            font-size: 12px;
            color: var(--gray-500);
            max-width: 150px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        
        /* 积分徽章 */
        .points-badge {
            display: inline-block;
            padding: 4px 10px;
            background: #fef3c7;
            border-radius: 30px;
            color: #92400e;
            font-weight: 600;
            font-size: 12px;
            white-space: nowrap;
        }
        
        /* 角色标签 */
        .role-badge {
            display: inline-flex;
            align-items: center;
            padding: 4px 10px;
            border-radius: 30px;
            font-size: 11px;
            font-weight: 500;
            gap: 4px;
            white-space: nowrap;
        }
        
        .role-admin {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .role-user {
            background: #e0e7ff;
            color: #3730a3;
        }
        
        /* 注册时间 */
        .reg-time {
            font-size: 11px;
            color: var(--gray-500);
            white-space: nowrap;
        }
        
        /* 操作按钮美化 */
        .action-buttons {
            display: flex;
            gap: 4px;
            flex-wrap: wrap;
            justify-content: center;
        }
        
        .action-btn {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            white-space: nowrap;
        }
        
        .action-btn.delete {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .action-btn.delete:hover {
            background: #fecaca;
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(239, 68, 68, 0.2);
        }
        
        .action-btn.disabled {
            background: #f3f4f6;
            color: var(--gray-400);
            cursor: not-allowed;
            opacity: 0.6;
        }
        
        .action-btn.disabled:hover {
            transform: none;
            box-shadow: none;
        }
        
        /* 空状态 */
        .empty-state {
            text-align: center;
            padding: 40px 16px;
        }
        
        .empty-icon {
            font-size: 48px;
            margin-bottom: 16px;
            opacity: 0.5;
        }
        
        .empty-title {
            font-size: 16px;
            font-weight: 600;
            color: var(--gray-700);
            margin-bottom: 4px;
        }
        
        .empty-desc {
            font-size: 13px;
            color: var(--gray-500);
        }
        
        /* 手机端适配 */
        @media (max-width: 768px) {
            .page-title {
                font-size: 1.8rem;
            }
            
            .page-stats {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .stat-item {
                padding: 10px;
            }
            
            .stat-icon {
                width: 32px;
                height: 32px;
                font-size: 16px;
            }
            
            .stat-info p {
                font-size: 16px;
            }
            
            .card-body {
                padding: 12px;
            }
            
            /* 表格响应式 */
            .users-table {
                display: block;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
            }
            
            .users-table th,
            .users-table td {
                padding: 10px 6px;
                font-size: 11px;
            }
            
            .user-info {
                min-width: 120px;
            }
            
            .user-avatar {
                width: 28px;
                height: 28px;
            }
            
            .user-name {
                max-width: 70px;
                font-size: 12px;
            }
            
            .user-email {
                max-width: 100px;
            }
            
            .action-buttons {
                flex-direction: column;
                gap: 4px;
            }
            
            .action-btn {
                width: 100%;
                justify-content: center;
                padding: 6px 8px;
            }
            
            .nav-links {
                gap: 4px;
            }
            
            .nav-link {
                padding: 4px 8px;
                font-size: 12px;
            }
        }
        
        @media (max-width: 480px) {
            .page-header {
                padding: 16px;
            }
            
            .page-title {
                font-size: 1.5rem;
            }
            
            .page-stats {
                grid-template-columns: 1fr;
            }
            
            .navbar-brand {
                font-size: 1.1rem;
                padding-left: 8px;
            }
            
            .nav-link {
                padding: 4px 6px;
                font-size: 11px;
            }
            
            .users-table th:nth-child(2),
            .users-table td:nth-child(2) {
                display: none; /* 在小屏幕上隐藏邮箱列 */
            }
        }
        
        /* 工具提示 */
        [title] {
            cursor: help;
        }
        
        /* 加载动画 */
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        .loading {
            display: inline-block;
            width: 16px;
            height: 16px;
            border: 2px solid var(--gray-200);
            border-top-color: var(--primary);
            border-radius: 50%;
            animation: spin 0.6s linear infinite;
        }
        
        /* 管理员标签提示 */
        .self-warning {
            font-size: 10px;
            color: var(--gray-400);
            margin-left: 4px;
        }
    </style>
</head>
<body>
    <div class="min-h-screen bg-background">
        <!-- 美化后的导航栏 -->
        <nav class="navbar sticky top-0 z-50 w-full">
            <div class="container mx-auto px-4">
                <div class="flex h-16 items-center justify-between">
                    <a href="index.php" class="navbar-brand flex items-center gap-2">
                        后台管理
                    </a>
                    <div class="nav-links">
                        <a href="index.php" class="nav-link">
                            ← 首页
                        </a>
                        <a href="../logout.php" class="nav-link">
                            退出
                        </a>
                    </div>
                </div>
            </div>
        </nav>

        <main class="container mx-auto px-4 py-8">
            <!-- 页面标题和统计 -->
            <div class="page-header">
                <h1 class="page-title">用户管理</h1>
                <p class="text-gray-500" style="font-size: 14px;">查看所有注册用户，可以删除用户（不能删除管理员和自己）</p>
                
                <?php
                $admin_count = count(db_get_where('users', ['role' => 'admin']));
                $total_points = 0;
                foreach ($users as $user) {
                    $total_points += $user['points'];
                }
                ?>
                
                <div class="page-stats">
                    <div class="stat-item">
                        <div class="stat-icon">👥</div>
                        <div class="stat-info">
                            <h3>总用户</h3>
                            <p><?php echo count($users); ?></p>
                        </div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-icon">👑</div>
                        <div class="stat-info">
                            <h3>管理员</h3>
                            <p><?php echo $admin_count; ?></p>
                        </div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-icon">⭐</div>
                        <div class="stat-info">
                            <h3>总积分</h3>
                            <p><?php echo $total_points; ?></p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- 用户列表卡片 -->
            <div class="card">
                <div class="card-header">
                    <h2>
                        <span>📋</span>
                        用户列表
                    </h2>
                </div>
                <div class="card-body">
                    <?php if (empty($users)): ?>
                        <div class="empty-state">
                            <div class="empty-icon">📭</div>
                            <h3 class="empty-title">暂无用户</h3>
                            <p class="empty-desc">还没有用户注册</p>
                        </div>
                    <?php else: ?>
                        <table class="users-table">
                            <thead>
                                <tr>
                                    <th>用户</th>
                                    <th>邮箱</th>
                                    <th>积分</th>
                                    <th>角色</th>
                                    <th>注册时间</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($users as $user): 
                                    $avatar = !empty($user['avatar']) ? $user['avatar'] : '../img/touxiang.png';
                                    $is_self = ($current_user['id'] == $user['id']);
                                ?>
                                    <tr>
                                        <td>
                                            <div class="user-info" title="<?php echo htmlspecialchars($user['username']); ?>">
                                                <img src="<?php echo $avatar; ?>" 
                                                     class="user-avatar"
                                                     alt="avatar"
                                                     onerror="this.src='../img/touxiang.png'">
                                                <div>
                                                    <div class="user-name"><?php echo htmlspecialchars($user['username']); ?></div>
                                                    <?php if ($is_self): ?>
                                                        <span class="self-warning">(当前登录)</span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="user-email" title="<?php echo htmlspecialchars($user['email'] ?: '未设置'); ?>">
                                                <?php echo htmlspecialchars($user['email'] ?: '-'); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="points-badge">⭐ <?php echo $user['points']; ?></span>
                                        </td>
                                        <td>
                                            <span class="role-badge <?php echo $user['role'] == 'admin' ? 'role-admin' : 'role-user'; ?>">
                                                <?php if ($user['role'] == 'admin'): ?>
                                                    <span>👑</span> 管理员
                                                <?php else: ?>
                                                    <span>👤</span> 普通用户
                                                <?php endif; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="reg-time" title="<?php echo $user['created_at']; ?>">
                                                <?php echo date('Y-m-d', strtotime($user['created_at'])); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="action-buttons">
                                                <?php if (!$is_self && $user['role'] != 'admin'): ?>
                                                    <!-- 只能删除其他普通用户 -->
                                                    <a href="javascript:;" onclick="confirmDelete('<?php echo $user['id']; ?>', '<?php echo addslashes($user['username']); ?>')" class="action-btn delete" title="删除用户">
                                                        🗑️ 删除
                                                    </a>
                                                <?php else: ?>
                                                    <!-- 不能删除自己或管理员 -->
                                                    <span class="action-btn disabled" title="<?php echo $is_self ? '不能删除自己' : '不能删除管理员'; ?>">
                                                        🚫 不可删除
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
    
    <!-- 自定义确认对话框 -->
    <div class="confirm-dialog-overlay" id="confirmDialog">
        <div class="confirm-dialog" id="confirmDialogBox">
            <div class="confirm-dialog-icon" id="confirmIcon">⚠️</div>
            <div class="confirm-dialog-title" id="confirmTitle">确认操作</div>
            <div class="confirm-dialog-message" id="confirmMessage"></div>
            <div class="confirm-dialog-actions" id="confirmActions">
                <button class="confirm-dialog-btn cancel" onclick="hideConfirmDialog()">取 消</button>
                <button class="confirm-dialog-btn" id="confirmBtn">确 认</button>
            </div>
        </div>
    </div>
    
    <!-- 自定义提示框容器 -->
    <div id="toastContainer"></div>
    
    <script src="../assets/js/main.js"></script>
    <script>
    // 自定义提示框函数
    function showToast(message, type = 'info') {
        const container = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.className = `custom-toast ${type}`;
        
        const icons = {
            success: '✓',
            error: '✗',
            warning: '⚠',
            info: 'ℹ'
        };
        
        toast.innerHTML = `
            <div class="toast-content">
                <div class="toast-icon">${icons[type] || 'ℹ'}</div>
                <div class="toast-message">${message}</div>
                <div class="toast-close" onclick="this.parentElement.parentElement.remove()">×</div>
            </div>
        `;
        
        container.appendChild(toast);
        
        // 触发动画
        setTimeout(() => {
            toast.classList.add('show');
        }, 10);
        
        // 3秒后自动关闭
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => {
                if (toast.parentElement) {
                    toast.remove();
                }
            }, 300);
        }, 3000);
    }
    
    // 确认对话框变量
    let currentAction = null;
    
    // 显示确认对话框
    function showConfirmDialog(title, message, icon = 'warning', onConfirm) {
        document.getElementById('confirmTitle').textContent = title;
        document.getElementById('confirmMessage').textContent = message;
        
        const iconEl = document.getElementById('confirmIcon');
        iconEl.className = `confirm-dialog-icon ${icon}`;
        
        let iconChar = '⚠️';
        if (icon === 'error') iconChar = '❌';
        else iconChar = '⚠️';
        iconEl.textContent = iconChar;
        
        const confirmBtn = document.getElementById('confirmBtn');
        confirmBtn.className = 'confirm-dialog-btn delete';
        confirmBtn.textContent = '确 认 删 除';
        
        document.getElementById('confirmDialog').style.display = 'flex';
        currentAction = onConfirm;
        
        setTimeout(() => {
            document.getElementById('confirmDialogBox').classList.add('show');
        }, 10);
    }
    
    // 隐藏确认对话框
    function hideConfirmDialog() {
        document.getElementById('confirmDialogBox').classList.remove('show');
        setTimeout(() => {
            document.getElementById('confirmDialog').style.display = 'none';
        }, 200);
    }
    
    // 确认删除用户
    function confirmDelete(userId, username) {
        showConfirmDialog(
            '确认删除用户',
            `确定要删除用户 "${username}" 吗？此操作不可撤销，该用户的所有网站也将被永久删除！`,
            'error',
            function() {
                showToast('正在删除用户...', 'info');
                
                // 删除用户及其所有网站
                fetch('../api/admin.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        action: 'delete_user',
                        user_id: userId
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showToast('用户删除成功', 'success');
                        setTimeout(() => {
                            location.reload();
                        }, 1000);
                    } else {
                        showToast(data.message || '删除失败', 'error');
                    }
                })
                .catch(error => {
                    showToast('网络错误，请稍后重试', 'error');
                })
                .finally(() => {
                    hideConfirmDialog();
                });
            }
        );
    }
    
    // 设置确认按钮事件
    document.getElementById('confirmBtn').addEventListener('click', function() {
        if (currentAction) {
            currentAction();
        }
    });
    
    // 点击遮罩层关闭
    document.getElementById('confirmDialog').addEventListener('click', function(e) {
        if (e.target === this) {
            hideConfirmDialog();
        }
    });
    </script>
</body>
</html>