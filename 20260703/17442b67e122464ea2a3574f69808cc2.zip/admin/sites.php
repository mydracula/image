<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

// 检查管理员权限
if (!is_admin()) {
    header('Location: ../login.php');
    exit;
}

$sites = db_get_all('sites', 'created_at DESC');
?>
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>网站管理 - 后台管理</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        /* 全局样式 */
        :root {
            --primary: #3b82f6;
            --primary-dark: #2563eb;
            --success: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
            --info: #3b82f6;
            --gray-50: #f9fafb;
            --gray-100: #f3f4f6;
            --gray-200: #e5e7eb;
            --gray-300: #d4d6d9;
            --gray-400: #9ca3af;
            --gray-500: #6b7280;
            --gray-600: #4b5563;
            --gray-700: #374151;
            --gray-800: #1f2937;
            --gray-900: #111827;
        }

        /* 自定义提示框 */
        .custom-toast {
            position: fixed;
            top: 20px;
            right: 20px;
            min-width: 280px;
            max-width: 90%;
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1), 0 10px 10px -5px rgba(0,0,0,0.04);
            padding: 16px 20px;
            transform: translateX(400px);
            transition: transform 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55);
            z-index: 9999;
            border-left: 4px solid;
            backdrop-filter: blur(10px);
            background: rgba(255,255,255,0.98);
        }
        
        .custom-toast.show {
            transform: translateX(0);
        }
        
        .custom-toast.success {
            border-left-color: var(--success);
        }
        
        .custom-toast.error {
            border-left-color: var(--danger);
        }
        
        .custom-toast.warning {
            border-left-color: var(--warning);
        }
        
        .custom-toast.info {
            border-left-color: var(--info);
        }
        
        .toast-content {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .toast-icon {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            font-weight: bold;
            flex-shrink: 0;
        }
        
        .success .toast-icon {
            background: var(--success);
            color: white;
        }
        
        .error .toast-icon {
            background: var(--danger);
            color: white;
        }
        
        .warning .toast-icon {
            background: var(--warning);
            color: white;
        }
        
        .info .toast-icon {
            background: var(--info);
            color: white;
        }
        
        .toast-message {
            flex: 1;
            font-size: 14px;
            color: var(--gray-800);
            font-weight: 500;
            line-height: 1.5;
            word-break: break-word;
        }
        
        .toast-close {
            cursor: pointer;
            color: var(--gray-400);
            font-size: 20px;
            line-height: 1;
            transition: color 0.2s;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            flex-shrink: 0;
        }
        
        .toast-close:hover {
            color: var(--gray-600);
            background: var(--gray-100);
        }
        
        /* 确认对话框 */
        .confirm-dialog-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 10000;
            backdrop-filter: blur(4px);
            padding: 16px;
        }
        
        .confirm-dialog {
            background: white;
            border-radius: 24px;
            width: 90%;
            max-width: 400px;
            padding: 32px 24px;
            box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);
            transform: scale(0.9);
            transition: transform 0.2s;
        }
        
        .confirm-dialog.show {
            transform: scale(1);
        }
        
        .confirm-dialog-icon {
            width: 64px;
            height: 64px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 32px;
        }
        
        .confirm-dialog-icon.warning {
            background: #fef3c7;
            color: var(--warning);
        }
        
        .confirm-dialog-icon.success {
            background: #d1fae5;
            color: var(--success);
        }
        
        .confirm-dialog-icon.error {
            background: #fee2e2;
            color: var(--danger);
        }
        
        .confirm-dialog-icon.info {
            background: #dbeafe;
            color: var(--info);
        }
        
        .confirm-dialog-title {
            font-size: 20px;
            font-weight: 600;
            color: var(--gray-900);
            text-align: center;
            margin-bottom: 8px;
        }
        
        .confirm-dialog-message {
            font-size: 14px;
            color: var(--gray-500);
            text-align: center;
            margin-bottom: 24px;
            line-height: 1.6;
            word-break: break-word;
        }
        
        .confirm-dialog-actions {
            display: flex;
            gap: 12px;
        }
        
        .confirm-dialog-btn {
            flex: 1;
            padding: 12px;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            border: none;
            transition: all 0.2s;
        }
        
        .confirm-dialog-btn.cancel {
            background: var(--gray-100);
            color: var(--gray-700);
        }
        
        .confirm-dialog-btn.cancel:hover {
            background: var(--gray-200);
        }
        
        .confirm-dialog-btn.enable {
            background: var(--success);
            color: white;
        }
        
        .confirm-dialog-btn.enable:hover {
            background: #059669;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
        }
        
        .confirm-dialog-btn.disable {
            background: var(--warning);
            color: white;
        }
        
        .confirm-dialog-btn.disable:hover {
            background: #d97706;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(245, 158, 11, 0.3);
        }
        
        .confirm-dialog-btn.delete {
            background: var(--danger);
            color: white;
        }
        
        .confirm-dialog-btn.delete:hover {
            background: #dc2626;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
        }
        
        /* 导航栏美化 */
        .navbar {
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
            box-shadow: 0 4px 20px rgba(0,0,0,0.02);
            border-bottom: 1px solid rgba(59, 130, 246, 0.08);
            backdrop-filter: blur(10px);
        }
        
        .navbar-brand {
            font-size: 1.3rem;
            font-weight: 700;
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            letter-spacing: -0.5px;
            position: relative;
            padding-left: 12px;
        }
        
        .navbar-brand::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 4px;
            height: 24px;
            background: linear-gradient(135deg, var(--primary), #8b5cf6);
            border-radius: 4px;
        }
        
        .nav-links {
            display: flex;
            gap: 8px;
        }
        
        .nav-link {
            color: var(--gray-600);
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
            padding: 6px 12px;
            border-radius: 30px;
            transition: all 0.2s;
            background: rgba(255,255,255,0.8);
            border: 1px solid rgba(100, 116, 139, 0.1);
            white-space: nowrap;
        }
        
        .nav-link:hover {
            background: white;
            color: var(--primary);
            border-color: var(--primary);
            transform: translateY(-1px);
        }
        
        /* 页面标题美化 */
        .page-header {
            background: white;
            border-radius: 24px;
            padding: 24px 20px;
            margin-bottom: 24px;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -1px rgba(0,0,0,0.06);
            border: 1px solid rgba(59, 130, 246, 0.1);
        }
        
        .page-title {
            font-size: 2rem;
            font-weight: 700;
            background: linear-gradient(135deg, var(--gray-900) 0%, var(--gray-700) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 8px;
        }
        
        .page-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 12px;
            margin-top: 20px;
        }
        
        .stat-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
            background: var(--gray-50);
            border-radius: 16px;
            border: 1px solid var(--gray-200);
        }
        
        .stat-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary), #8b5cf6);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 20px;
            flex-shrink: 0;
        }
        
        .stat-info h3 {
            font-size: 12px;
            color: var(--gray-500);
            font-weight: 400;
        }
        
        .stat-info p {
            font-size: 20px;
            font-weight: 600;
            color: var(--gray-900);
            line-height: 1.2;
        }
        
        /* 卡片美化 */
        .card {
            background: white;
            border-radius: 24px;
            box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1), 0 8px 10px -6px rgba(0,0,0,0.02);
            overflow: hidden;
            border: 1px solid rgba(59, 130, 246, 0.1);
        }
        
        .card-header {
            padding: 20px;
            border-bottom: 1px solid var(--gray-200);
            background: linear-gradient(135deg, #ffffff 0%, #fafafa 100%);
        }
        
        .card-header h2 {
            font-size: 18px;
            font-weight: 600;
            color: var(--gray-900);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .card-body {
            padding: 16px;
            overflow-x: auto;
        }
        
        /* 表格美化 - 手机适配 */
        .site-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .site-table th {
            text-align: left;
            padding: 12px 8px;
            font-size: 12px;
            font-weight: 600;
            color: var(--gray-500);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            background: var(--gray-50);
            white-space: nowrap;
        }
        
        .site-table td {
            padding: 12px 8px;
            background: white;
            border-bottom: 1px solid var(--gray-200);
            vertical-align: middle;
        }
        
        .site-table tr:last-child td {
            border-bottom: none;
        }
        
        /* 网站标题链接 - 截断显示 */
        .site-title-wrapper {
            display: flex;
            align-items: center;
            gap: 8px;
            max-width: 200px;
        }
        
        .site-title-link {
            color: var(--primary);
            text-decoration: none;
            font-weight: 500;
            font-size: 14px;
            transition: all 0.2s;
            display: inline-block;
            max-width: 150px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        
        .site-title-link:hover {
            color: var(--primary-dark);
            text-decoration: underline;
        }
        
        /* 用户信息 - 修复头像显示 */
        .user-info {
            display: flex;
            align-items: center;
            gap: 8px;
            min-width: 120px;
        }
        
        .user-avatar {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            object-fit: cover;
            background: var(--gray-100);
            border: 1px solid var(--gray-200);
            flex-shrink: 0;
        }
        
        .user-name {
            font-size: 13px;
            color: var(--gray-700);
            max-width: 80px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        
        /* UUID 截断 */
        .uuid-code {
            background: var(--gray-100);
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 11px;
            font-family: monospace;
            color: var(--gray-700);
            display: inline-block;
            max-width: 80px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        
        /* 文件数标签 */
        .file-count {
            display: inline-block;
            padding: 4px 8px;
            background: var(--gray-100);
            border-radius: 30px;
            font-size: 11px;
            color: var(--gray-600);
            font-weight: 500;
            white-space: nowrap;
        }
        
        /* 访问量 */
        .views-count {
            font-weight: 500;
            font-size: 12px;
            color: var(--gray-700);
            white-space: nowrap;
        }
        
        /* 创建时间 */
        .created-time {
            font-size: 11px;
            color: var(--gray-500);
            white-space: nowrap;
        }
        
        /* 状态标签美化 */
        .status-badge {
            display: inline-flex;
            align-items: center;
            padding: 4px 10px;
            border-radius: 30px;
            font-size: 11px;
            font-weight: 500;
            gap: 4px;
            white-space: nowrap;
        }
        
        .status-active {
            background: #d1fae5;
            color: #065f46;
        }
        
        .status-disabled {
            background: #fee2e2;
            color: #991b1b;
        }
        
        /* 操作按钮美化 - 手机适配 */
        .action-buttons {
            display: flex;
            gap: 4px;
            flex-wrap: wrap;
        }
        
        .action-btn {
            padding: 4px 8px;
            border-radius: 16px;
            font-size: 11px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 2px;
            white-space: nowrap;
        }
        
        .action-btn.view {
            background: #eff6ff;
            color: var(--primary);
        }
        
        .action-btn.view:hover {
            background: #dbeafe;
        }
        
        .action-btn.edit {
            background: #f3f4f6;
            color: var(--gray-700);
        }
        
        .action-btn.edit:hover {
            background: #e5e7eb;
        }
        
        .action-btn.enable {
            background: #d1fae5;
            color: #065f46;
        }
        
        .action-btn.enable:hover {
            background: #a7f3d0;
        }
        
        .action-btn.disable {
            background: #fef3c7;
            color: #92400e;
        }
        
        .action-btn.disable:hover {
            background: #fde68a;
        }
        
        .action-btn.delete {
            background: #fee2e2;
            color: var(--danger);
        }
        
        .action-btn.delete:hover {
            background: #fecaca;
        }
        
        /* 空状态 */
        .empty-state {
            text-align: center;
            padding: 40px 16px;
        }
        
        .empty-icon {
            font-size: 48px;
            margin-bottom: 16px;
            opacity: 0.5;
        }
        
        .empty-title {
            font-size: 16px;
            font-weight: 600;
            color: var(--gray-700);
            margin-bottom: 4px;
        }
        
        .empty-desc {
            font-size: 13px;
            color: var(--gray-500);
        }
        
        /* 手机端适配 */
        @media (max-width: 768px) {
            .page-title {
                font-size: 1.8rem;
            }
            
            .page-stats {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .stat-item {
                padding: 10px;
            }
            
            .stat-icon {
                width: 32px;
                height: 32px;
                font-size: 16px;
            }
            
            .stat-info p {
                font-size: 16px;
            }
            
            .card-body {
                padding: 12px;
            }
            
            /* 表格响应式 */
            .site-table {
                display: block;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
            }
            
            .site-table th,
            .site-table td {
                padding: 10px 6px;
                font-size: 11px;
            }
            
            .site-title-link {
                max-width: 100px;
            }
            
            .user-info {
                min-width: 100px;
            }
            
            .user-name {
                max-width: 60px;
            }
            
            .uuid-code {
                max-width: 60px;
            }
            
            .action-buttons {
                flex-direction: column;
                gap: 4px;
            }
            
            .action-btn {
                width: 100%;
                justify-content: center;
                padding: 6px 8px;
            }
            
            .nav-links {
                gap: 4px;
            }
            
            .nav-link {
                padding: 4px 8px;
                font-size: 12px;
            }
        }
        
        @media (max-width: 480px) {
            .page-header {
                padding: 16px;
            }
            
            .page-title {
                font-size: 1.5rem;
            }
            
            .page-stats {
                grid-template-columns: 1fr;
            }
            
            .navbar-brand {
                font-size: 1.1rem;
                padding-left: 8px;
            }
            
            .nav-link {
                padding: 4px 6px;
                font-size: 11px;
            }
        }
        
        /* 工具提示 */
        [title] {
            cursor: help;
        }
        
        /* 加载动画 */
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        .loading {
            display: inline-block;
            width: 16px;
            height: 16px;
            border: 2px solid var(--gray-200);
            border-top-color: var(--primary);
            border-radius: 50%;
            animation: spin 0.6s linear infinite;
        }
    </style>
</head>
<body>
    <div class="min-h-screen bg-background">
        <!-- 美化后的导航栏 -->
        <nav class="navbar sticky top-0 z-50 w-full">
            <div class="container mx-auto px-4">
                <div class="flex h-16 items-center justify-between">
                    <a href="index.php" class="navbar-brand flex items-center gap-2">
                        后台管理
                    </a>
                    <div class="nav-links">
                        <a href="index.php" class="nav-link">
                            ← 首页
                        </a>
                        <a href="../logout.php" class="nav-link">
                            退出
                        </a>
                    </div>
                </div>
            </div>
        </nav>

        <main class="container mx-auto px-4 py-8">
            <!-- 页面标题和统计 -->
            <div class="page-header">
                <h1 class="page-title">网站管理</h1>
                <p class="text-gray-500" style="font-size: 14px;">管理所有用户创建的网站，可以查看、启用/禁用或删除</p>
                
                <?php
                $active_count = count(db_get_where('sites', ['status' => 'active']));
                $disabled_count = count(db_get_where('sites', ['status' => 'disabled']));
                $total_files = 0;
                $total_views = 0;
                foreach ($sites as $site) {
                    $total_files += count($site['files'] ?? []);
                    $total_views += $site['views'] ?? 0;
                }
                ?>
                
                <div class="page-stats">
                    <div class="stat-item">
                        <div class="stat-icon">🌐</div>
                        <div class="stat-info">
                            <h3>总网站</h3>
                            <p><?php echo count($sites); ?></p>
                        </div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-icon">✅</div>
                        <div class="stat-info">
                            <h3>正常</h3>
                            <p><?php echo $active_count; ?></p>
                        </div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-icon">❌</div>
                        <div class="stat-info">
                            <h3>禁用</h3>
                            <p><?php echo $disabled_count; ?></p>
                        </div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-icon">📁</div>
                        <div class="stat-info">
                            <h3>文件数</h3>
                            <p><?php echo $total_files; ?></p>
                        </div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-icon">👁️</div>
                        <div class="stat-info">
                            <h3>访问量</h3>
                            <p><?php echo $total_views; ?></p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- 网站列表卡片 -->
            <div class="card">
                <div class="card-header">
                    <h2>
                        <span>📋</span>
                        网站列表
                    </h2>
                </div>
                <div class="card-body">
                    <?php if (empty($sites)): ?>
                        <div class="empty-state">
                            <div class="empty-icon">📭</div>
                            <h3 class="empty-title">暂无网站</h3>
                            <p class="empty-desc">还没有用户创建任何网站</p>
                        </div>
                    <?php else: ?>
                        <table class="site-table">
                            <thead>
                                <tr>
                                    <th>网站名称</th>
                                    <th>创建者</th>
                                    <th>UUID</th>
                                    <th>文件</th>
                                    <th>访问</th>
                                    <th>创建时间</th>
                                    <th>状态</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($sites as $site): 
                                    $user = db_get_one('users', ['id' => $site['user_id']]);
                                    $site_title = htmlspecialchars($site['title']);
                                    $short_title = mb_strlen($site_title) > 8 ? mb_substr($site_title, 0, 8) . '...' : $site_title;
                                    $uuid = $site['uuid'];
                                    $short_uuid = strlen($uuid) > 8 ? substr($uuid, 0, 8) . '...' : $uuid;
                                    $avatar = isset($user['avatar']) && $user['avatar'] ? $user['avatar'] : '../img/touxiang.png';
                                ?>
                                    <tr>
                                        <td>
                                            <div class="site-title-wrapper" title="<?php echo $site_title; ?>">
                                                <span>🌐</span>
                                                <a href="../site.php?id=<?php echo $site['id']; ?>" target="_blank" class="site-title-link" title="<?php echo $site_title; ?>">
                                                    <?php echo $short_title; ?>
                                                </a>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="user-info" title="<?php echo htmlspecialchars($user['username'] ?? '未知'); ?>">
                                                <img src="<?php echo $avatar; ?>" 
                                                     class="user-avatar"
                                                     alt="avatar"
                                                     onerror="this.src='../img/touxiang.png'">
                                                <span class="user-name"><?php echo htmlspecialchars($user['username'] ?? '未知'); ?></span>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="uuid-code" title="<?php echo $uuid; ?>"><?php echo $short_uuid; ?></span>
                                        </td>
                                        <td>
                                            <span class="file-count"><?php echo count($site['files'] ?? []); ?> 个</span>
                                        </td>
                                        <td>
                                            <span class="views-count">👁️ <?php echo $site['views'] ?? 0; ?></span>
                                        </td>
                                        <td>
                                            <span class="created-time" title="<?php echo $site['created_at']; ?>">
                                                <?php echo date('m-d', strtotime($site['created_at'])); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="status-badge <?php echo $site['status'] == 'active' ? 'status-active' : 'status-disabled'; ?>">
                                                <?php if ($site['status'] == 'active'): ?>
                                                    <span>●</span> 正常
                                                <?php else: ?>
                                                    <span>●</span> 禁用
                                                <?php endif; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="action-buttons">
                                                <a href="../site.php?id=<?php echo $site['id']; ?>" target="_blank" class="action-btn view" title="查看网站">
                                                    👁️ 查看
                                                </a>
                                                <a href="../edit.php?id=<?php echo $site['id']; ?>" target="_blank" class="action-btn edit" title="编辑网站">
                                                    ✏️ 编辑
                                                </a>
                                                <?php if ($site['status'] == 'active'): ?>
                                                    <a href="javascript:;" onclick="toggleStatus('<?php echo $site['id']; ?>', 'disable')" class="action-btn disable" title="禁用网站">
                                                        🔒 禁用
                                                    </a>
                                                <?php else: ?>
                                                    <a href="javascript:;" onclick="toggleStatus('<?php echo $site['id']; ?>', 'enable')" class="action-btn enable" title="启用网站">
                                                        🔓 启用
                                                    </a>
                                                <?php endif; ?>
                                                <a href="javascript:;" onclick="confirmDelete('<?php echo $site['id']; ?>', '<?php echo addslashes($site_title); ?>')" class="action-btn delete" title="删除网站">
                                                    🗑️ 删除
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
    
    <!-- 自定义确认对话框 -->
    <div class="confirm-dialog-overlay" id="confirmDialog">
        <div class="confirm-dialog" id="confirmDialogBox">
            <div class="confirm-dialog-icon" id="confirmIcon">⚠️</div>
            <div class="confirm-dialog-title" id="confirmTitle">确认操作</div>
            <div class="confirm-dialog-message" id="confirmMessage"></div>
            <div class="confirm-dialog-actions" id="confirmActions">
                <button class="confirm-dialog-btn cancel" onclick="hideConfirmDialog()">取 消</button>
                <button class="confirm-dialog-btn" id="confirmBtn">确 认</button>
            </div>
        </div>
    </div>
    
    <!-- 自定义提示框容器 -->
    <div id="toastContainer"></div>
    
    <script src="../assets/js/main.js"></script>
    <script>
    // 自定义提示框函数
    function showToast(message, type = 'info') {
        const container = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.className = `custom-toast ${type}`;
        
        const icons = {
            success: '✓',
            error: '✗',
            warning: '⚠',
            info: 'ℹ'
        };
        
        toast.innerHTML = `
            <div class="toast-content">
                <div class="toast-icon">${icons[type] || 'ℹ'}</div>
                <div class="toast-message">${message}</div>
                <div class="toast-close" onclick="this.parentElement.parentElement.remove()">×</div>
            </div>
        `;
        
        container.appendChild(toast);
        
        // 触发动画
        setTimeout(() => {
            toast.classList.add('show');
        }, 10);
        
        // 3秒后自动关闭
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => {
                if (toast.parentElement) {
                    toast.remove();
                }
            }, 300);
        }, 3000);
    }
    
    // 确认对话框变量
    let currentAction = null;
    
    // 显示确认对话框
    function showConfirmDialog(title, message, icon = 'warning', actionType = 'confirm', onConfirm) {
        document.getElementById('confirmTitle').textContent = title;
        document.getElementById('confirmMessage').textContent = message;
        
        const iconEl = document.getElementById('confirmIcon');
        iconEl.className = `confirm-dialog-icon ${icon}`;
        
        let iconChar = '⚠️';
        if (icon === 'success') iconChar = '✅';
        else if (icon === 'error') iconChar = '❌';
        else if (icon === 'info') iconChar = 'ℹ️';
        else iconChar = '⚠️';
        iconEl.textContent = iconChar;
        
        const confirmBtn = document.getElementById('confirmBtn');
        
        if (actionType === 'enable') {
            confirmBtn.className = 'confirm-dialog-btn enable';
            confirmBtn.textContent = '确 认 启 用';
        } else if (actionType === 'disable') {
            confirmBtn.className = 'confirm-dialog-btn disable';
            confirmBtn.textContent = '确 认 禁 用';
        } else if (actionType === 'delete') {
            confirmBtn.className = 'confirm-dialog-btn delete';
            confirmBtn.textContent = '确 认 删 除';
        } else {
            confirmBtn.className = 'confirm-dialog-btn enable';
            confirmBtn.textContent = '确 认';
        }
        
        document.getElementById('confirmDialog').style.display = 'flex';
        currentAction = onConfirm;
        
        setTimeout(() => {
            document.getElementById('confirmDialogBox').classList.add('show');
        }, 10);
    }
    
    // 隐藏确认对话框
    function hideConfirmDialog() {
        document.getElementById('confirmDialogBox').classList.remove('show');
        setTimeout(() => {
            document.getElementById('confirmDialog').style.display = 'none';
        }, 200);
    }
    
    // 切换网站状态
    function toggleStatus(siteId, action) {
        const newStatus = action === 'enable' ? 'active' : 'disabled';
        const actionText = action === 'enable' ? '启用' : '禁用';
        
        showConfirmDialog(
            `确认${actionText}网站`,
            `确定要${actionText}这个网站吗？`,
            action === 'enable' ? 'success' : 'warning',
            action,
            function() {
                showToast(`正在${actionText}网站...`, 'info');
                
                fetch('../api/admin.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        action: 'update_site_status',
                        site_id: siteId,
                        status: newStatus
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showToast(`网站${actionText}成功`, 'success');
                        setTimeout(() => {
                            location.reload();
                        }, 1000);
                    } else {
                        showToast(data.message || '操作失败', 'error');
                    }
                })
                .catch(error => {
                    showToast('网络错误，请稍后重试', 'error');
                })
                .finally(() => {
                    hideConfirmDialog();
                });
            }
        );
    }
    
    // 确认删除
    function confirmDelete(siteId, siteTitle) {
        showConfirmDialog(
            '确认删除网站',
            `确定要删除网站 "${siteTitle}" 吗？此操作不可撤销，所有文件将被永久删除！`,
            'error',
            'delete',
            function() {
                showToast('正在删除网站...', 'info');
                
                fetch('../api/delete_site.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({id: siteId})
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showToast('网站删除成功', 'success');
                        setTimeout(() => {
                            location.reload();
                        }, 1000);
                    } else {
                        showToast(data.message || '删除失败', 'error');
                    }
                })
                .catch(error => {
                    showToast('网络错误，请稍后重试', 'error');
                })
                .finally(() => {
                    hideConfirmDialog();
                });
            }
        );
    }
    
    // 设置确认按钮事件
    document.getElementById('confirmBtn').addEventListener('click', function() {
        if (currentAction) {
            currentAction();
        }
    });
    
    // 点击遮罩层关闭
    document.getElementById('confirmDialog').addEventListener('click', function(e) {
        if (e.target === this) {
            hideConfirmDialog();
        }
    });
    </script>
</body>
</html>