<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

// 检查管理员权限
if (!is_admin()) {
    header('Location: ../login.php');
    exit;
}

$user = get_logged_user();

// 统计数据
$users_count = count(db_get_all('users'));
$sites_count = count(db_get_all('sites'));
$orders_count = count(db_get_all('orders'));
$pending_orders = count(db_get_where('orders', ['status' => 'pending']));

// 获取更多统计数据
$active_users = count(db_get_where('users', ['status' => 'active']));
$active_sites = count(db_get_where('sites', ['status' => 'active']));
$total_points = 0;
$users = db_get_all('users');
foreach ($users as $u) {
    $total_points += $u['points'];
}
?>
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>后台管理 - 静态网站托管平台</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        /* 全局样式 */
        :root {
            --primary: #3b82f6;
            --primary-dark: #2563eb;
            --success: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
            --info: #3b82f6;
            --gray-50: #f9fafb;
            --gray-100: #f3f4f6;
            --gray-200: #e5e7eb;
            --gray-300: #d4d6d9;
            --gray-400: #9ca3af;
            --gray-500: #6b7280;
            --gray-600: #4b5563;
            --gray-700: #374151;
            --gray-800: #1f2937;
            --gray-900: #111827;
        }

        /* 导航栏美化 */
        .navbar {
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
            box-shadow: 0 4px 20px rgba(0,0,0,0.02);
            border-bottom: 1px solid rgba(59, 130, 246, 0.08);
            backdrop-filter: blur(10px);
        }
        
        .navbar-brand {
            font-size: 1.3rem;
            font-weight: 700;
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            letter-spacing: -0.5px;
            position: relative;
            padding-left: 12px;
        }
        
        .navbar-brand::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 4px;
            height: 24px;
            background: linear-gradient(135deg, var(--primary), #8b5cf6);
            border-radius: 4px;
        }
        
        .admin-info {
            display: flex;
            align-items: center;
            gap: 8px;
            background: rgba(255,255,255,0.8);
            padding: 4px 12px 4px 8px;
            border-radius: 40px;
            border: 1px solid rgba(59, 130, 246, 0.1);
        }
        
        .admin-avatar {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid white;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
        
        .admin-name {
            font-size: 13px;
            font-weight: 500;
            color: var(--gray-700);
        }
        
        .nav-links {
            display: flex;
            gap: 6px;
        }
        
        .nav-link {
            color: var(--gray-600);
            text-decoration: none;
            font-size: 12px;
            font-weight: 500;
            padding: 5px 10px;
            border-radius: 30px;
            transition: all 0.2s;
            background: rgba(255,255,255,0.8);
            border: 1px solid rgba(100, 116, 139, 0.1);
            white-space: nowrap;
        }
        
        .nav-link:hover {
            background: white;
            color: var(--primary);
            border-color: var(--primary);
            transform: translateY(-1px);
        }

        /* 页面标题美化 */
        .page-header {
            background: white;
            border-radius: 20px;
            padding: 16px 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04);
            border: 1px solid rgba(59, 130, 246, 0.1);
        }
        
        .page-title {
            font-size: 1.6rem;
            font-weight: 700;
            background: linear-gradient(135deg, var(--gray-900) 0%, var(--gray-700) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 4px;
        }
        
        .welcome-text {
            font-size: 13px;
            color: var(--gray-500);
        }

        /* 统计卡片区域 - 缩小版 */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
            margin-bottom: 24px;
        }
        
        .stat-card {
            background: white;
            border-radius: 16px;
            padding: 14px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04);
            border: 1px solid rgba(59, 130, 246, 0.1);
            transition: all 0.2s ease;
            position: relative;
            overflow: hidden;
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, var(--primary), #8b5cf6);
        }
        
        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 16px rgba(0,0,0,0.08);
        }
        
        .stat-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        
        .stat-title {
            font-size: 12px;
            color: var(--gray-500);
            font-weight: 500;
        }
        
        .stat-icon {
            width: 32px;
            height: 32px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
        }
        
        .stat-icon.users {
            background: #e0e7ff;
            color: #3730a3;
        }
        
        .stat-icon.sites {
            background: #d1fae5;
            color: #065f46;
        }
        
        .stat-icon.orders {
            background: #fef3c7;
            color: #92400e;
        }
        
        .stat-icon.pending {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .stat-value {
            font-size: 24px;
            font-weight: 700;
            color: var(--gray-900);
            line-height: 1.2;
            margin-bottom: 4px;
        }
        
        .stat-trend {
            font-size: 11px;
            color: var(--gray-500);
            display: flex;
            align-items: center;
            gap: 4px;
        }
        
        .trend-up {
            color: var(--success);
        }

        /* 管理卡片区域 - 缩小版横向布局 */
        .management-section {
            margin-top: 24px;
        }
        
        .section-title {
            font-size: 16px;
            font-weight: 600;
            color: var(--gray-800);
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        
        .section-title span {
            width: 3px;
            height: 18px;
            background: linear-gradient(135deg, var(--primary), #8b5cf6);
            border-radius: 4px;
        }
        
        .management-cards {
            display: flex;
            gap: 12px;
            flex-wrap: nowrap;
            overflow-x: auto;
            padding: 2px 0 8px 0;
            -webkit-overflow-scrolling: touch;
            scrollbar-width: thin;
            scrollbar-color: var(--primary) var(--gray-200);
        }
        
        .management-cards::-webkit-scrollbar {
            height: 4px;
        }
        
        .management-cards::-webkit-scrollbar-track {
            background: var(--gray-200);
            border-radius: 10px;
        }
        
        .management-cards::-webkit-scrollbar-thumb {
            background: var(--primary);
            border-radius: 10px;
        }
        
        .management-card {
            flex: 0 0 200px;
            background: white;
            border-radius: 16px;
            padding: 16px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04);
            border: 1px solid rgba(59, 130, 246, 0.1);
            transition: all 0.2s ease;
            text-decoration: none;
            color: inherit;
            position: relative;
            overflow: hidden;
        }
        
        .management-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 16px rgba(0,0,0,0.08);
            border-color: var(--primary);
        }
        
        .management-card::after {
            content: '';
            position: absolute;
            top: 0;
            right: 0;
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, transparent 50%, rgba(59, 130, 246, 0.05) 50%);
            border-radius: 0 16px 0 0;
        }
        
        .card-icon {
            width: 40px;
            height: 40px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            margin-bottom: 12px;
        }
        
        .card-icon.users {
            background: linear-gradient(135deg, #e0e7ff, #c7d2fe);
            color: #3730a3;
        }
        
        .card-icon.sites {
            background: linear-gradient(135deg, #d1fae5, #a7f3d0);
            color: #065f46;
        }
        
        .card-icon.orders {
            background: linear-gradient(135deg, #fef3c7, #fde68a);
            color: #92400e;
        }
        
        .card-title {
            font-size: 16px;
            font-weight: 600;
            color: var(--gray-900);
            margin-bottom: 4px;
        }
        
        .card-desc {
            font-size: 11px;
            color: var(--gray-500);
            line-height: 1.4;
            margin-bottom: 12px;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            height: 30px;
        }
        
        .card-stats {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding-top: 10px;
            border-top: 1px solid var(--gray-200);
        }
        
        .stat-small {
            display: flex;
            align-items: baseline;
            gap: 4px;
        }
        
        .stat-small-value {
            font-size: 16px;
            font-weight: 600;
            color: var(--gray-900);
        }
        
        .stat-small-label {
            font-size: 10px;
            color: var(--gray-500);
        }
        
        .card-arrow {
            width: 24px;
            height: 24px;
            border-radius: 50%;
            background: var(--gray-100);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--gray-600);
            font-size: 14px;
            transition: all 0.2s;
        }
        
        .management-card:hover .card-arrow {
            background: var(--primary);
            color: white;
            transform: translateX(4px);
        }

        /* 快捷操作区域 - 缩小版 */
        .quick-actions {
            margin-top: 20px;
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }
        
        .quick-btn {
            padding: 6px 14px;
            border-radius: 30px;
            background: white;
            border: 1px solid var(--gray-200);
            color: var(--gray-700);
            font-size: 12px;
            font-weight: 500;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            transition: all 0.2s;
        }
        
        .quick-btn:hover {
            background: var(--primary);
            border-color: var(--primary);
            color: white;
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(59, 130, 246, 0.2);
        }

        /* 手机端适配 */
        @media (max-width: 768px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 8px;
            }
            
            .stat-card {
                padding: 12px;
            }
            
            .stat-value {
                font-size: 20px;
            }
            
            .management-cards {
                gap: 8px;
            }
            
            .management-card {
                flex: 0 0 180px;
                padding: 14px;
            }
            
            .card-icon {
                width: 36px;
                height: 36px;
                font-size: 18px;
            }
            
            .card-title {
                font-size: 15px;
            }
            
            .card-desc {
                font-size: 10px;
                height: 28px;
            }
            
            .admin-info {
                display: none; /* 平板隐藏管理员信息 */
            }
        }
        
        @media (max-width: 480px) {
            .page-header {
                padding: 12px 16px;
            }
            
            .page-title {
                font-size: 1.4rem;
            }
            
            .stats-grid {
                gap: 6px;
            }
            
            .stat-card {
                padding: 10px;
            }
            
            .stat-icon {
                width: 28px;
                height: 28px;
                font-size: 14px;
            }
            
            .stat-value {
                font-size: 18px;
            }
            
            .stat-title {
                font-size: 11px;
            }
            
            .navbar-brand {
                font-size: 1rem;
                padding-left: 6px;
            }
            
            .nav-link {
                padding: 4px 6px;
                font-size: 11px;
            }
            
            .management-card {
                flex: 0 0 160px;
                padding: 12px;
            }
            
            .quick-btn {
                padding: 5px 10px;
                font-size: 11px;
            }
        }
    </style>
</head>
<body>
    <div class="min-h-screen bg-background">
        <!-- 美化后的导航栏 -->
        <nav class="navbar sticky top-0 z-50 w-full">
            <div class="container mx-auto px-4">
                <div class="flex h-14 items-center justify-between">
                    <a href="../index.php" class="navbar-brand flex items-center gap-2">
                        后台管理
                    </a>
                    
                    <div class="flex items-center gap-2">
                        <!-- 管理员信息（平板以上显示） -->
                        <div class="admin-info">
                            <img src="<?php echo $user['avatar'] ?: '../img/touxiang.png'; ?>" 
                                 class="admin-avatar" 
                                 alt="avatar"
                                 onerror="this.src='../img/touxiang.png'">
                            <span class="admin-name"><?php echo htmlspecialchars($user['username']); ?></span>
                        </div>
                        
                        <!-- 导航链接 -->
                        <div class="nav-links">
                            <a href="../dashboard.php" class="nav-link" title="返回前台">
                                <span>🏠</span> 前台
                            </a>
                            <a href="../logout.php" class="nav-link" title="退出登录">
                                <span>🚪</span> 退出
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </nav>

        <main class="container mx-auto px-4 py-6">
            <!-- 页面标题 -->
            <div class="page-header">
                <h1 class="page-title">欢迎回来</h1>
                <p class="welcome-text">管理员: <?php echo htmlspecialchars($user['username']); ?> · 管理后台</p>
            </div>
            
            <!-- 统计卡片区域 -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-header">
                        <span class="stat-title">总用户</span>
                        <span class="stat-icon users">👥</span>
                    </div>
                    <div class="stat-value"><?php echo $users_count; ?></div>
                    <div class="stat-trend">
                        <span class="trend-up">↑</span> 活跃 <?php echo $active_users; ?>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-header">
                        <span class="stat-title">总网站</span>
                        <span class="stat-icon sites">🌐</span>
                    </div>
                    <div class="stat-value"><?php echo $sites_count; ?></div>
                    <div class="stat-trend">
                        <span class="trend-up">↑</span> 正常 <?php echo $active_sites; ?>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-header">
                        <span class="stat-title">总订单</span>
                        <span class="stat-icon orders">📦</span>
                    </div>
                    <div class="stat-value"><?php echo $orders_count; ?></div>
                    <div class="stat-trend">
                        已完成 <?php echo $orders_count - $pending_orders; ?>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-header">
                        <span class="stat-title">待处理</span>
                        <span class="stat-icon pending">⏳</span>
                    </div>
                    <div class="stat-value" style="color: var(--warning);"><?php echo $pending_orders; ?></div>
                    <div class="stat-trend">
                        总积分 <?php echo $total_points; ?>
                    </div>
                </div>
            </div>

            <!-- 管理卡片区域 - 横向滚动（缩小版） -->
            <div class="management-section">
                <div class="section-title">
                    <span></span>
                    快速管理
                </div>
                
                <div class="management-cards">
                    <!-- 用户管理卡片 -->
                    <a href="users.php" class="management-card">
                        <div class="card-icon users">👥</div>
                        <h3 class="card-title">用户管理</h3>
                        <p class="card-desc">查看用户，可删除普通用户</p>
                        <div class="card-stats">
                            <div class="stat-small">
                                <span class="stat-small-value"><?php echo $users_count; ?></span>
                                <span class="stat-small-label">用户</span>
                            </div>
                            <div class="card-arrow">→</div>
                        </div>
                    </a>
                    
                    <!-- 网站管理卡片 -->
                    <a href="sites.php" class="management-card">
                        <div class="card-icon sites">🌐</div>
                        <h3 class="card-title">网站管理</h3>
                        <p class="card-desc">查看网站，可启用/禁用/删除</p>
                        <div class="card-stats">
                            <div class="stat-small">
                                <span class="stat-small-value"><?php echo $sites_count; ?></span>
                                <span class="stat-small-label">网站</span>
                            </div>
                            <div class="card-arrow">→</div>
                        </div>
                    </a>
                    
                    <!-- 订单管理卡片 -->
                    <a href="orders.php" class="management-card">
                        <div class="card-icon orders">📦</div>
                        <h3 class="card-title">订单管理</h3>
                        <p class="card-desc">审核充值订单，通过/拒绝/删除</p>
                        <div class="card-stats">
                            <div class="stat-small">
                                <span class="stat-small-value"><?php echo $pending_orders; ?></span>
                                <span class="stat-small-label">待审</span>
                            </div>
                            <div class="card-arrow">→</div>
                        </div>
                    </a>
                </div>
            </div>
            
            <!-- 快捷操作区域 -->
            <div class="quick-actions">
                <a href="users.php" class="quick-btn">
                    <span>👥</span> 用户
                </a>
                <a href="sites.php" class="quick-btn">
                    <span>🌐</span> 网站
                </a>
                <a href="orders.php" class="quick-btn">
                    <span>📦</span> 订单
                </a>
                <a href="../create.php" class="quick-btn">
                    <span>✨</span> 新建
                </a>
                <a href="../dashboard.php" class="quick-btn">
                    <span>📊</span> 仪表板
                </a>
            </div>
        </main>
    </div>
</body>
</html>