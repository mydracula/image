<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

// 检查管理员权限
if (!is_admin()) {
    header('Location: ../login.php');
    exit;
}

$orders = db_get_all('orders', 'created_at DESC');
?>
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>订单管理 - 后台管理</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        /* 全局样式 */
        :root {
            --primary: #3b82f6;
            --primary-dark: #2563eb;
            --success: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
            --info: #3b82f6;
            --gray-50: #f9fafb;
            --gray-100: #f3f4f6;
            --gray-200: #e5e7eb;
            --gray-300: #d4d6d9;
            --gray-400: #9ca3af;
            --gray-500: #6b7280;
            --gray-600: #4b5563;
            --gray-700: #374151;
            --gray-800: #1f2937;
            --gray-900: #111827;
        }

        /* 自定义提示框 */
        .custom-toast {
            position: fixed;
            top: 20px;
            right: 20px;
            min-width: 320px;
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1), 0 10px 10px -5px rgba(0,0,0,0.04);
            padding: 16px 20px;
            transform: translateX(400px);
            transition: transform 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55);
            z-index: 9999;
            border-left: 4px solid;
            backdrop-filter: blur(10px);
            background: rgba(255,255,255,0.98);
        }
        
        .custom-toast.show {
            transform: translateX(0);
        }
        
        .custom-toast.success {
            border-left-color: var(--success);
        }
        
        .custom-toast.error {
            border-left-color: var(--danger);
        }
        
        .custom-toast.warning {
            border-left-color: var(--warning);
        }
        
        .custom-toast.info {
            border-left-color: var(--info);
        }
        
        .toast-content {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .toast-icon {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            font-weight: bold;
        }
        
        .success .toast-icon {
            background: var(--success);
            color: white;
        }
        
        .error .toast-icon {
            background: var(--danger);
            color: white;
        }
        
        .warning .toast-icon {
            background: var(--warning);
            color: white;
        }
        
        .info .toast-icon {
            background: var(--info);
            color: white;
        }
        
        .toast-message {
            flex: 1;
            font-size: 14px;
            color: var(--gray-800);
            font-weight: 500;
            line-height: 1.5;
        }
        
        .toast-close {
            cursor: pointer;
            color: var(--gray-400);
            font-size: 20px;
            line-height: 1;
            transition: color 0.2s;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
        }
        
        .toast-close:hover {
            color: var(--gray-600);
            background: var(--gray-100);
        }
        
        /* 确认对话框 */
        .confirm-dialog-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 10000;
            backdrop-filter: blur(4px);
        }
        
        .confirm-dialog {
            background: white;
            border-radius: 24px;
            width: 90%;
            max-width: 400px;
            padding: 32px;
            box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);
            transform: scale(0.9);
            transition: transform 0.2s;
        }
        
        .confirm-dialog.show {
            transform: scale(1);
        }
        
        .confirm-dialog-icon {
            width: 64px;
            height: 64px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 32px;
        }
        
        .confirm-dialog-icon.warning {
            background: #fef3c7;
            color: var(--warning);
        }
        
        .confirm-dialog-icon.success {
            background: #d1fae5;
            color: var(--success);
        }
        
        .confirm-dialog-icon.error {
            background: #fee2e2;
            color: var(--danger);
        }
        
        .confirm-dialog-icon.info {
            background: #dbeafe;
            color: var(--info);
        }
        
        .confirm-dialog-title {
            font-size: 20px;
            font-weight: 600;
            color: var(--gray-900);
            text-align: center;
            margin-bottom: 8px;
        }
        
        .confirm-dialog-message {
            font-size: 14px;
            color: var(--gray-500);
            text-align: center;
            margin-bottom: 24px;
            line-height: 1.6;
        }
        
        .confirm-dialog-actions {
            display: flex;
            gap: 12px;
        }
        
        .confirm-dialog-btn {
            flex: 1;
            padding: 12px;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            border: none;
            transition: all 0.2s;
        }
        
        .confirm-dialog-btn.cancel {
            background: var(--gray-100);
            color: var(--gray-700);
        }
        
        .confirm-dialog-btn.cancel:hover {
            background: var(--gray-200);
        }
        
        .confirm-dialog-btn.approve {
            background: var(--success);
            color: white;
        }
        
        .confirm-dialog-btn.approve:hover {
            background: #059669;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
        }
        
        .confirm-dialog-btn.reject {
            background: var(--danger);
            color: white;
        }
        
        .confirm-dialog-btn.reject:hover {
            background: #dc2626;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
        }
        
        .confirm-dialog-btn.delete {
            background: var(--gray-700);
            color: white;
        }
        
        .confirm-dialog-btn.delete:hover {
            background: var(--gray-800);
            transform: translateY(-1px);
        }
        
        /* 导航栏美化 */
        .navbar {
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
            box-shadow: 0 4px 20px rgba(0,0,0,0.02);
            border-bottom: 1px solid rgba(59, 130, 246, 0.08);
            backdrop-filter: blur(10px);
        }
        
        .navbar-brand {
            font-size: 1.5rem;
            font-weight: 700;
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            letter-spacing: -0.5px;
            position: relative;
            padding-left: 12px;
        }
        
        .navbar-brand::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 4px;
            height: 24px;
            background: linear-gradient(135deg, var(--primary), #8b5cf6);
            border-radius: 4px;
        }
        
        .nav-link {
            color: var(--gray-600);
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            padding: 8px 16px;
            border-radius: 30px;
            transition: all 0.2s;
            background: rgba(255,255,255,0.8);
            border: 1px solid rgba(100, 116, 139, 0.1);
        }
        
        .nav-link:hover {
            background: white;
            color: var(--primary);
            border-color: var(--primary);
            transform: translateY(-1px);
        }
        
        /* 页面标题美化 */
        .page-header {
            background: white;
            border-radius: 24px;
            padding: 32px;
            margin-bottom: 32px;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -1px rgba(0,0,0,0.06);
            border: 1px solid rgba(59, 130, 246, 0.1);
        }
        
        .page-title {
            font-size: 2.5rem;
            font-weight: 700;
            background: linear-gradient(135deg, var(--gray-900) 0%, var(--gray-700) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 8px;
        }
        
        .page-stats {
            display: flex;
            gap: 24px;
            margin-top: 20px;
            flex-wrap: wrap;
        }
        
        .stat-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            background: var(--gray-50);
            border-radius: 16px;
            border: 1px solid var(--gray-200);
            min-width: 180px;
        }
        
        .stat-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary), #8b5cf6);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 20px;
        }
        
        .stat-info h3 {
            font-size: 14px;
            color: var(--gray-500);
            font-weight: 400;
        }
        
        .stat-info p {
            font-size: 24px;
            font-weight: 600;
            color: var(--gray-900);
            line-height: 1.2;
        }
        
        /* 卡片美化 */
        .card {
            background: white;
            border-radius: 24px;
            box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1), 0 8px 10px -6px rgba(0,0,0,0.02);
            overflow: hidden;
            border: 1px solid rgba(59, 130, 246, 0.1);
        }
        
        .card-header {
            padding: 24px;
            border-bottom: 1px solid var(--gray-200);
            background: linear-gradient(135deg, #ffffff 0%, #fafafa 100%);
        }
        
        .card-header h2 {
            font-size: 20px;
            font-weight: 600;
            color: var(--gray-900);
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .card-body {
            padding: 24px;
            overflow-x: auto;
        }
        
        /* 表格美化 */
        .orders-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0 8px;
        }
        
        .orders-table th {
            text-align: left;
            padding: 12px 16px;
            font-size: 13px;
            font-weight: 600;
            color: var(--gray-500);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            background: var(--gray-50);
            border-radius: 12px 12px 0 0;
        }
        
        .orders-table td {
            padding: 16px;
            background: white;
            border-radius: 16px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.02);
            transition: all 0.2s;
        }
        
        .orders-table tr:hover td {
            background: var(--gray-50);
            transform: translateY(-2px);
            box-shadow: 0 8px 16px -4px rgba(0,0,0,0.1);
        }
        
        /* 订单号样式 */
        .order-id {
            font-family: 'SF Mono', 'Fira Code', monospace;
            background: var(--gray-100);
            padding: 4px 8px;
            border-radius: 8px;
            font-size: 12px;
            color: var(--gray-700);
            letter-spacing: 0.5px;
        }
        
        /* 用户名样式 */
        .username-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 4px 12px;
            background: #eff6ff;
            border-radius: 30px;
            color: var(--primary);
            font-weight: 500;
            font-size: 13px;
        }
        
        /* 金额样式 */
        .amount {
            font-weight: 600;
            color: var(--gray-900);
        }
        
        .amount-large {
            font-size: 16px;
            font-weight: 700;
            color: #059669;
        }
        
        /* 积分样式 */
        .points-badge {
            display: inline-block;
            padding: 4px 12px;
            background: #fef3c7;
            border-radius: 30px;
            color: #92400e;
            font-weight: 500;
            font-size: 12px;
        }
        
        /* 状态标签美化 */
        .status-badge {
            display: inline-flex;
            align-items: center;
            padding: 6px 14px;
            border-radius: 30px;
            font-size: 12px;
            font-weight: 500;
            gap: 6px;
        }
        
        .status-pending {
            background: #fef3c7;
            color: #92400e;
        }
        
        .status-approved {
            background: #d1fae5;
            color: #065f46;
        }
        
        .status-rejected {
            background: #fee2e2;
            color: #991b1b;
        }
        
        /* 操作按钮美化 */
        .action-buttons {
            display: flex;
            gap: 6px;
            flex-wrap: wrap;
        }
        
        .action-btn {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        
        .action-btn.approve {
            background: #d1fae5;
            color: #065f46;
        }
        
        .action-btn.approve:hover {
            background: #a7f3d0;
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(16, 185, 129, 0.2);
        }
        
        .action-btn.reject {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .action-btn.reject:hover {
            background: #fecaca;
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(239, 68, 68, 0.2);
        }
        
        .action-btn.delete {
            background: #f3f4f6;
            color: var(--gray-700);
        }
        
        .action-btn.delete:hover {
            background: #e5e7eb;
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        
        /* 时间样式 */
        .order-time {
            font-size: 13px;
            color: var(--gray-500);
            display: flex;
            align-items: center;
            gap: 4px;
        }
        
        /* 空状态 */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
        }
        
        .empty-icon {
            font-size: 64px;
            margin-bottom: 20px;
            opacity: 0.5;
        }
        
        .empty-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--gray-700);
            margin-bottom: 8px;
        }
        
        .empty-desc {
            font-size: 14px;
            color: var(--gray-500);
        }
        
        /* 统计卡片特殊样式 */
        .stat-item.pending {
            border-left: 4px solid var(--warning);
        }
        
        .stat-item.approved {
            border-left: 4px solid var(--success);
        }
        
        .stat-item.rejected {
            border-left: 4px solid var(--danger);
        }
        
        .stat-value {
            font-size: 28px;
            font-weight: 700;
        }
        
        .stat-value.pending {
            color: var(--warning);
        }
        
        .stat-value.approved {
            color: var(--success);
        }
        
        .stat-value.rejected {
            color: var(--danger);
        }
        
        /* 筛选标签 */
        .filter-tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        
        .filter-tab {
            padding: 8px 20px;
            border-radius: 30px;
            font-size: 13px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            background: var(--gray-100);
            color: var(--gray-600);
            border: 1px solid transparent;
        }
        
        .filter-tab:hover {
            background: var(--gray-200);
        }
        
        .filter-tab.active {
            background: var(--primary);
            color: white;
        }
        
        .filter-tab.pending {
            background: #fef3c7;
            color: #92400e;
        }
        
        .filter-tab.pending:hover {
            background: #fde68a;
        }
        
        .filter-tab.approved {
            background: #d1fae5;
            color: #065f46;
        }
        
        .filter-tab.approved:hover {
            background: #a7f3d0;
        }
        
        .filter-tab.rejected {
            background: #fee2e2;
            color: #991b1b;
        }
        
        .filter-tab.rejected:hover {
            background: #fecaca;
        }
    </style>
</head>
<body>
    <div class="min-h-screen bg-background">
        <!-- 美化后的导航栏 -->
        <nav class="navbar sticky top-0 z-50 w-full">
            <div class="container mx-auto px-4">
                <div class="flex h-16 items-center justify-between">
                    <a href="index.php" class="navbar-brand flex items-center gap-2">
                        后台管理
                    </a>
                    <div class="flex items-center gap-3">
                        <a href="index.php" class="nav-link">
                            ← 返回仪表板
                        </a>
                        <a href="../logout.php" class="nav-link">
                            退出
                        </a>
                    </div>
                </div>
            </div>
        </nav>

        <main class="container mx-auto px-4 py-8">
            <!-- 页面标题和统计 -->
            <div class="page-header">
                <h1 class="page-title">订单管理</h1>
                <p class="text-gray-500">管理用户的充值订单，可以审核通过、拒绝或删除</p>
                
                <?php
                $pending_count = count(db_get_where('orders', ['status' => 'pending']));
                $approved_count = count(db_get_where('orders', ['status' => 'approved']));
                $rejected_count = count(db_get_where('orders', ['status' => 'rejected']));
                $total_amount = 0;
                $total_points = 0;
                foreach ($orders as $order) {
                    if ($order['status'] == 'approved') {
                        $total_amount += $order['amount'];
                        $total_points += $order['points'];
                    }
                }
                ?>
                
                <div class="page-stats">
                    <div class="stat-item pending">
                        <div class="stat-icon">⏳</div>
                        <div class="stat-info">
                            <h3>待审核</h3>
                            <p class="stat-value pending"><?php echo $pending_count; ?></p>
                        </div>
                    </div>
                    <div class="stat-item approved">
                        <div class="stat-icon">✅</div>
                        <div class="stat-info">
                            <h3>已通过</h3>
                            <p class="stat-value approved"><?php echo $approved_count; ?></p>
                        </div>
                    </div>
                    <div class="stat-item rejected">
                        <div class="stat-icon">❌</div>
                        <div class="stat-info">
                            <h3>已拒绝</h3>
                            <p class="stat-value rejected"><?php echo $rejected_count; ?></p>
                        </div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-icon">💰</div>
                        <div class="stat-info">
                            <h3>总金额</h3>
                            <p>¥<?php echo $total_amount; ?></p>
                        </div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-icon">⭐</div>
                        <div class="stat-info">
                            <h3>总积分</h3>
                            <p><?php echo $total_points; ?></p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- 筛选标签 -->
            <div class="filter-tabs" id="filterTabs">
                <span class="filter-tab active" onclick="filterOrders('all')">全部 (<?php echo count($orders); ?>)</span>
                <span class="filter-tab pending" onclick="filterOrders('pending')">待审核 (<?php echo $pending_count; ?>)</span>
                <span class="filter-tab approved" onclick="filterOrders('approved')">已通过 (<?php echo $approved_count; ?>)</span>
                <span class="filter-tab rejected" onclick="filterOrders('rejected')">已拒绝 (<?php echo $rejected_count; ?>)</span>
            </div>
            
            <!-- 订单列表卡片 -->
            <div class="card">
                <div class="card-header">
                    <h2>
                        <span>📋</span>
                        订单列表
                    </h2>
                </div>
                <div class="card-body">
                    <?php if (empty($orders)): ?>
                        <div class="empty-state">
                            <div class="empty-icon">📭</div>
                            <h3 class="empty-title">暂无订单</h3>
                            <p class="empty-desc">还没有用户提交充值订单</p>
                        </div>
                    <?php else: ?>
                        <table class="orders-table" id="ordersTable">
                            <thead>
                                <tr>
                                    <th>订单号</th>
                                    <th>用户名</th>
                                    <th>金额</th>
                                    <th>积分</th>
                                    <th>状态</th>
                                    <th>时间</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($orders as $order): ?>
                                    <tr data-status="<?php echo $order['status']; ?>">
                                        <td>
                                            <span class="order-id"><?php echo substr($order['id'], 0, 8); ?>...</span>
                                        </td>
                                        <td>
                                            <span class="username-badge">
                                                <span>👤</span>
                                                <?php echo htmlspecialchars($order['username']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="amount-large">¥<?php echo $order['amount']; ?></span>
                                        </td>
                                        <td>
                                            <span class="points-badge">
                                                ⭐ <?php echo $order['points']; ?> 积分
                                            </span>
                                        </td>
                                        <td>
                                            <span class="status-badge status-<?php echo $order['status']; ?>">
                                                <?php if ($order['status'] == 'pending'): ?>
                                                    <span>⏳</span> 待审核
                                                <?php elseif ($order['status'] == 'approved'): ?>
                                                    <span>✅</span> 已通过
                                                <?php else: ?>
                                                    <span>❌</span> 已拒绝
                                                <?php endif; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="order-time" title="<?php echo $order['created_at']; ?>">
                                                <span>🕒</span>
                                                <?php echo date('Y-m-d H:i', strtotime($order['created_at'])); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="action-buttons">
                                                <?php if ($order['status'] == 'pending'): ?>
                                                    <button onclick="processOrder('<?php echo $order['id']; ?>', 'approve')" class="action-btn approve" title="通过订单">
                                                        ✅ 通过
                                                    </button>
                                                    <button onclick="processOrder('<?php echo $order['id']; ?>', 'reject')" class="action-btn reject" title="拒绝订单">
                                                        ❌ 拒绝
                                                    </button>
                                                <?php endif; ?>
                                                <button onclick="confirmDelete('<?php echo $order['id']; ?>')" class="action-btn delete" title="删除订单">
                                                    🗑️ 删除
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
    
    <!-- 自定义确认对话框 -->
    <div class="confirm-dialog-overlay" id="confirmDialog">
        <div class="confirm-dialog" id="confirmDialogBox">
            <div class="confirm-dialog-icon" id="confirmIcon">⚠️</div>
            <div class="confirm-dialog-title" id="confirmTitle">确认操作</div>
            <div class="confirm-dialog-message" id="confirmMessage"></div>
            <div class="confirm-dialog-actions" id="confirmActions">
                <button class="confirm-dialog-btn cancel" onclick="hideConfirmDialog()">取 消</button>
                <button class="confirm-dialog-btn" id="confirmBtn">确 认</button>
            </div>
        </div>
    </div>
    
    <!-- 自定义提示框容器 -->
    <div id="toastContainer"></div>
    
    <script src="../assets/js/main.js"></script>
    <script>
    // 当前筛选状态
    let currentFilter = 'all';
    
    // 自定义提示框函数
    function showToast(message, type = 'info') {
        const container = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.className = `custom-toast ${type}`;
        
        const icons = {
            success: '✓',
            error: '✗',
            warning: '⚠',
            info: 'ℹ'
        };
        
        toast.innerHTML = `
            <div class="toast-content">
                <div class="toast-icon">${icons[type] || 'ℹ'}</div>
                <div class="toast-message">${message}</div>
                <div class="toast-close" onclick="this.parentElement.parentElement.remove()">×</div>
            </div>
        `;
        
        container.appendChild(toast);
        
        // 触发动画
        setTimeout(() => {
            toast.classList.add('show');
        }, 10);
        
        // 3秒后自动关闭
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => {
                if (toast.parentElement) {
                    toast.remove();
                }
            }, 300);
        }, 3000);
    }
    
    // 确认对话框变量
    let currentAction = null;
    let currentOrderId = '';
    
    // 显示确认对话框
    function showConfirmDialog(title, message, icon = 'warning', actionType = 'confirm', onConfirm) {
        document.getElementById('confirmTitle').textContent = title;
        document.getElementById('confirmMessage').textContent = message;
        
        const iconEl = document.getElementById('confirmIcon');
        iconEl.className = `confirm-dialog-icon ${icon}`;
        
        let iconChar = '⚠️';
        if (icon === 'success') iconChar = '✅';
        else if (icon === 'error') iconChar = '❌';
        else if (icon === 'info') iconChar = 'ℹ️';
        else iconChar = '⚠️';
        iconEl.textContent = iconChar;
        
        const actionsEl = document.getElementById('confirmActions');
        const confirmBtn = document.getElementById('confirmBtn');
        
        if (actionType === 'approve') {
            confirmBtn.className = 'confirm-dialog-btn approve';
            confirmBtn.textContent = '确 认 通 过';
        } else if (actionType === 'reject') {
            confirmBtn.className = 'confirm-dialog-btn reject';
            confirmBtn.textContent = '确 认 拒 绝';
        } else if (actionType === 'delete') {
            confirmBtn.className = 'confirm-dialog-btn delete';
            confirmBtn.textContent = '确 认 删 除';
        } else {
            confirmBtn.className = 'confirm-dialog-btn approve';
            confirmBtn.textContent = '确 认';
        }
        
        document.getElementById('confirmDialog').style.display = 'flex';
        currentAction = onConfirm;
        
        setTimeout(() => {
            document.getElementById('confirmDialogBox').classList.add('show');
        }, 10);
    }
    
    // 隐藏确认对话框
    function hideConfirmDialog() {
        document.getElementById('confirmDialogBox').classList.remove('show');
        setTimeout(() => {
            document.getElementById('confirmDialog').style.display = 'none';
        }, 200);
    }
    
    // 处理订单
    function processOrder(orderId, action) {
        currentOrderId = orderId;
        
        if (action === 'approve') {
            showConfirmDialog(
                '确认通过订单',
                '确定要通过该订单吗？通过后用户将获得相应积分。',
                'success',
                'approve',
                function() {
                    executeOrderAction(orderId, 'approve');
                }
            );
        } else if (action === 'reject') {
            showConfirmDialog(
                '确认拒绝订单',
                '确定要拒绝该订单吗？拒绝后用户不会获得积分。',
                'error',
                'reject',
                function() {
                    executeOrderAction(orderId, 'reject');
                }
            );
        }
    }
    
    // 确认删除订单
    function confirmDelete(orderId) {
        currentOrderId = orderId;
        showConfirmDialog(
            '确认删除订单',
            '确定要删除该订单吗？此操作不可撤销！',
            'warning',
            'delete',
            function() {
                executeOrderAction(orderId, 'delete');
            }
        );
    }
    
    // 执行订单操作
    function executeOrderAction(orderId, action) {
        let apiAction = '';
        let status = '';
        let successMessage = '';
        
        if (action === 'approve') {
            apiAction = 'process_order';
            status = 'approved';
            successMessage = '订单已通过，用户积分已增加';
        } else if (action === 'reject') {
            apiAction = 'process_order';
            status = 'rejected';
            successMessage = '订单已拒绝';
        } else if (action === 'delete') {
            apiAction = 'delete_order';
            successMessage = '订单已删除';
        }
        
        showToast('正在处理...', 'info');
        
        let postData = {};
        if (action === 'delete') {
            postData = {
                action: 'delete_order',
                order_id: orderId
            };
        } else {
            postData = {
                action: 'process_order',
                order_id: orderId,
                status: status
            };
        }
        
        fetch('../api/admin.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(postData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast(successMessage, 'success');
                setTimeout(() => {
                    location.reload();
                }, 1000);
            } else {
                showToast(data.message || '操作失败', 'error');
            }
        })
        .catch(error => {
            showToast('网络错误，请稍后重试', 'error');
        })
        .finally(() => {
            hideConfirmDialog();
        });
    }
    
    // 筛选订单
    function filterOrders(status) {
        currentFilter = status;
        
        // 更新标签样式
        const tabs = document.querySelectorAll('.filter-tab');
        tabs.forEach(tab => {
            tab.classList.remove('active');
        });
        event.target.classList.add('active');
        
        // 筛选表格行
        const rows = document.querySelectorAll('#ordersTable tbody tr');
        rows.forEach(row => {
            if (status === 'all' || row.dataset.status === status) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }
    
    // 设置确认按钮事件
    document.getElementById('confirmBtn').addEventListener('click', function() {
        if (currentAction) {
            currentAction();
        }
    });
    
    // 点击遮罩层关闭
    document.getElementById('confirmDialog').addEventListener('click', function(e) {
        if (e.target === this) {
            hideConfirmDialog();
        }
    });
    </script>
</body>
</html>