<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

// 检查登录
if (!is_logged_in()) {
    echo json_encode(['success' => false, 'message' => '请先登录']);
    exit;
}

$user = get_logged_user();
$data = json_decode(file_get_contents('php://input'), true);
$site_id = $data['id'] ?? '';

if (!$site_id) {
    echo json_encode(['success' => false, 'message' => '参数错误']);
    exit;
}

// 获取网站信息
$site = db_get_one('sites', ['id' => $site_id]);

if (!$site) {
    echo json_encode(['success' => false, 'message' => '网站不存在']);
    exit;
}

// 检查权限（只有作者或管理员可以删除）
if ($site['user_id'] != $user['id'] && !is_admin()) {
    echo json_encode(['success' => false, 'message' => '无权删除']);
    exit;
}

// 删除文件目录
$site_path = UPLOAD_PATH . $site_id . '/';
if (file_exists($site_path)) {
    // 递归删除目录函数
    function deleteDirectory($dir) {
        if (!file_exists($dir)) {
            return true;
        }
        if (!is_dir($dir)) {
            return unlink($dir);
        }
        $items = scandir($dir);
        foreach ($items as $item) {
            if ($item == '.' || $item == '..') {
                continue;
            }
            $path = $dir . DIRECTORY_SEPARATOR . $item;
            if (is_dir($path)) {
                deleteDirectory($path);
            } else {
                unlink($path);
            }
        }
        return rmdir($dir);
    }
    
    if (deleteDirectory($site_path)) {
        // 删除成功
    } else {
        echo json_encode(['success' => false, 'message' => '文件目录删除失败']);
        exit;
    }
}

// 删除数据库记录
if (db_delete('sites', $site_id)) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => '数据库记录删除失败']);
}
?>