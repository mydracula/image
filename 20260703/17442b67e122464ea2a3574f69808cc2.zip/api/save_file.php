<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

if (!is_logged_in()) {
    echo json_encode(['success' => false, 'message' => '请先登录']);
    exit;
}

$user = get_logged_user();
$data = json_decode(file_get_contents('php://input'), true);

$site_id = $data['site_id'] ?? '';
$file = $data['file'] ?? '';
$content = $data['content'] ?? '';

if (!$site_id || !$file) {
    echo json_encode(['success' => false, 'message' => '参数错误']);
    exit;
}

$site = db_get_one('sites', ['id' => $site_id]);

if (!$site || ($site['user_id'] != $user['id'] && !is_admin())) {
    echo json_encode(['success' => false, 'message' => '无权访问']);
    exit;
}

$file_path = UPLOAD_PATH . $site_id . '/' . $file;

// 检查文件类型
$ext = pathinfo($file, PATHINFO_EXTENSION);
if (!in_array(strtolower($ext), ['html', 'htm', 'css', 'js', 'txt'])) {
    echo json_encode(['success' => false, 'message' => '不支持编辑此文件类型']);
    exit;
}

// 创建目录
$dir = dirname($file_path);
if (!file_exists($dir)) {
    mkdir($dir, 0777, true);
}

if (file_put_contents($file_path, $content)) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => '保存失败']);
}
?>