<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

// 检查登录
if (!is_logged_in()) {
    echo json_encode(['success' => false, 'message' => '请先登录']);
    exit;
}

$user = get_logged_user();
$data = json_decode(file_get_contents('php://input'), true);

$amount = $data['amount'] ?? 0;
$points = $data['points'] ?? 0;

if ($amount <= 0 || $points <= 0) {
    echo json_encode(['success' => false, 'message' => '参数错误']);
    exit;
}

// 创建订单
$order = [
    'user_id' => $user['id'],
    'username' => $user['username'],
    'amount' => $amount,
    'points' => $points,
    'status' => 'pending',
    'payment_method' => 'manual'
];

$order_id = db_insert('orders', $order);

if ($order_id) {
    echo json_encode(['success' => true, 'order_id' => $order_id]);
} else {
    echo json_encode(['success' => false, 'message' => '创建订单失败']);
}
?>