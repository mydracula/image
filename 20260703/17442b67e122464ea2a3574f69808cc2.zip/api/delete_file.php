<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

// 检查登录
if (!is_logged_in()) {
    echo json_encode(['success' => false, 'message' => '请先登录']);
    exit;
}

$user = get_logged_user();
$data = json_decode(file_get_contents('php://input'), true);

$site_id = $data['site_id'] ?? '';
$file = $data['file'] ?? '';

if (!$site_id || !$file) {
    echo json_encode(['success' => false, 'message' => '参数错误']);
    exit;
}

// 安全检查：防止路径遍历
$file = str_replace(['..', '/', '\\'], '', $file);
if (empty($file)) {
    echo json_encode(['success' => false, 'message' => '文件名不合法']);
    exit;
}

$site = db_get_one('sites', ['id' => $site_id]);

if (!$site || ($site['user_id'] != $user['id'] && !is_admin())) {
    echo json_encode(['success' => false, 'message' => '无权访问']);
    exit;
}

$file_path = UPLOAD_PATH . $site_id . '/' . $file;

if (!file_exists($file_path)) {
    echo json_encode(['success' => false, 'message' => '文件不存在']);
    exit;
}

// 如果是目录，不能直接删除
if (is_dir($file_path)) {
    echo json_encode(['success' => false, 'message' => '不能删除目录']);
    exit;
}

if (unlink($file_path)) {
    // 更新文件列表
    $files = scandir(UPLOAD_PATH . $site_id);
    $files = array_diff($files, ['.', '..']);
    db_update('sites', $site_id, ['files' => array_values($files)]);
    
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => '删除失败，请检查文件权限']);
}
?>