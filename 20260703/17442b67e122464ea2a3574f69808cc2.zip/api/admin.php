<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

// 检查管理员权限
if (!is_admin()) {
    echo json_encode(['success' => false, 'message' => '无权访问']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$action = $data['action'] ?? '';

switch ($action) {
    case 'update_user_status':
        $user_id = $data['user_id'] ?? '';
        $status = $data['status'] ?? '';
        
        if (!$user_id || !in_array($status, ['active', 'banned'])) {
            echo json_encode(['success' => false, 'message' => '参数错误']);
            exit;
        }
        
        if (db_update('users', $user_id, ['status' => $status])) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => '更新失败']);
        }
        break;
        
    case 'process_order':
        $order_id = $data['order_id'] ?? '';
        $status = $data['status'] ?? '';
        
        if (!$order_id || !in_array($status, ['approved', 'rejected'])) {
            echo json_encode(['success' => false, 'message' => '参数错误']);
            exit;
        }
        
        $order = db_get_one('orders', ['id' => $order_id]);
        if (!$order) {
            echo json_encode(['success' => false, 'message' => '订单不存在']);
            exit;
        }
        
        if ($status == 'approved' && $order['status'] == 'pending') {
            // 添加积分
            add_points($order['user_id'], $order['points']);
        }
        
        if (db_update('orders', $order_id, ['status' => $status])) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => '操作失败']);
        }
        break;
        
    case 'delete_order':
        $order_id = $data['order_id'] ?? '';
        
        if (!$order_id) {
            echo json_encode(['success' => false, 'message' => '参数错误']);
            exit;
        }
        
        if (db_delete('orders', $order_id)) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => '删除失败']);
        }
        break;
        
    case 'update_site_status':
        $site_id = $data['site_id'] ?? '';
        $status = $data['status'] ?? '';
        
        if (!$site_id || !in_array($status, ['active', 'disabled'])) {
            echo json_encode(['success' => false, 'message' => '参数错误']);
            exit;
        }
        
        if (db_update('sites', $site_id, ['status' => $status])) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => '更新失败']);
        }
        break;
        
    // 新增：删除用户及其所有网站
    case 'delete_user':
        $user_id = $data['user_id'] ?? '';
        
        if (!$user_id) {
            echo json_encode(['success' => false, 'message' => '参数错误']);
            exit;
        }
        
        // 检查用户是否存在
        $user = db_get_one('users', ['id' => $user_id]);
        if (!$user) {
            echo json_encode(['success' => false, 'message' => '用户不存在']);
            exit;
        }
        
        // 不能删除管理员
        if ($user['role'] == 'admin') {
            echo json_encode(['success' => false, 'message' => '不能删除管理员']);
            exit;
        }
        
        // 获取该用户的所有网站
        $user_sites = db_get_where('sites', ['user_id' => $user_id]);
        
        // 删除用户的网站文件和记录
        foreach ($user_sites as $site) {
            // 删除网站文件目录
            $site_path = UPLOAD_PATH . $site['id'] . '/';
            if (file_exists($site_path)) {
                deleteDirectory($site_path);
            }
            // 删除网站记录
            db_delete('sites', $site['id']);
        }
        
        // 删除用户的订单记录
        db_delete_where('orders', ['user_id' => $user_id]);
        
        // 最后删除用户
        if (db_delete('users', $user_id)) {
            echo json_encode(['success' => true, 'message' => '用户删除成功']);
        } else {
            echo json_encode(['success' => false, 'message' => '删除用户失败']);
        }
        break;
        
    default:
        echo json_encode(['success' => false, 'message' => '未知操作']);
}

// 辅助函数：递归删除目录
function deleteDirectory($dir) {
    if (!file_exists($dir)) {
        return true;
    }
    if (!is_dir($dir)) {
        return unlink($dir);
    }
    $items = scandir($dir);
    foreach ($items as $item) {
        if ($item == '.' || $item == '..') {
            continue;
        }
        $path = $dir . DIRECTORY_SEPARATOR . $item;
        if (is_dir($path)) {
            deleteDirectory($path);
        } else {
            unlink($path);
        }
    }
    return rmdir($dir);
}
?>