<?php
require_once '../includes/config.php';
require_once '../includes/db.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

// 检查登录
if (!is_logged_in()) {
    echo json_encode(['success' => false, 'message' => '请先登录']);
    exit;
}

$user = get_logged_user();
$data = json_decode(file_get_contents('php://input'), true);

$site_id = $data['site_id'] ?? '';
$file = $data['file'] ?? '';

if (!$site_id || !$file) {
    echo json_encode(['success' => false, 'message' => '参数错误']);
    exit;
}

// 安全检查：防止路径遍历
$file = str_replace(['..', '/', '\\'], '', $file);
if (empty($file)) {
    echo json_encode(['success' => false, 'message' => '文件名不合法']);
    exit;
}

$site = db_get_one('sites', ['id' => $site_id]);

if (!$site || ($site['user_id'] != $user['id'] && !is_admin())) {
    echo json_encode(['success' => false, 'message' => '无权访问']);
    exit;
}

$file_path = UPLOAD_PATH . $site_id . '/' . $file;

if (!file_exists($file_path)) {
    echo json_encode(['success' => false, 'message' => '文件不存在']);
    exit;
}

// 如果是目录，不能读取
if (is_dir($file_path)) {
    echo json_encode(['success' => false, 'message' => '不能读取目录']);
    exit;
}

// 检查文件类型
$ext = pathinfo($file, PATHINFO_EXTENSION);
if (!in_array(strtolower($ext), ['html', 'htm', 'css', 'js', 'txt', 'json', 'xml'])) {
    echo json_encode(['success' => false, 'message' => '不支持预览此文件类型']);
    exit;
}

// 检查文件大小（限制为1MB，避免读取大文件）
if (filesize($file_path) > 1024 * 1024) {
    echo json_encode(['success' => false, 'message' => '文件过大，无法编辑']);
    exit;
}

$content = file_get_contents($file_path);

echo json_encode(['success' => true, 'content' => $content]);
?>