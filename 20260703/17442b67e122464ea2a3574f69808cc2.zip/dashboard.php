<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

// 检查登录
if (!is_logged_in()) {
    header('Location: login.php');
    exit;
}

$user = get_logged_user();
$sites = db_get_where('sites', ['user_id' => $user['id']]);
$orders = db_get_where('orders', ['user_id' => $user['id']]);

// 获取最后一次充值时间（冷却时间12小时）
$last_recharge = $user['last_recharge'] ?? 0;
$cooldown_hours = 12;
$cooldown_seconds = $cooldown_hours * 3600;
$can_recharge = (time() - $last_recharge) >= $cooldown_seconds;
$remaining_seconds = $cooldown_seconds - (time() - $last_recharge);
$remaining_hours = floor($remaining_seconds / 3600);
$remaining_minutes = floor(($remaining_seconds % 3600) / 60);

// 检查积分是否足够
$has_enough_points = $user['points'] >= CREATE_COST;
?>
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>我的作品 - 静态网站托管平台</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        /* 淡蓝色背景 */
        body {
            background: linear-gradient(135deg, #e6f0fa 0%, #cce3f0 100%);
            min-height: 100vh;
        }
        
        /* 美化版弹窗样式 */
        .custom-toast {
            position: fixed;
            top: 20px;
            right: 20px;
            min-width: 300px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            padding: 16px 20px;
            transform: translateX(400px);
            transition: transform 0.3s ease;
            z-index: 9999;
            border-left: 4px solid;
            backdrop-filter: blur(10px);
            background: rgba(255,255,255,0.98);
        }
        
        .custom-toast.show {
            transform: translateX(0);
        }
        
        .custom-toast.success {
            border-left-color: #10b981;
        }
        
        .custom-toast.error {
            border-left-color: #ef4444;
        }
        
        .custom-toast.warning {
            border-left-color: #f59e0b;
        }
        
        .custom-toast.info {
            border-left-color: #3b82f6;
        }
        
        .toast-content {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .toast-icon {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            font-weight: bold;
        }
        
        .success .toast-icon {
            background: #10b981;
            color: white;
        }
        
        .error .toast-icon {
            background: #ef4444;
            color: white;
        }
        
        .warning .toast-icon {
            background: #f59e0b;
            color: white;
        }
        
        .info .toast-icon {
            background: #3b82f6;
            color: white;
        }
        
        .toast-message {
            flex: 1;
            font-size: 14px;
            color: #1f2937;
            font-weight: 500;
        }
        
        .toast-close {
            cursor: pointer;
            color: #9ca3af;
            font-size: 20px;
            transition: color 0.2s;
        }
        
        .toast-close:hover {
            color: #4b5563;
        }
        
        /* 美化版确认对话框 */
        .confirm-dialog-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 10000;
            backdrop-filter: blur(4px);
        }
        
        .confirm-dialog {
            background: white;
            border-radius: 24px;
            width: 90%;
            max-width: 400px;
            padding: 32px 24px;
            box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);
            transform: scale(0.9);
            transition: transform 0.2s;
        }
        
        .confirm-dialog.show {
            transform: scale(1);
        }
        
        .confirm-dialog-icon {
            width: 64px;
            height: 64px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 32px;
            background: #fee2e2;
            color: #ef4444;
        }
        
        .confirm-dialog-title {
            font-size: 20px;
            font-weight: 600;
            color: #1f2937;
            text-align: center;
            margin-bottom: 8px;
        }
        
        .confirm-dialog-message {
            font-size: 14px;
            color: #6b7280;
            text-align: center;
            margin-bottom: 24px;
            line-height: 1.6;
        }
        
        .confirm-dialog-actions {
            display: flex;
            gap: 12px;
        }
        
        .confirm-dialog-btn {
            flex: 1;
            padding: 12px;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            border: none;
            transition: all 0.2s;
        }
        
        .confirm-dialog-btn.cancel {
            background: #f3f4f6;
            color: #4b5563;
        }
        
        .confirm-dialog-btn.cancel:hover {
            background: #e5e7eb;
        }
        
        .confirm-dialog-btn.confirm {
            background: #ef4444;
            color: white;
        }
        
        .confirm-dialog-btn.confirm:hover {
            background: #dc2626;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
        }
        
        /* 充值按钮禁用样式 */
        .recharge-btn.disabled,
        .recharge-btn:disabled {
            opacity: 0.5 !important;
            cursor: not-allowed !important;
            background: #9ca3af !important;
            pointer-events: none !important;
        }
        
        .cooldown-tip {
            font-size: 11px;
            color: #f59e0b;
            margin-top: 8px;
            text-align: center;
        }
        
        .disable-message {
            background: #fef3c7;
            border: 1px solid #fde68a;
            border-radius: 12px;
            padding: 12px 16px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .disable-message-icon {
            font-size: 24px;
        }
        
        .disable-message-text {
            flex: 1;
            color: #92400e;
            font-size: 14px;
        }
        
        .disable-message-text strong {
            font-weight: 600;
        }
        
        /* 充值套餐折叠样式 */
        .recharge-packages {
            display: none;
            margin-top: 20px;
        }
        
        .recharge-packages.show {
            display: block;
        }
        
        .toggle-packages-btn {
            background: #3b82f6;
            color: white;
            padding: 8px 20px;
            border-radius: 30px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
            display: inline-block;
            margin-bottom: 15px;
        }
        
        .toggle-packages-btn:hover {
            background: #2563eb;
            transform: translateY(-2px);
        }
        
        .order-id {
            font-size: 12px;
            font-family: monospace;
            max-width: 100px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            display: inline-block;
        }
        
        .create-btn {
            display: inline-block;
        }
    </style>
</head>
<body>
    <div class="min-h-screen">
        <!-- 导航栏 -->
        <nav class="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur">
            <div class="container mx-auto px-4">
                <div class="flex h-16 items-center justify-between">
                    <a href="index.php" class="flex items-center gap-2">
                        <span class="text-xl font-bold text-primary">鸿盟创客静态网站托管</span>
                    </a>
                    
                    <div class="flex items-center gap-4">
                        <a href="logout.php" class="text-sm text-muted-foreground">退出</a>
                    </div>
                </div>
            </div>
        </nav>

        <main class="container mx-auto px-4 py-8">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                <!-- 侧边栏 -->
                <div class="md:col-span-1">
                    <div class="bg-white border rounded-lg p-4">
                        <div class="text-center mb-4">
                            <img src="<?php echo $user['avatar'] ?: 'img/touxiang.png'; ?>" class="w-20 h-20 rounded-full mx-auto mb-2" alt="avatar">
                            <h3 class="font-bold"><?php echo htmlspecialchars($user['username']); ?></h3>
                            <p class="text-sm text-gray-500">积分: <?php echo $user['points']; ?></p>
                        </div>
                        
                        <div class="space-y-1">
                            <a href="dashboard.php" class="block px-3 py-2 bg-primary/10 text-primary rounded">我的作品</a>
                            <a href="create.php" class="block px-3 py-2 hover:bg-gray-100 rounded">创建新网站</a>
                            <a href="javascript:;" onclick="toggleRechargePackages()" class="block px-3 py-2 hover:bg-gray-100 rounded">积分充值</a>
                            <?php if (is_admin()): ?>
                                <div class="border-t pt-2 mt-2">
                                    <a href="admin/index.php" class="block px-3 py-2 bg-red-50 text-red-600 rounded">后台管理</a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- 主要内容 -->
                <div class="md:col-span-3">
                    <!-- 作品列表 -->
                    <div class="bg-white border rounded-lg p-6 mb-6">
                        <h2 class="text-xl font-bold mb-4">我的网站作品 (<?php echo count($sites); ?>)</h2>
                        
                        <?php if (empty($sites)): ?>
                            <div class="text-center py-8 text-gray-500">
                                <p class="mb-4">您还没有创建任何网站</p>
                                <a href="create.php" class="bg-primary text-white px-4 py-2 rounded inline-block">立即创建</a>
                            </div>
                        <?php else: ?>
                            <div class="space-y-4">
                                <?php foreach ($sites as $site): ?>
                                    <div class="border rounded-lg p-4 flex justify-between items-center">
                                        <div>
                                            <h3 class="font-semibold"><?php echo htmlspecialchars($site['title']); ?></h3>
                                            <p class="text-sm text-gray-500">创建于: <?php echo $site['created_at']; ?></p>
                                        </div>
                                        <div class="flex gap-2">
                                            <a href="site.php?id=<?php echo $site['id']; ?>" class="text-primary text-sm hover:underline" target="_blank">查看</a>
                                            <a href="edit.php?id=<?php echo $site['id']; ?>" class="text-gray-600 text-sm hover:underline">编辑</a>
                                            <a href="javascript:;" onclick="showDeleteConfirm('<?php echo $site['id']; ?>')" class="text-red-600 text-sm hover:underline">删除</a>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- 充值记录区域 -->
                    <div id="recharge" class="bg-white border rounded-lg p-6">
                        <h2 class="text-xl font-bold mb-4">积分充值记录</h2>
                        
                        <?php if (!$can_recharge): ?>
                            <div class="disable-message">
                                <div class="disable-message-icon">⏰</div>
                                <div class="disable-message-text">
                                    <strong>充值冷却中</strong><br>
                                    距离下次充值还有 <strong><?php echo $remaining_hours; ?>小时<?php echo $remaining_minutes; ?>分钟</strong>，请稍后再试。
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <!-- 充值套餐（默认隐藏） -->
                        <div id="rechargePackages" class="recharge-packages">
                            <h3 class="font-semibold mb-3">选择充值套餐</h3>
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <!-- 基础套餐 -->
                                <div class="border rounded-lg p-4 text-center">
                                    <h4 class="font-bold">基础套餐</h4>
                                    <p class="text-2xl text-primary font-bold my-2">¥10</p>
                                    <p class="text-sm text-gray-600 mb-3">100 积分</p>
                                    <button onclick="recharge(10, 100)" class="recharge-btn w-full bg-primary text-white py-2 rounded text-sm font-medium <?php echo !$can_recharge ? 'disabled' : ''; ?>" <?php echo !$can_recharge ? 'disabled' : ''; ?>>
                                        <?php echo $can_recharge ? '立即充值' : '冷却中'; ?>
                                    </button>
                                    <?php if (!$can_recharge): ?>
                                        <div class="cooldown-tip">⏰ <?php echo $remaining_hours; ?>小时<?php echo $remaining_minutes; ?>分钟后可充值</div>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- 推荐套餐 -->
                                <div class="border rounded-lg p-4 text-center border-primary relative">
                                    <span class="absolute -top-2 left-1/2 transform -translate-x-1/2 bg-primary text-white px-2 py-0.5 text-xs rounded-full">热门</span>
                                    <h4 class="font-bold mt-2">推荐套餐</h4>
                                    <p class="text-2xl text-primary font-bold my-2">¥50</p>
                                    <p class="text-sm text-gray-600 mb-3">600 积分</p>
                                    <button onclick="recharge(50, 600)" class="recharge-btn w-full bg-primary text-white py-2 rounded text-sm font-medium <?php echo !$can_recharge ? 'disabled' : ''; ?>" <?php echo !$can_recharge ? 'disabled' : ''; ?>>
                                        <?php echo $can_recharge ? '立即充值' : '冷却中'; ?>
                                    </button>
                                    <?php if (!$can_recharge): ?>
                                        <div class="cooldown-tip">⏰ <?php echo $remaining_hours; ?>小时<?php echo $remaining_minutes; ?>分钟后可充值</div>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- 高级套餐 -->
                                <div class="border rounded-lg p-4 text-center">
                                    <h4 class="font-bold">高级套餐</h4>
                                    <p class="text-2xl text-primary font-bold my-2">¥100</p>
                                    <p class="text-sm text-gray-600 mb-3">1200 积分</p>
                                    <button onclick="recharge(100, 1200)" class="recharge-btn w-full bg-primary text-white py-2 rounded text-sm font-medium <?php echo !$can_recharge ? 'disabled' : ''; ?>" <?php echo !$can_recharge ? 'disabled' : ''; ?>>
                                        <?php echo $can_recharge ? '立即充值' : '冷却中'; ?>
                                    </button>
                                    <?php if (!$can_recharge): ?>
                                        <div class="cooldown-tip">⏰ <?php echo $remaining_hours; ?>小时<?php echo $remaining_minutes; ?>分钟后可充值</div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        
                        <h3 class="font-semibold mb-3 mt-4">历史订单</h3>
                        <?php if (empty($orders)): ?>
                            <p class="text-gray-500 text-center py-4">暂无充值记录</p>
                        <?php else: ?>
                            <table class="w-full">
                                <thead>
                                    <tr class="border-b">
                                        <th class="text-left py-2">订单号</th>
                                        <th class="text-left py-2">金额</th>
                                        <th class="text-left py-2">积分</th>
                                        <th class="text-left py-2">状态</th>
                                        <th class="text-left py-2">时间</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($orders as $order): ?>
                                        <tr class="border-b">
                                            <td class="py-2 text-sm">
                                                <span class="order-id" title="<?php echo $order['id']; ?>"><?php echo substr($order['id'], 0, 8); ?>...</span>
                                            </td>
                                            <td class="py-2 text-sm">¥<?php echo $order['amount']; ?></td>
                                            <td class="py-2 text-sm"><?php echo $order['points']; ?></td>
                                            <td class="py-2 text-sm">
                                                <?php if ($order['status'] == 'pending'): ?>
                                                    <span class="text-yellow-600">⏳ 待审核</span>
                                                <?php elseif ($order['status'] == 'approved'): ?>
                                                    <span class="text-green-600">✅ 已通过</span>
                                                <?php else: ?>
                                                    <span class="text-red-600">❌ 已拒绝</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="py-2 text-sm"><?php echo date('Y-m-d', strtotime($order['created_at'])); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    </div>
    
    <!-- 自定义确认对话框 -->
    <div class="confirm-dialog-overlay" id="confirmDialog">
        <div class="confirm-dialog" id="confirmDialogBox">
            <div class="confirm-dialog-icon">⚠️</div>
            <div class="confirm-dialog-title">确认删除</div>
            <div class="confirm-dialog-message" id="confirmMessage">确定要删除这个网站吗？此操作不可撤销！</div>
            <div class="confirm-dialog-actions">
                <button class="confirm-dialog-btn cancel" onclick="hideConfirmDialog()">取 消</button>
                <button class="confirm-dialog-btn confirm" id="confirmDeleteBtn">确 认 删 除</button>
            </div>
        </div>
    </div>
    
    <!-- 自定义提示框容器 -->
    <div id="toastContainer"></div>
    
    <script>
    let isProcessing = false;
    let canRecharge = <?php echo $can_recharge ? 'true' : 'false'; ?>;
    let currentDeleteId = null;
    
    function showToast(message, type = 'info') {
        const container = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.className = `custom-toast ${type}`;
        
        const icons = { success: '✓', error: '✗', warning: '⚠', info: 'ℹ' };
        
        toast.innerHTML = `
            <div class="toast-content">
                <div class="toast-icon">${icons[type] || 'ℹ'}</div>
                <div class="toast-message">${message}</div>
                <div class="toast-close" onclick="this.parentElement.parentElement.remove()">×</div>
            </div>
        `;
        
        container.appendChild(toast);
        
        setTimeout(() => { toast.classList.add('show'); }, 10);
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => { if (toast.parentElement) toast.remove(); }, 300);
        }, 3000);
    }
    
    // 切换充值套餐显示/隐藏
    function toggleRechargePackages() {
        const packages = document.getElementById('rechargePackages');
        if (packages.classList.contains('show')) {
            packages.classList.remove('show');
        } else {
            packages.classList.add('show');
            // 滚动到充值区域
            document.getElementById('recharge').scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }
    
    function showDeleteConfirm(id) {
        currentDeleteId = id;
        const dialog = document.getElementById('confirmDialog');
        const dialogBox = document.getElementById('confirmDialogBox');
        dialog.style.display = 'flex';
        setTimeout(() => dialogBox.classList.add('show'), 10);
    }
    
    function hideConfirmDialog() {
        const dialogBox = document.getElementById('confirmDialogBox');
        dialogBox.classList.remove('show');
        setTimeout(() => {
            document.getElementById('confirmDialog').style.display = 'none';
        }, 200);
        currentDeleteId = null;
    }
    
    function deleteSite() {
        if (!currentDeleteId) return;
        
        const confirmBtn = document.getElementById('confirmDeleteBtn');
        confirmBtn.disabled = true;
        confirmBtn.textContent = '删除中...';
        
        showToast('正在删除网站...', 'info');
        
        // 使用相对路径，确保API文件位置正确
        fetch('api/delete_site.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({id: currentDeleteId})
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('HTTP error ' + response.status);
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                showToast('网站删除成功', 'success');
                setTimeout(() => location.reload(), 1000);
            } else {
                showToast(data.message || '删除失败', 'error');
                confirmBtn.disabled = false;
                confirmBtn.textContent = '确 认 删 除';
                hideConfirmDialog();
            }
        })
        .catch(error => {
            console.error('Delete error:', error);
            showToast('网络错误，请稍后重试', 'error');
            confirmBtn.disabled = false;
            confirmBtn.textContent = '确 认 删 除';
            hideConfirmDialog();
        });
    }
    
    document.getElementById('confirmDeleteBtn').addEventListener('click', deleteSite);
    
    document.getElementById('confirmDialog').addEventListener('click', function(e) {
        if (e.target === this) {
            hideConfirmDialog();
        }
    });
    
    function recharge(amount, points) {
        if (!canRecharge) {
            showToast('充值冷却中，请 <?php echo $remaining_hours; ?>小时<?php echo $remaining_minutes; ?>分钟后再试', 'warning');
            return;
        }
        
        if (isProcessing) {
            showToast('正在处理中，请稍后...', 'info');
            return;
        }
        
        isProcessing = true;
        
        const btns = document.querySelectorAll('.recharge-btn');
        btns.forEach(btn => {
            btn.disabled = true;
            btn.classList.add('disabled');
        });
        
        showToast('正在提交充值申请...', 'info');
        
        fetch('api/recharge.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({amount: amount, points: points})
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast('充值申请已提交，12小时内无法再次充值', 'success');
                setTimeout(() => location.reload(), 1500);
            } else {
                showToast(data.message || '充值失败', 'error');
                btns.forEach(btn => {
                    btn.disabled = false;
                    btn.classList.remove('disabled');
                });
                isProcessing = false;
            }
        })
        .catch(error => {
            console.error('Recharge error:', error);
            showToast('网络错误，请稍后重试', 'error');
            btns.forEach(btn => {
                btn.disabled = false;
                btn.classList.remove('disabled');
            });
            isProcessing = false;
        });
    }
    </script>
</body>
</html>