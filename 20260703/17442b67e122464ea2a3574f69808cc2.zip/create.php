<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

// 检查登录
if (!is_logged_in()) {
    header('Location: login.php');
    exit;
}

$user = get_logged_user();
$error = '';

// 检查积分
if ($user['points'] < CREATE_COST) {
    $error = '积分不足，需要 ' . CREATE_COST . ' 积分才能创建网站，请先充值';
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && !$error) {
    $title = $_POST['title'] ?? '';
    $description = $_POST['description'] ?? '';
    $uuid = $_POST['uuid'] ?? uniqid();
    $is_showcase = isset($_POST['is_showcase']) ? 1 : 0;
    
    // 验证标题长度 (最多15个字符)
    $title = trim($title);
    if (mb_strlen($title) > 15) {
        $error = '网站名称不能超过15个字符，当前长度：' . mb_strlen($title);
    }
    
    // 验证描述长度 (最多50个字符)
    $description = trim($description);
    if (mb_strlen($description) > 50) {
        $error = '网站描述不能超过50个字符，当前长度：' . mb_strlen($description);
    }
    
    // 验证 UUID
    $uuid = preg_replace('/[^a-zA-Z0-9]/', '', $uuid);
    if (empty($uuid)) {
        $uuid = uniqid();
    }
    
    // 检查 UUID 是否已存在
    $existing = db_get_one('sites', ['uuid' => $uuid]);
    if ($existing) {
        $error = '访问地址已存在，请修改';
    } elseif (empty($title)) {
        $error = '请输入网站名称';
    }
    
    if (!$error) {
        // 扣除积分
        if (deduct_points($user['id'], CREATE_COST)) {
            // 创建网站记录
            $site = [
                'user_id' => $user['id'],
                'title' => $title,
                'description' => $description,
                'uuid' => $uuid,
                'files' => [],
                'status' => 'active',
                'views' => 0,
                'is_showcase' => $is_showcase  // 是否展示在首页他人作品区
            ];
            
            $site_id = db_insert('sites', $site);
            
            if ($site_id) {
                // 创建网站目录
                $site_path = UPLOAD_PATH . $site_id . '/';
                if (!file_exists($site_path)) {
                    mkdir($site_path, 0777, true);
                }
                
                header('Location: edit.php?id=' . $site_id);
                exit;
            } else {
                // 返还积分
                add_points($user['id'], CREATE_COST);
                $error = '创建失败，请稍后重试';
            }
        } else {
            $error = '积分扣除失败';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>创建网站 - 静态网站托管平台</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        /* 额外样式 */
        .checkbox-wrapper {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px;
            background: #f8fafc;
            border-radius: 8px;
            border: 1px solid #e2e8f0;
            margin-bottom: 20px;
        }
        
        .checkbox-wrapper input[type="checkbox"] {
            width: 18px;
            height: 18px;
            cursor: pointer;
            accent-color: #3b82f6;
        }
        
        .checkbox-wrapper label {
            cursor: pointer;
            font-weight: 500;
            color: #1e293b;
        }
        
        .checkbox-desc {
            font-size: 12px;
            color: #64748b;
            margin-left: 28px;
            margin-top: -8px;
            margin-bottom: 12px;
        }
        
        .char-counter {
            font-size: 12px;
            text-align: right;
            margin-top: 4px;
            color: #94a3b8;
        }
        
        .char-counter.warning {
            color: #eab308;
        }
        
        .char-counter.danger {
            color: #ef4444;
        }
        
        .info-box {
            background: #eff6ff;
            border-left: 4px solid #3b82f6;
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .info-box-title {
            font-weight: 600;
            color: #1e40af;
            margin-bottom: 8px;
        }
        
        .info-box-content {
            color: #1e293b;
            font-size: 14px;
        }
    </style>
    <script>
        function updateTitleCount() {
            const input = document.getElementById('title');
            const counter = document.getElementById('titleCount');
            const length = input.value.length;
            const max = 15;
            counter.textContent = length + '/' + max;
            
            if (length > max) {
                counter.classList.add('danger');
                counter.classList.remove('warning');
            } else if (length >= max - 3) {
                counter.classList.add('warning');
                counter.classList.remove('danger');
            } else {
                counter.classList.remove('warning', 'danger');
            }
        }
        
        function updateDescCount() {
            const textarea = document.getElementById('description');
            const counter = document.getElementById('descCount');
            const length = textarea.value.length;
            const max = 50;
            counter.textContent = length + '/' + max;
            
            if (length > max) {
                counter.classList.add('danger');
                counter.classList.remove('warning');
            } else if (length >= max - 10) {
                counter.classList.add('warning');
                counter.classList.remove('danger');
            } else {
                counter.classList.remove('warning', 'danger');
            }
        }
        
        function validateForm() {
            const title = document.getElementById('title').value;
            const description = document.getElementById('description').value;
            
            if (title.length > 15) {
                alert('网站名称不能超过15个字符，当前长度：' + title.length);
                return false;
            }
            
            if (description.length > 50) {
                alert('网站描述不能超过50个字符，当前长度：' + description.length);
                return false;
            }
            
            return true;
        }
    </script>
</head>
<body>
    <div class="min-h-screen bg-background">
        <nav class="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur">
            <div class="container mx-auto px-4">
                <div class="flex h-16 items-center justify-between">
                    <a href="index.php" class="flex items-center gap-2">
                        <span class="text-xl font-bold text-primary">静态网站托管</span>
                    </a>
                    <div class="flex items-center gap-4">
                        <span class="text-sm">积分: <?php echo $user['points']; ?></span>
                        <a href="dashboard.php" class="text-sm">返回仪表板</a>
                    </div>
                </div>
            </div>
        </nav>

        <main class="container mx-auto px-4 py-8 max-w-3xl">
            <h1 class="text-3xl font-bold mb-6">创建新网站</h1>
            
            <!-- 提示信息 -->
            <div class="info-box">
                <div class="info-box-title">
                    <span>📌 填写说明</span>
                </div>
                <div class="info-box-content">
                    <ul class="list-disc list-inside space-y-1">
                        <li>网站名称最多 <strong>15个字符</strong></li>
                        <li>网站描述最多 <strong>50个字符</strong></li>
                        <li>勾选"展示到首页"后，您的作品将出现在首页他人作品区</li>
                    </ul>
                </div>
            </div>
            
            <?php if ($error): ?>
                <div class="bg-red-100 text-red-700 p-4 rounded mb-6">
                    <?php echo $error; ?>
                    <?php if (strpos($error, '积分不足') !== false): ?>
                        <a href="dashboard.php#recharge" class="ml-2 text-primary underline">去充值</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <?php if (!$error): ?>
            <div class="bg-white border rounded-lg p-6">
                <form method="POST" action="" onsubmit="return validateForm()">
                    <div class="mb-4">
                        <label class="block text-sm font-medium mb-2">网站名称 <span class="text-red-500">*</span></label>
                        <input type="text" name="title" id="title" required maxlength="15"
                               class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:border-primary"
                               oninput="updateTitleCount()">
                        <div class="char-counter" id="titleCount">0/15</div>
                        <p class="text-xs text-gray-500 mt-1">您的网站标题，将显示在作品列表中（最多15个字符）</p>
                    </div>
                    
                    <div class="mb-4">
                        <label class="block text-sm font-medium mb-2">网站描述</label>
                        <textarea name="description" id="description" rows="3" maxlength="50"
                                  class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:border-primary"
                                  oninput="updateDescCount()"></textarea>
                        <div class="char-counter" id="descCount">0/50</div>
                        <p class="text-xs text-gray-500 mt-1">简短描述您的网站内容（可选，最多50个字符）</p>
                    </div>
                    
                    <div class="mb-4">
                        <label class="block text-sm font-medium mb-2">访问地址 (UUID)</label>
                        <input type="text" name="uuid" pattern="[a-zA-Z0-9]+" 
                               class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:border-primary"
                               placeholder="留空自动生成，只能包含字母和数字">
                        <p class="text-xs text-gray-500 mt-1">自定义访问路径，只能包含字母和数字，留空将自动生成</p>
                    </div>
                    
                    <!-- 是否展示到首页他人作品区 -->
                    <div class="checkbox-wrapper">
                        <input type="checkbox" name="is_showcase" id="is_showcase" value="1">
                        <label for="is_showcase">✨ 展示到首页他人作品区</label>
                    </div>
                    <div class="checkbox-desc">
                        勾选后，您的作品将展示在首页的"他人作品"区域，让更多人看到您的创作。
                    </div>
                    
                    <div class="bg-blue-50 border border-blue-200 rounded p-4 mb-6">
                        <p class="text-sm text-blue-800">
                            <strong>创建需要消耗 <?php echo CREATE_COST; ?> 积分</strong><br>
                            当前积分: <?php echo $user['points']; ?>，创建后剩余: <?php echo $user['points'] - CREATE_COST; ?>
                        </p>
                    </div>
                    
                    <button type="submit" 
                            class="w-full bg-primary text-white py-3 rounded-lg font-medium hover:bg-primary/90 transition">
                        创建网站（消耗 <?php echo CREATE_COST; ?> 积分）
                    </button>
                </form>
            </div>
            <?php endif; ?>
        </main>
    </div>
    
    <script>
        // 初始化字符计数
        updateTitleCount();
        updateDescCount();
    </script>
</body>
</html>