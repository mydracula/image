<?php
require_once 'includes/config.php';
require_once 'includes/db.php';
require_once 'includes/auth.php';

// 检查登录
if (!is_logged_in()) {
    header('Location: login.php');
    exit;
}

$user = get_logged_user();
$site_id = $_GET['id'] ?? '';

if (!$site_id) {
    header('Location: dashboard.php');
    exit;
}

$site = db_get_one('sites', ['id' => $site_id]);

// 检查权限
if (!$site || ($site['user_id'] != $user['id'] && !is_admin())) {
    header('Location: dashboard.php');
    exit;
}

$site_path = UPLOAD_PATH . $site_id . '/';

// 获取当前文件列表
if (!file_exists($site_path)) {
    mkdir($site_path, 0777, true);
}
$files = scandir($site_path);
$files = array_diff($files, ['.', '..']);
$files = array_values($files);
$html_files_count = count(array_filter($files, function($file) {
    return preg_match('/\.(html?)$/i', $file);
}));

// 检查是否存在 index.html
$has_index = file_exists($site_path . 'index.html');

// 处理粘贴HTML代码
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['paste_html'])) {
    $html_content = $_POST['html_code'] ?? '';
    
    if (!empty(trim($html_content))) {
        $index_path = $site_path . 'index.html';
        
        // 如果已存在 index.html，检查文件数量限制
        if (!$has_index) {
            if ($html_files_count >= 10) {
                $error_message = "最多只能上传 10 个 HTML 文件，当前已有 {$html_files_count} 个";
                header('Location: edit.php?id=' . $site_id . '&error=' . urlencode($error_message));
                exit;
            }
        }
        
        if (file_put_contents($index_path, $html_content) !== false) {
            // 更新文件列表
            $files = scandir($site_path);
            $files = array_diff($files, ['.', '..']);
            db_update('sites', $site_id, ['files' => array_values($files)]);
            
            header('Location: edit.php?id=' . $site_id . '&success=index_created');
            exit;
        } else {
            $error_message = "创建 index.html 失败，请检查目录权限";
        }
    } else {
        $error_message = "请输入 HTML 代码";
    }
}

// 处理文件上传
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['files'])) {
    $uploaded_files = [];
    $total_files = count($_FILES['files']['name']);
    $allowed_extensions = ['html', 'htm'];
    
    // 检查文件数量限制
    $new_html_files = 0;
    for ($i = 0; $i < $total_files; $i++) {
        if ($_FILES['files']['error'][$i] == 0) {
            $file_name = $_FILES['files']['name'][$i];
            $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
            if (in_array($file_ext, $allowed_extensions)) {
                $new_html_files++;
            }
        }
    }
    
    if ($html_files_count + $new_html_files > 10) {
        $error_message = "最多只能上传 10 个 HTML 文件，当前已有 {$html_files_count} 个";
        header('Location: edit.php?id=' . $site_id . '&error=' . urlencode($error_message));
        exit;
    }
    
    for ($i = 0; $i < $total_files; $i++) {
        if ($_FILES['files']['error'][$i] == 0) {
            $file_name = $_FILES['files']['name'][$i];
            $file_tmp = $_FILES['files']['tmp_name'][$i];
            $file_size = $_FILES['files']['size'][$i];
            $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
            
            // 检查文件类型
            if (!in_array($file_ext, $allowed_extensions)) {
                continue;
            }
            
            // 检查文件大小 (3MB)
            if ($file_size > 3 * 1024 * 1024) {
                continue;
            }
            
            // 安全处理文件名
            $file_name = preg_replace('/[^a-zA-Z0-9_.-]/', '_', $file_name);
            
            $target_path = $site_path . $file_name;
            
            // 创建目录
            $dir = dirname($target_path);
            if (!file_exists($dir)) {
                mkdir($dir, 0777, true);
            }
            
            if (move_uploaded_file($file_tmp, $target_path)) {
                $uploaded_files[] = $file_name;
            }
        }
    }
    
    // 更新文件列表
    $files = scandir($site_path);
    $files = array_diff($files, ['.', '..']);
    db_update('sites', $site_id, ['files' => array_values($files)]);
    
    header('Location: edit.php?id=' . $site_id);
    exit;
}

// 获取错误信息
$error_message = $_GET['error'] ?? '';
$success_message = $_GET['success'] ?? '';

// 修复：构建正确的网站访问URL
$site_url = SITE_URL . '/site.php?id=' . $site_id;
// 如果路径重复，避免双斜杠
$site_url = str_replace('//', '/', $site_url);
$site_url = str_replace(':/', '://', $site_url); // 修复 http:// 的情况
?>
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>编辑网站 - <?php echo htmlspecialchars($site['title']); ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        /* 美化版样式 - 保持您之前的美化样式 */
        :root {
            --primary: #3b82f6;
            --primary-dark: #2563eb;
            --success: #10b981;
            --danger: #ef4444;
            --warning: #f59e0b;
            --gray-50: #f9fafb;
            --gray-100: #f3f4f6;
            --gray-200: #e5e7eb;
            --gray-300: #d1d5db;
            --gray-400: #9ca3af;
            --gray-500: #6b7280;
            --gray-600: #4b5563;
            --gray-700: #374151;
            --gray-800: #1f2937;
            --gray-900: #111827;
        }

        /* 自定义提示框 */
        .custom-toast {
            position: fixed;
            top: 20px;
            right: 20px;
            min-width: 280px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            padding: 16px 20px;
            transform: translateX(400px);
            transition: transform 0.3s ease;
            z-index: 9999;
            border-left: 4px solid;
            backdrop-filter: blur(10px);
        }
        
        .custom-toast.show {
            transform: translateX(0);
        }
        
        .custom-toast.success {
            border-left-color: var(--success);
        }
        
        .custom-toast.error {
            border-left-color: var(--danger);
        }
        
        .custom-toast.info {
            border-left-color: var(--primary);
        }
        
        .toast-content {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .toast-icon {
            width: 24px;
            height: 24px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
        }
        
        .success .toast-icon {
            background: var(--success);
            color: white;
        }
        
        .error .toast-icon {
            background: var(--danger);
            color: white;
        }
        
        .info .toast-icon {
            background: var(--primary);
            color: white;
        }
        
        .toast-message {
            flex: 1;
            font-size: 14px;
            color: var(--gray-800);
            font-weight: 500;
        }
        
        .toast-close {
            cursor: pointer;
            color: var(--gray-400);
            font-size: 18px;
            transition: color 0.2s;
        }
        
        .toast-close:hover {
            color: var(--gray-600);
        }

        /* 上传区域美化 */
        .upload-area {
            border: 2px dashed var(--gray-300);
            border-radius: 12px;
            padding: 24px;
            text-align: center;
            background: var(--gray-50);
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .upload-area:hover {
            border-color: var(--primary);
            background: #f0f9ff;
        }
        
        .upload-area.dragover {
            border-color: var(--primary);
            background: #e0f2fe;
            transform: scale(1.02);
        }
        
        .upload-icon {
            font-size: 40px;
            color: var(--gray-400);
            margin-bottom: 12px;
        }
        
        .upload-text {
            font-size: 14px;
            color: var(--gray-500);
        }
        
        .upload-text strong {
            color: var(--primary);
        }
        
        .file-info {
            margin-top: 12px;
            padding: 12px;
            background: white;
            border-radius: 8px;
            border: 1px solid var(--gray-200);
            display: none;
        }
        
        .file-info.show {
            display: block;
        }

        /* 按钮美化 */
        .btn {
            padding: 8px 16px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.2s;
            cursor: pointer;
            border: none;
        }
        
        .btn-primary {
            background: var(--primary);
            color: white;
        }
        
        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-1px);
            box-shadow: 0 4px 6px -1px rgba(59, 130, 246, 0.2);
        }
        
        .btn-outline {
            background: white;
            border: 1px solid var(--gray-300);
            color: var(--gray-700);
        }
        
        .btn-outline:hover {
            background: var(--gray-50);
            border-color: var(--primary);
            color: var(--primary);
        }
        
        .btn-sm {
            padding: 4px 12px;
            font-size: 12px;
        }

        /* 文件列表美化 */
        .file-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px;
            border-radius: 8px;
            background: var(--gray-50);
            margin-bottom: 6px;
            transition: all 0.2s;
        }
        
        .file-item:hover {
            background: var(--gray-100);
            transform: translateX(4px);
        }
        
        .file-actions {
            display: flex;
            gap: 8px;
        }
        
        .file-action-btn {
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 12px;
            cursor: pointer;
            transition: all 0.2s;
            background: white;
            border: 1px solid var(--gray-200);
            text-decoration: none;
            color: var(--gray-600);
        }
        
        .file-action-btn:hover {
            background: var(--gray-100);
        }
        
        .file-action-btn.edit:hover {
            background: #dbeafe;
            border-color: var(--primary);
            color: var(--primary-dark);
        }
        
        .file-action-btn.delete:hover {
            background: #fee2e2;
            border-color: #fecaca;
            color: var(--danger);
        }
        
        .file-action-btn.view:hover {
            background: #f0fdf4;
            border-color: #86efac;
            color: #166534;
        }

        /* 卡片美化 */
        .card {
            background: white;
            border-radius: 16px;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .card-header {
            padding: 20px;
            border-bottom: 1px solid var(--gray-200);
            background: var(--gray-50);
        }
        
        .card-body {
            padding: 20px;
        }

        /* 选择器美化 */
        .custom-select {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid var(--gray-300);
            border-radius: 8px;
            font-size: 14px;
            color: var(--gray-700);
            background: white;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .custom-select:hover {
            border-color: var(--primary);
        }
        
        .custom-select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        /* 编辑器美化 - 默认收起 */
        .editor-container {
            margin-top: 20px;
            transition: all 0.3s ease;
        }
        
        .editor-container.collapsed {
            display: none;
        }
        
        .editor-toggle {
            display: flex;
            align-items: center;
            justify-content: space-between;
            cursor: pointer;
            padding: 12px 16px;
            background: var(--gray-50);
            border-radius: 8px;
            border: 1px solid var(--gray-200);
            margin-bottom: 10px;
        }
        
        .editor-toggle:hover {
            background: var(--gray-100);
        }
        
        .toggle-icon {
            transition: transform 0.3s ease;
        }
        
        .toggle-icon.expanded {
            transform: rotate(180deg);
        }
        
        .code-editor {
            width: 100%;
            padding: 16px;
            border: 1px solid var(--gray-300);
            border-radius: 8px;
            font-family: 'Fira Code', monospace;
            font-size: 13px;
            line-height: 1.6;
            background: #1e1e1e;
            color: #d4d4d4;
            resize: vertical;
        }
        
        .code-editor:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        /* 粘贴区域美化 */
        .paste-section {
            margin-bottom: 20px;
        }
        
        .paste-title {
            font-weight: 600;
            color: var(--gray-700);
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .paste-textarea {
            width: 100%;
            padding: 16px;
            border: 1px solid var(--gray-300);
            border-radius: 8px;
            font-family: 'Fira Code', monospace;
            font-size: 13px;
            line-height: 1.6;
            background: var(--gray-50);
            color: var(--gray-800);
            resize: vertical;
            margin-bottom: 10px;
        }
        
        .paste-textarea:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        /* 提示框美化 */
        .info-box {
            background: #eff6ff;
            border-left: 4px solid var(--primary);
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .info-box-title {
            font-weight: 600;
            color: #1e40af;
            margin-bottom: 8px;
        }

        /* 大小指示器 */
        .size-indicator {
            display: inline-block;
            padding: 2px 6px;
            background: var(--gray-100);
            border-radius: 4px;
            font-size: 11px;
            color: var(--gray-500);
            margin-left: 6px;
        }

        /* 导航栏美化 */
        .navbar {
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
            border-bottom: 1px solid rgba(59, 130, 246, 0.08);
        }
        
        .navbar-brand {
            font-size: 1.5rem;
            font-weight: 700;
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            position: relative;
            padding-left: 12px;
        }
        
        .navbar-brand::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 4px;
            height: 24px;
            background: linear-gradient(135deg, var(--primary), #8b5cf6);
            border-radius: 4px;
        }
        
        .points-badge {
            background: #f0f9ff;
            color: var(--primary);
            padding: 6px 16px;
            border-radius: 30px;
            font-size: 14px;
            font-weight: 600;
            border: 1px solid rgba(59, 130, 246, 0.2);
        }
        
        .back-link {
            color: var(--gray-500);
            text-decoration: none;
            font-size: 14px;
            padding: 8px 16px;
            border-radius: 30px;
            transition: all 0.2s;
        }
        
        .back-link:hover {
            background: white;
            color: var(--primary);
        }

        /* 页面标题美化 */
        .page-title {
            font-size: 2.5rem;
            font-weight: 700;
            background: linear-gradient(135deg, #1e293b 0%, #334155 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 8px;
        }

        /* 复制按钮 - 修复 */
        .url-container {
            display: flex;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
            background: var(--gray-50);
            padding: 12px 16px;
            border-radius: 12px;
            border: 1px solid var(--gray-200);
        }
        
        .url-label {
            color: var(--gray-500);
            font-size: 14px;
            font-weight: 500;
        }
        
        .url-text {
            color: var(--primary);
            text-decoration: none;
            font-size: 14px;
            word-break: break-all;
            flex: 1;
        }
        
        .url-text:hover {
            text-decoration: underline;
        }
        
        .btn-copy {
            background: white;
            border: 1px solid var(--gray-200);
            color: var(--gray-600);
            padding: 6px 16px;
            border-radius: 30px;
            font-size: 13px;
            cursor: pointer;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        
        .btn-copy:hover {
            background: #f0f9ff;
            border-color: var(--primary);
            color: var(--primary);
        }
        
        .btn-copy.copied {
            background: var(--success);
            border-color: var(--success);
            color: white;
        }

        /* 错误提示 */
        .error-box {
            background: #fee2e2;
            border-left: 4px solid var(--danger);
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            color: #991b1b;
        }

        /* 成功提示 */
        .success-box {
            background: #d1fae5;
            border-left: 4px solid var(--success);
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            color: #065f46;
        }

        /* 文件计数器 */
        .file-counter {
            display: inline-block;
            padding: 4px 10px;
            background: var(--primary);
            color: white;
            border-radius: 20px;
            font-size: 12px;
            margin-left: 10px;
        }

        /* 手机适配 */
        @media (max-width: 768px) {
            .page-title {
                font-size: 2rem;
            }
            
            .navbar-brand {
                font-size: 1.2rem;
            }
            
            .points-badge {
                padding: 4px 12px;
                font-size: 12px;
            }
            
            .url-container {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .btn-copy {
                align-self: flex-end;
            }
        }

        /* 标签页切换 */
        .tab-container {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            border-bottom: 1px solid var(--gray-200);
            padding-bottom: 10px;
        }
        
        .tab-btn {
            padding: 8px 20px;
            border-radius: 30px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            background: white;
            border: 1px solid var(--gray-200);
            color: var(--gray-600);
        }
        
        .tab-btn:hover {
            border-color: var(--primary);
            color: var(--primary);
        }
        
        .tab-btn.active {
            background: var(--primary);
            border-color: var(--primary);
            color: white;
        }
        
        .tab-content {
            display: none;
        }
        
        .tab-content.active {
            display: block;
        }
        
        /* 编辑器区域ID用于滚动 */
        #editor-section {
            scroll-margin-top: 100px;
        }
    </style>
</head>
<body>
    <div class="min-h-screen bg-background">
        <!-- 美化后的导航栏 -->
        <nav class="navbar sticky top-0 z-50 w-full">
            <div class="container mx-auto px-4">
                <div class="flex h-16 items-center justify-between">
                    <a href="index.php" class="navbar-brand flex items-center gap-2">
                        静态网站托管
                    </a>
                    <div class="flex items-center gap-3">
                        <span class="points-badge">⚡ 积分: <?php echo $user['points']; ?></span>
                        <a href="dashboard.php" class="back-link">← 返回仪表板</a>
                    </div>
                </div>
            </div>
        </nav>

        <main class="container mx-auto px-4 py-8">
            <!-- 页面标题 -->
            <div class="mb-8">
                <h1 class="page-title"><?php echo htmlspecialchars($site['title']); ?></h1>
                
                <!-- 修复后的URL显示区域 -->
                <div class="url-container">
                    <span class="url-label">🌐 网站地址：</span>
                    <a href="site.php?id=<?php echo $site_id; ?>" target="_blank" class="url-text" id="siteUrl">
                        <?php echo $site_url; ?>
                    </a>
                    <button class="btn-copy" onclick="copySiteUrl()" id="copyUrlBtn">
                        <span>📋</span> 复制链接
                    </button>
                </div>
            </div>
            
            <?php if ($error_message): ?>
                <div class="error-box">
                    <strong>⚠️ <?php echo htmlspecialchars($error_message); ?></strong>
                </div>
            <?php endif; ?>
            
            <?php if ($success_message == 'index_created'): ?>
                <div class="success-box">
                    <strong>✅ index.html 创建成功！</strong>
                </div>
            <?php endif; ?>
            
            <!-- 提示信息 -->
            <div class="info-box">
                <div class="info-box-title">
                    <span>📌 温馨提示</span>
                    <span class="file-counter">HTML文件: <?php echo $html_files_count; ?>/10</span>
                </div>
                <div class="info-box-content">
                    <ul class="list-disc list-inside space-y-1">
                        <li>仅支持上传 <strong>.html</strong> 文件，单个文件最大 <strong>3MB</strong></li>
                        <li>最多允许上传 <strong>10 个 HTML 文件</strong>（当前已有 <?php echo $html_files_count; ?> 个）</li>
                        <li>可以通过"粘贴代码"快速创建 index.html</li>
                        <li>点击文件列表的"编辑"按钮可以编辑文件</li>
                    </ul>
                </div>
            </div>
            
            <!-- 标签页切换 -->
            <div class="tab-container">
                <button class="tab-btn active" onclick="switchTab('upload')" id="tabUploadBtn">📤 上传文件</button>
                <button class="tab-btn" onclick="switchTab('paste')" id="tabPasteBtn">📋 粘贴代码</button>
            </div>
            
            <!-- 上传文件标签页 -->
            <div id="tabUpload" class="tab-content active">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <!-- 文件列表 -->
                    <div class="md:col-span-1">
                        <div class="card">
                            <div class="card-header">
                                <h2 class="font-bold flex items-center gap-2">
                                    <span>📁</span> 文件列表
                                    <span class="size-indicator">3MB 限制</span>
                                </h2>
                            </div>
                            <div class="card-body">
                                <?php if (empty($files)): ?>
                                    <div class="text-center py-8 text-gray-400">
                                        <div class="text-4xl mb-2">📂</div>
                                        <p class="text-sm">暂无文件</p>
                                    </div>
                                <?php else: ?>
                                    <div class="space-y-1 max-h-96 overflow-y-auto pr-2">
                                        <?php foreach ($files as $file): 
                                            $file_size = file_exists($site_path . $file) ? filesize($site_path . $file) : 0;
                                            $file_size_formatted = $file_size > 1024 ? round($file_size / 1024, 1) . 'KB' : $file_size . 'B';
                                            $is_editable = preg_match('/\.(html?|css|js|txt)$/i', $file);
                                        ?>
                                            <div class="file-item">
                                                <div class="flex items-center flex-1 min-w-0">
                                                    <span class="mr-2">📄</span>
                                                    <span class="truncate text-sm" title="<?php echo $file; ?>"><?php echo $file; ?></span>
                                                    <span class="size-indicator ml-2"><?php echo $file_size_formatted; ?></span>
                                                </div>
                                                <div class="file-actions">
                                                    <a href="data/uploads/<?php echo $site_id; ?>/<?php echo urlencode($file); ?>" target="_blank" class="file-action-btn view">查看</a>
                                                    <?php if ($is_editable): ?>
                                                        <a href="javascript:void(0);" onclick="loadAndEdit('<?php echo addslashes($file); ?>')" class="file-action-btn edit">编辑</a>
                                                    <?php endif; ?>
                                                    <a href="javascript:void(0);" onclick="deleteFile('<?php echo addslashes($file); ?>')" class="file-action-btn delete">删除</a>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                                
                                <!-- 上传表单 -->
                                <form method="POST" enctype="multipart/form-data" class="mt-4" id="uploadForm">
                                    <div class="upload-area" id="uploadArea">
                                        <input type="file" name="files[]" multiple class="hidden" id="fileInput" accept=".html,.htm">
                                        <div class="upload-icon">📤</div>
                                        <div class="upload-text">
                                            <strong>点击选择</strong> 或拖拽文件到此处
                                        </div>
                                        <div class="text-xs text-gray-400 mt-2">
                                            仅支持 .html 文件，最大 3MB（最多10个）
                                        </div>
                                    </div>
                                    
                                    <!-- 文件信息预览 -->
                                    <div class="file-info" id="fileInfo">
                                        <div class="file-name" id="fileName">已选择 0 个文件</div>
                                        <div class="file-size" id="fileSize"></div>
                                    </div>
                                    
                                    <button type="submit" class="btn btn-primary w-full mt-4" id="uploadBtn">
                                        开始上传
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <!-- 文件编辑器（默认收起） -->
                    <div class="md:col-span-2" id="editor-section">
                        <div class="card">
                            <div class="card-header">
                                <div class="editor-toggle" onclick="toggleEditor()">
                                    <span class="font-bold flex items-center gap-2">
                                        <span>✏️</span> 文件编辑器
                                    </span>
                                    <span class="toggle-icon" id="toggleIcon">▼</span>
                                </div>
                            </div>
                            <div class="card-body editor-container collapsed" id="editorContainer">
                                <div class="mb-4">
                                    <select id="fileSelector" class="custom-select" onchange="loadSelectedFile(this.value)">
                                        <option value="">📋 选择要编辑的文件</option>
                                        <?php foreach ($files as $file): ?>
                                            <?php if (preg_match('/\.(html?|css|js|txt)$/i', $file)): ?>
                                                <option value="<?php echo htmlspecialchars($file); ?>"><?php echo $file; ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <textarea id="editor" rows="20" class="code-editor" placeholder="📝 选择文件开始编辑..."></textarea>
                                
                                <div class="flex justify-end gap-2 mt-4">
                                    <button onclick="saveFile()" class="btn btn-primary" id="saveBtn">
                                        保存文件
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- 粘贴代码标签页 -->
            <div id="tabPaste" class="tab-content">
                <div class="card">
                    <div class="card-header">
                        <h2 class="font-bold flex items-center gap-2">
                            <span>📋</span> 粘贴 HTML 代码
                        </h2>
                    </div>
                    <div class="card-body">
                        <form method="POST" id="pasteForm">
                            <div class="paste-section">
                                <div class="paste-title">
                                    <span>📝 HTML 代码</span>
                                    <?php if ($has_index): ?>
                                        <span class="size-indicator" style="background: #fef3c7; color: #92400e;">已存在 index.html，粘贴将覆盖</span>
                                    <?php else: ?>
                                        <span class="size-indicator" style="background: #d1fae5; color: #065f46;">将创建 index.html</span>
                                    <?php endif; ?>
                                </div>
                                <textarea name="html_code" rows="15" class="paste-textarea" placeholder="在此粘贴您的 HTML 代码...">&lt;!DOCTYPE html&gt;
&lt;html lang="zh"&gt;
&lt;head&gt;
    &lt;meta charset="UTF-8"&gt;
    &lt;meta name="viewport" content="width=device-width, initial-scale=1.0"&gt;
    &lt;title&gt;我的网站&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;
    &lt;h1&gt;欢迎访问我的网站！&lt;/h1&gt;
&lt;/body&gt;
&lt;/html&gt;</textarea>
                            </div>
                            <input type="hidden" name="paste_html" value="1">
                            <button type="submit" class="btn btn-primary" id="pasteBtn">
                                <?php echo $has_index ? '覆盖 index.html' : '创建 index.html'; ?>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </main>
    </div>
    
    <!-- 自定义提示框容器 -->
    <div id="toastContainer"></div>
    
    <script>
    // 自定义提示框函数
    function showToast(message, type = 'info') {
        const container = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.className = `custom-toast ${type}`;
        
        const icons = {
            success: '✓',
            error: '✗',
            info: 'ℹ'
        };
        
        toast.innerHTML = `
            <div class="toast-content">
                <div class="toast-icon">${icons[type] || 'ℹ'}</div>
                <div class="toast-message">${message}</div>
                <div class="toast-close" onclick="this.parentElement.parentElement.remove()">×</div>
            </div>
        `;
        
        container.appendChild(toast);
        
        setTimeout(() => {
            toast.classList.add('show');
        }, 10);
        
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => {
                if (toast.parentElement) {
                    toast.remove();
                }
            }, 300);
        }, 3000);
    }
    
    // 切换标签页
    function switchTab(tab) {
        document.getElementById('tabUpload').classList.remove('active');
        document.getElementById('tabPaste').classList.remove('active');
        document.getElementById('tabUploadBtn').classList.remove('active');
        document.getElementById('tabPasteBtn').classList.remove('active');
        
        if (tab === 'upload') {
            document.getElementById('tabUpload').classList.add('active');
            document.getElementById('tabUploadBtn').classList.add('active');
        } else {
            document.getElementById('tabPaste').classList.add('active');
            document.getElementById('tabPasteBtn').classList.add('active');
        }
    }
    
    // 切换编辑器显示/隐藏
    function toggleEditor() {
        const container = document.getElementById('editorContainer');
        const icon = document.getElementById('toggleIcon');
        
        if (container.classList.contains('collapsed')) {
            container.classList.remove('collapsed');
            icon.classList.add('expanded');
        } else {
            container.classList.add('collapsed');
            icon.classList.remove('expanded');
        }
    }
    
    // 复制网站链接
    function copySiteUrl() {
        const urlElement = document.getElementById('siteUrl');
        const url = urlElement.textContent.trim();
        const copyBtn = document.getElementById('copyUrlBtn');
        
        navigator.clipboard.writeText(url).then(() => {
            copyBtn.classList.add('copied');
            copyBtn.innerHTML = '<span>✓</span> 已复制';
            showToast('网站链接已复制到剪贴板', 'success');
            
            setTimeout(() => {
                copyBtn.classList.remove('copied');
                copyBtn.innerHTML = '<span>📋</span> 复制链接';
            }, 2000);
        }).catch(() => {
            const textarea = document.createElement('textarea');
            textarea.value = url;
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand('copy');
            document.body.removeChild(textarea);
            showToast('网站链接已复制到剪贴板', 'success');
        });
    }
    
    let currentFile = '';
    
    // 文件上传预览
    document.getElementById('fileInput').addEventListener('change', function(e) {
        const files = e.target.files;
        const fileInfo = document.getElementById('fileInfo');
        const fileName = document.getElementById('fileName');
        const fileSize = document.getElementById('fileSize');
        const currentCount = <?php echo $html_files_count; ?>;
        
        if (files.length > 0) {
            let totalSize = 0;
            let fileNames = [];
            let htmlFileCount = 0;
            
            for (let i = 0; i < files.length; i++) {
                const file = files[i];
                const ext = file.name.split('.').pop().toLowerCase();
                
                if (ext !== 'html' && ext !== 'htm') {
                    showToast(`文件 ${file.name} 不是 HTML 文件`, 'error');
                    continue;
                }
                
                htmlFileCount++;
                
                if (file.size > 3 * 1024 * 1024) {
                    showToast(`文件 ${file.name} 超过 3MB 限制`, 'error');
                    continue;
                }
                
                totalSize += file.size;
                fileNames.push(file.name);
            }
            
            if (currentCount + htmlFileCount > 10) {
                showToast(`最多只能上传 10 个 HTML 文件，当前已有 ${currentCount} 个`, 'error');
                document.getElementById('fileInput').value = '';
                fileInfo.classList.remove('show');
                return;
            }
            
            if (fileNames.length > 0) {
                fileName.textContent = `已选择 ${fileNames.length} 个文件：${fileNames.join('、')}`;
                const sizeMB = (totalSize / (1024 * 1024)).toFixed(2);
                fileSize.textContent = `总大小：${sizeMB} MB`;
                fileInfo.classList.add('show');
                showToast(`已选择 ${fileNames.length} 个文件，可以上传`, 'success');
            } else {
                fileInfo.classList.remove('show');
            }
        } else {
            fileInfo.classList.remove('show');
        }
    });
    
    // 拖拽上传
    const uploadArea = document.getElementById('uploadArea');
    
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        uploadArea.addEventListener(eventName, preventDefaults, false);
    });
    
    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }
    
    ['dragenter', 'dragover'].forEach(eventName => {
        uploadArea.addEventListener(eventName, () => {
            uploadArea.classList.add('dragover');
        });
    });
    
    ['dragleave', 'drop'].forEach(eventName => {
        uploadArea.addEventListener(eventName, () => {
            uploadArea.classList.remove('dragover');
        });
    });
    
    uploadArea.addEventListener('drop', function(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        document.getElementById('fileInput').files = files;
        const event = new Event('change', { bubbles: true });
        document.getElementById('fileInput').dispatchEvent(event);
    });
    
    uploadArea.addEventListener('click', function() {
        document.getElementById('fileInput').click();
    });
    
    // 文件操作函数 - 修复版本
    function loadFile(filename, shouldScroll = true) {
        if (!filename) {
            document.getElementById('editor').value = '';
            return;
        }
        
        currentFile = filename;
        
        const selector = document.getElementById('fileSelector');
        for (let i = 0; i < selector.options.length; i++) {
            if (selector.options[i].value === filename) {
                selector.selectedIndex = i;
                break;
            }
        }
        
        // 如果编辑器是收起的，自动展开
        const container = document.getElementById('editorContainer');
        if (container.classList.contains('collapsed')) {
            toggleEditor();
        }
        
        showToast(`正在加载 ${filename}...`, 'info');
        
        // 获取正确的站点ID
        const siteId = '<?php echo $site_id; ?>';
        
        // 使用完整的API路径
        fetch('api/get_file.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                site_id: siteId,
                file: filename
            })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('网络响应失败 (HTTP ' + response.status + ')');
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                document.getElementById('editor').value = data.content;
                showToast(`文件 ${filename} 加载成功`, 'success');
                
                if (shouldScroll) {
                    setTimeout(() => {
                        document.getElementById('editor-section').scrollIntoView({ 
                            behavior: 'smooth', 
                            block: 'start' 
                        });
                    }, 300);
                }
            } else {
                showToast(data.message || '加载失败', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showToast('网络错误：' + error.message, 'error');
        });
    }
    
    // 加载并编辑文件（带滚动）
    function loadAndEdit(filename) {
        loadFile(filename, true);
    }
    
    // 从下拉框选择文件
    function loadSelectedFile(filename) {
        if (filename) {
            loadFile(filename, true);
        }
    }
    
    function saveFile() {
        if (!currentFile) {
            showToast('请先选择要编辑的文件', 'warning');
            return;
        }
        
        const content = document.getElementById('editor').value;
        showToast('正在保存...', 'info');
        
        fetch('api/save_file.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                site_id: '<?php echo $site_id; ?>',
                file: currentFile,
                content: content
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast('文件保存成功', 'success');
            } else {
                showToast(data.message || '保存失败', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showToast('网络错误：' + error.message, 'error');
        });
    }
    
    function deleteFile(filename) {
        if (confirm('确定要删除这个文件吗？此操作不可撤销！')) {
            showToast(`正在删除 ${filename}...`, 'info');
            
            fetch('api/delete_file.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    site_id: '<?php echo $site_id; ?>',
                    file: filename
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast('文件删除成功', 'success');
                    location.reload();
                } else {
                    showToast(data.message || '删除失败', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showToast('网络错误：' + error.message, 'error');
            });
        }
    }
    
    // 上传表单验证
    document.getElementById('uploadForm').addEventListener('submit', function(e) {
        const fileInput = document.getElementById('fileInput');
        const currentCount = <?php echo $html_files_count; ?>;
        
        if (fileInput.files.length === 0) {
            e.preventDefault();
            showToast('请先选择要上传的文件', 'warning');
            return false;
        }
        
        let htmlFileCount = 0;
        for (let i = 0; i < fileInput.files.length; i++) {
            const file = fileInput.files[i];
            const ext = file.name.split('.').pop().toLowerCase();
            
            if (ext !== 'html' && ext !== 'htm') {
                e.preventDefault();
                showToast(`文件 ${file.name} 不是 HTML 文件`, 'error');
                return false;
            }
            
            htmlFileCount++;
            
            if (file.size > 3 * 1024 * 1024) {
                e.preventDefault();
                showToast(`文件 ${file.name} 超过 3MB 限制`, 'error');
                return false;
            }
        }
        
        if (currentCount + htmlFileCount > 10) {
            e.preventDefault();
            showToast(`最多只能上传 10 个 HTML 文件，当前已有 ${currentCount} 个`, 'error');
            return false;
        }
        
        showToast('正在上传文件...', 'info');
        return true;
    });
    
    // 粘贴表单验证
    document.getElementById('pasteForm').addEventListener('submit', function(e) {
        const htmlCode = document.querySelector('textarea[name="html_code"]').value.trim();
        const currentCount = <?php echo $html_files_count; ?>;
        
        if (!htmlCode) {
            e.preventDefault();
            showToast('请输入 HTML 代码', 'warning');
            return false;
        }
        
        <?php if (!$has_index): ?>
        if (currentCount >= 10) {
            e.preventDefault();
            showToast(`最多只能上传 10 个 HTML 文件，当前已有 ${currentCount} 个`, 'error');
            return false;
        }
        <?php endif; ?>
        
        showToast('正在创建 index.html...', 'info');
        return true;
    });
    </script>
</body>
</html>