import { defineConfig } from '@morjs/cli'

export default defineConfig([
  {
    name: 'web',
    sourceType: 'wechat',
    target: 'web',
    compileType: 'miniprogram',
    compileMode: 'bundle',
    // web: {
    //   emitIntermediateAssets: true
    // }
  }
])
