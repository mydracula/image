import { wApp } from '@morjs/core'

wApp({
  globalData: {},
  onLaunch () {
    
  }
})
