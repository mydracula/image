import { wPage } from '@morjs/core'

wPage({})
