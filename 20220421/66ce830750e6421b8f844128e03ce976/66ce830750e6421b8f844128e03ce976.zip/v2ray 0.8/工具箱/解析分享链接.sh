#节点保存目录
nodeDir='../节点列表'

#节点分享链接(一行一个链接)
nodeLinks='
vless://32111740-3ee8-46cd-8ec8-bb46e8bc9e8a@119.29.186.53:8097?path=/&security=tls&flow=xtls-rprx-origin&encryption=none&host=cutebi.flashproxy.cn&type=ws&allowInsecure=1#ws+tls_119.29.186.53:8097
'
#mux开关(true开启)
mux='false'

#免流Host, 如果不设置则使用节点自带的
repHost=''

#path, 如果不设置则使用节点自带的
repPath=''


cd "${0%/*}"
sh ../Core/downloadCores.sh "$repHost" 'MLBox' 'Usgae'
echo "节点保存目录为: $PWD/$nodeDir"
echo '所有 节点文件(.ini结尾) 需要复制到 节点列表 文件夹才可以用'
alias 'MLBox=../Core/MLBox'
mkdir "$nodeDir" 2>/dev/null
i=1
for v2link in $nodeLinks; do
	v2msg=`MLBox -v2Link="$v2link"`
	eval "$v2msg"
	echo "$ps" | grep -q '/' && ps="${ps//\//\\}"
	filePath="${nodeDir:=$PWD}/${i}_${ps%% *}.ini"
	echo "$v2link" | grep -q '^vless' && protocol='vless' || protocol='vmess'
	echo "protocol=$protocol" >"$filePath"
	echo "mux='$mux'" >>"$filePath"
	echo "$v2msg" | grep -Ev '^host|^sni|^path' >>"$filePath"
	if [ -n "$repHost" ]; then
		host="$repHost"
		sni="$repHost"
	fi
	if [ -n "$repPath" ]; then
		path="$repPath"
	fi
	echo "host='$host'" >>"$filePath"
	echo "sni='$host'" >>"$filePath"
	echo "path='$path'" >>"$filePath"
	echo -E "第$i个节点: ${ps}, 已写入文件: ${i}_${ps%% *}.ini"
	for v in ${v2msg// /_}; do
		unset "${v%=*}"
	done
	i=$((i + 1))
done
