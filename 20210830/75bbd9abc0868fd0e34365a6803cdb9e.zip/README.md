# file2link
PHP利用Github与jsdelivr生成文件直链（对象存储/图床）

[Demo](https://huanghaozi.cn/tools/file2link/uploader.html "Demo"): [https://huanghaozi.cn/tools/file2link/uploader.html](https://huanghaozi.cn/tools/file2link/uploader.html "Demo")

# 食用方法
- 打开main.php编辑name（github昵称）、username（github用户名）、email（github绑的邮箱）、token（有repo权限的token）、repo（repo名）
- 打开uploader.html将第99行中url的链接更换为自己服务器上的main.php地址
- 传至php服务器
- 打开其中的uploader.html
即可使用
