<?php
require "githubapi.php";
$name = 'mydracula';
$username = 'mydracula';
$email = '1462465969@qq.com';
$token = '6139dd4c9dda417a5221dcc10d7d502f7201e651';
$repo = 'image';

$data = file_get_contents("php://input");
$index = strpos($data,",");
$indexExs = strpos($data,".");
$indexExe = strpos($data," ");
$fileEx = substr($data,$indexExs,$indexExe-$indexExs);
$dataPure = substr($data, $index+1);

$rv = foo($fileEx, $dataPure, $name, $email, $username, $token, $repo);
echo $rv;