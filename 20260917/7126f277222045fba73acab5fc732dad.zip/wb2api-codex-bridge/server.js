'use strict';

const http = require('node:http');
const crypto = require('node:crypto');

function envNumber(value, fallback, min = 1) {
  const number = Number(value);
  return Number.isFinite(number) && number >= min ? number : fallback;
}

const PORT = envNumber(process.env.PORT, 8888, 1);
const HOST = process.env.HOST || '127.0.0.1';
const REQUEST_TIMEOUT_MS = envNumber(process.env.BRIDGE_TIMEOUT_MS, 300000);
const UPSTREAM_BASE = (process.env.WB2API_BASE || 'http://127.0.0.1:7863').replace(/\/+$/, '');
const UPSTREAM_KEY = process.env.WB2API_KEY || '.';
const BRIDGE_KEY = process.env.CODEX_BRIDGE_KEY || '.';
const MAX_BODY_MB = envNumber(process.env.BRIDGE_MAX_BODY_MB, 16, 0.001);
const MAX_BODY_BYTES = MAX_BODY_MB * 1024 * 1024;
const LOG_REQUEST_BODY = process.env.BRIDGE_LOG_REQUEST_BODY === '1';
const IDLE_TIMEOUT_MS = envNumber(process.env.BRIDGE_IDLE_TIMEOUT_MS, 120000);
const HEARTBEAT_MS = envNumber(process.env.BRIDGE_HEARTBEAT_MS, 15000);
const STREAM_REASONING = process.env.BRIDGE_STREAM_REASONING !== '0';
const MAX_TOKENS_FIELD = process.env.BRIDGE_MAX_TOKENS_FIELD === 'max_completion_tokens'
  ? 'max_completion_tokens'
  : 'max_tokens';
const RETRY_ATTEMPTS = Math.max(1, envNumber(process.env.BRIDGE_RETRIES, 3));

const MODEL = 'cn:glm-5.3';

function log(message, detail = '') {
  const time = new Date().toLocaleString('zh-CN', { hour12: false });
  console.log(`[${time}] ${message}${detail ? ` ${detail}` : ''}`);
}

function sendJson(res, status, value) {
  if (res.destroyed || res.writableEnded) return;
  if (res.headersSent) {
    res.destroy();
    return;
  }
  const body = JSON.stringify(value);
  res.writeHead(status, {
    'content-type': 'application/json',
    'content-length': Buffer.byteLength(body),
  });
  res.end(body);
}

function sendText(res, status, text) {
  if (res.destroyed || res.writableEnded) return;
  const body = text;
  res.writeHead(status, {
    'content-type': 'text/plain; charset=utf-8',
    'content-length': Buffer.byteLength(body),
  });
  res.end(body);
}

function isAuthorized(req) {
  if (BRIDGE_KEY === '.') return true;
  const value = req.headers.authorization || '';
  return value === `Bearer ${BRIDGE_KEY}`;
}

function readBody(req, res) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    let done = false;
    req.on('data', (chunk) => {
      if (done) return;
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        done = true;
        chunks.length = 0;
        req.resume();
        reject(Object.assign(new Error(`请求体超过 ${MAX_BODY_MB} MB 限制`), { statusCode: 413 }));
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (done) return;
      done = true;
      resolve(Buffer.concat(chunks).toString('utf8'));
    });
    req.on('error', (error) => {
      if (done) return;
      done = true;
      reject(error);
    });
    res.on('close', () => {
      if (done || req.complete) return;
      done = true;
      reject(Object.assign(new Error('客户端提前断开连接'), { statusCode: 400 }));
    });
  });
}

function asText(value) {
  if (typeof value === 'string') return value;
  if (value === undefined || value === null) return '';
  return JSON.stringify(value);
}

function toChatContent(content) {
  if (typeof content === 'string') return content;
  if (!Array.isArray(content)) return asText(content);

  const parts = [];
  for (const part of content) {
    if (!part || typeof part !== 'object') {
      parts.push({ type: 'text', text: asText(part) });
      continue;
    }
    if (part.type === 'input_text' || part.type === 'output_text' || part.type === 'text') {
      parts.push({ type: 'text', text: asText(part.text) });
      continue;
    }
    if (part.type === 'input_image' || part.type === 'image_url') {
      const imageUrl = typeof part.image_url === 'string'
        ? part.image_url
        : part.image_url?.url || part.url;
      if (imageUrl) parts.push({ type: 'image_url', image_url: { url: imageUrl } });
      continue;
    }
    if (part.type === 'input_file' || part.type === 'file') {
      parts.push({ type: 'text', text: `[file: ${asText(part.file_id || part.filename || 'attached file')}]` });
      continue;
    }
    if (part.text !== undefined) parts.push({ type: 'text', text: asText(part.text) });
  }
  if (!parts.length) return '';
  if (parts.length === 1 && parts[0].type === 'text') return parts[0].text;
  return parts;
}

function addToolCall(messages, item) {
  const call = {
    id: item.call_id || item.id || `call_${crypto.randomUUID().replaceAll('-', '')}`,
    type: 'function',
    function: {
      name: item.name || 'unknown_function',
      arguments: asText(item.arguments || '{}'),
    },
  };
  const last = messages[messages.length - 1];
  if (last && last.role === 'assistant' && Array.isArray(last.tool_calls)) {
    last.tool_calls.push(call);
    return;
  }
  messages.push({ role: 'assistant', content: null, tool_calls: [call] });
}

function addInputItem(messages, item) {
  if (!item || typeof item !== 'object') return;

  if (item.type === 'function_call_output') {
    messages.push({
      role: 'tool',
      tool_call_id: item.call_id || item.id || `call_${crypto.randomUUID()}`,
      content: asText(item.output),
    });
    return;
  }

  if (item.type === 'function_call') {
    addToolCall(messages, item);
    return;
  }

  if (item.type === 'message') {
    const role = item.role === 'developer' ? 'system' : (item.role || 'user');
    messages.push({ role, content: toChatContent(item.content) });
    return;
  }

  if (item.type === 'input_text' || item.type === 'text') {
    messages.push({ role: 'user', content: asText(item.text) });
  }
}

function responsesInputToMessages(input) {
  if (typeof input === 'string') return [{ role: 'user', content: input }];
  if (!Array.isArray(input)) return [];

  const messages = [];
  for (const item of input) addInputItem(messages, item);
  return messages;
}

function responseToolToChatTool(tool) {
  if (!tool || tool.type !== 'function') return null;
  const fn = tool.function || {};
  const name = tool.name || fn.name;
  if (!name) return null;
  return {
    type: 'function',
    function: {
      name,
      description: tool.description || fn.description || '',
      parameters: tool.parameters || fn.parameters || { type: 'object', properties: {} },
      ...(tool.strict !== undefined || fn.strict !== undefined
        ? { strict: tool.strict ?? fn.strict }
        : {}),
    },
  };
}

function buildChatRequest(body) {
  const messages = [];
  if (body.instructions) messages.push({ role: 'system', content: asText(body.instructions) });
  messages.push(...responsesInputToMessages(body.input));

  const tools = (Array.isArray(body.tools) ? body.tools : [])
    .map(responseToolToChatTool)
    .filter(Boolean);

  const request = {
    model: MODEL,
    messages,
    stream: Boolean(body.stream),
  };

  if (body.max_output_tokens !== undefined) request[MAX_TOKENS_FIELD] = body.max_output_tokens;
  if (body.temperature !== undefined) request.temperature = body.temperature;
  if (body.top_p !== undefined) request.top_p = body.top_p;
  if (body.parallel_tool_calls !== undefined) request.parallel_tool_calls = body.parallel_tool_calls;
  if (body.prompt_cache_key !== undefined) request.prompt_cache_key = body.prompt_cache_key;
  if (tools.length) request.tools = tools;

  const format = body.text?.format;
  if (format && typeof format === 'object') {
    if (format.type === 'json_object') {
      request.response_format = { type: 'json_object' };
    } else if (format.type === 'json_schema' && format.schema) {
      request.response_format = {
        type: 'json_schema',
        json_schema: {
          name: format.name || 'response',
          schema: format.schema,
          ...(format.strict !== undefined ? { strict: format.strict } : {}),
        },
      };
    }
  }

  if (tools.length && body.tool_choice !== undefined) {
    if (body.tool_choice && typeof body.tool_choice === 'object' && body.tool_choice.type === 'function') {
      request.tool_choice = {
        type: 'function',
        function: { name: body.tool_choice.name || body.tool_choice.function?.name },
      };
    } else {
      request.tool_choice = body.tool_choice;
    }
  }

  if (body.reasoning?.effort) {
    const effort = normalizeReasoningEffort(body.reasoning.effort);
    if (effort) request.reasoning_effort = effort;
  }
  if (body.user) request.user = body.user;
  if (body.stream) request.stream_options = { include_usage: true };
  return request;
}

function normalizeReasoningEffort(effort) {
  if (typeof effort !== 'string') return undefined;
  const value = effort.trim().toLowerCase();
  if (!value || value === 'none' || value === 'off' || value === 'disabled') return undefined;
  if (value === 'minimal') return 'low';
  if (value === 'xhigh' || value === 'max') return 'high';
  return value;
}

function usageToResponse(usage) {
  if (!usage) return null;
  return {
    input_tokens: usage.prompt_tokens || 0,
    output_tokens: usage.completion_tokens || 0,
    total_tokens: usage.total_tokens || 0,
    ...(usage.completion_tokens_details?.reasoning_tokens !== undefined
      ? { output_tokens_details: { reasoning_tokens: usage.completion_tokens_details.reasoning_tokens } }
      : {}),
  };
}

function outputMessage(id, content, status = 'completed') {
  return {
    type: 'message',
    id,
    status,
    role: 'assistant',
    content: [{
      type: 'output_text',
      text: content || '',
      annotations: [],
      logprobs: [],
    }],
  };
}

function chatToResponse(payload) {
  const choice = payload.choices?.[0] || {};
  const message = choice.message || {};
  const responseId = `resp_${payload.id || crypto.randomUUID().replaceAll('-', '')}`;
  const output = [];

  const reasoning = message.reasoning_content || message.reasoning;
  if (reasoning && STREAM_REASONING) {
    output.push({
      type: 'reasoning',
      id: `rs_${responseId}`,
      summary: [{ type: 'summary_text', text: asText(reasoning) }],
    });
  }

  if (message.content) {
    output.push(outputMessage(`msg_${responseId}`, message.content));
  }

  for (const call of message.tool_calls || []) {
    const id = call.id || `call_${crypto.randomUUID().replaceAll('-', '')}`;
    output.push({
      type: 'function_call',
      id,
      call_id: id,
      name: call.function?.name || '',
      arguments: call.function?.arguments || '{}',
      status: 'completed',
    });
  }

  const response = {
    id: responseId,
    object: 'response',
    created_at: payload.created || Math.floor(Date.now() / 1000),
    status: 'completed',
    model: MODEL,
    output,
    parallel_tool_calls: true,
    tool_choice: 'auto',
    usage: usageToResponse(payload.usage),
  };
  if (choice.finish_reason === 'length') {
    response.status = 'incomplete';
    response.incomplete_details = { reason: 'max_output_tokens' };
  } else if (!output.length) {
    response.status = 'incomplete';
    response.incomplete_details = { reason: 'max_output_tokens' };
  }
  return response;
}

function makeResponseShell(id, model) {
  return {
    id,
    object: 'response',
    created_at: Math.floor(Date.now() / 1000),
    status: 'in_progress',
    model,
    output: [],
    parallel_tool_calls: true,
    tool_choice: 'auto',
    usage: null,
  };
}

function writeSse(res, event, value, state) {
  if (res.destroyed || res.writableEnded) return;
  const payload = { ...value, sequence_number: state.sequence++ };
  try {
    if (!res.write(`event: ${event}\n`)) state.needDrain = true;
    if (!res.write(`data: ${JSON.stringify(payload)}\n\n`)) state.needDrain = true;
  } catch (error) {
    state.needDrain = false;
    state.writeError = error;
  }
}

async function waitForDrain(res, state) {
  if (!state.needDrain || res.destroyed || res.writableEnded) return;
  state.needDrain = false;
  await new Promise((resolve) => {
    const done = () => {
      res.off('drain', done);
      res.off('close', done);
      resolve();
    };
    res.once('drain', done);
    res.once('close', done);
  });
}

function parseSseFrame(buffer) {
  let boundary = -1;
  let separatorLength = 0;
  for (let i = 0; i < buffer.length; i++) {
    const char = buffer[i];
    if (char === '\r' && buffer[i + 1] === '\n' && buffer[i + 2] === '\r' && buffer[i + 3] === '\n') {
      boundary = i;
      separatorLength = 4;
      break;
    }
    if (char === '\n') {
      if (buffer[i + 1] === '\n') {
        boundary = i;
        separatorLength = 2;
        break;
      }
      if (buffer[i + 1] === '\r' && buffer[i + 2] === '\n') {
        boundary = i;
        separatorLength = 3;
        break;
      }
    }
  }
  if (boundary === -1) return null;
  const frame = buffer.slice(0, boundary);
  const remainder = buffer.slice(boundary + separatorLength);
  const data = frame
    .split(/\r?\n/)
    .filter((line) => line.startsWith('data:'))
    .map((line) => line.slice(5).trim())
    .join('\n');
  if (!data || data === '[DONE]') return { data: null, remainder };
  try {
    return { data: JSON.parse(data), remainder };
  } catch {
    return { data: null, remainder };
  }
}

async function streamChatAsResponses(upstreamResponse, res, model, controller) {
  const responseId = `resp_${crypto.randomUUID().replaceAll('-', '')}`;
  const shell = makeResponseShell(responseId, model);
  const state = { sequence: 0, needDrain: false };
  const output = [];
  let nextOutputIndex = 0;
  let messageOpen = false;
  let messageText = '';
  let messageId = `msg_${responseId}`;
  let messageOutputIndex = -1;
  let reasoningOpen = false;
  let reasoningText = '';
  let reasoningId = `rs_${responseId}`;
  let reasoningOutputIndex = -1;
  const tools = new Map();
  let finishReason = 'stop';
  let usage = null;
  let idleError = null;
  let heartbeat = null;
  let idleTimer = null;

  res.writeHead(200, {
    'content-type': 'text/event-stream',
    'cache-control': 'no-cache',
    connection: 'keep-alive',
    'x-accel-buffering': 'no',
  });

  res.on('close', () => {
    if (!res.writableFinished) controller.abort();
    if (heartbeat) clearInterval(heartbeat);
    if (idleTimer) clearTimeout(idleTimer);
  });

  heartbeat = setInterval(() => {
    if (res.destroyed || res.writableEnded) return;
    res.write(': ping\n\n');
  }, HEARTBEAT_MS);
  if (heartbeat.unref) heartbeat.unref();

  function armIdleTimer() {
    clearTimeout(idleTimer);
    idleTimer = setTimeout(() => {
      idleError = new Error('上游长时间没有返回数据');
      controller.abort();
    }, IDLE_TIMEOUT_MS);
    if (idleTimer.unref) idleTimer.unref();
  }

  armIdleTimer();

  writeSse(res, 'response.created', { type: 'response.created', response: shell }, state);
  writeSse(res, 'response.in_progress', { type: 'response.in_progress', response: shell }, state);

  function openReasoning() {
    if (reasoningOpen || !STREAM_REASONING) return;
    reasoningOpen = true;
    reasoningOutputIndex = nextOutputIndex++;
    writeSse(res, 'response.output_item.added', {
      type: 'response.output_item.added',
      output_index: reasoningOutputIndex,
      item: { type: 'reasoning', id: reasoningId, summary: [] },
    }, state);
    writeSse(res, 'response.reasoning_summary_part.added', {
      type: 'response.reasoning_summary_part.added',
      item_id: reasoningId,
      output_index: reasoningOutputIndex,
      summary_index: 0,
      part: { type: 'summary_text', text: '' },
    }, state);
  }

  function closeReasoning() {
    if (!reasoningOpen) return;
    writeSse(res, 'response.reasoning_summary_text.done', {
      type: 'response.reasoning_summary_text.done',
      item_id: reasoningId,
      output_index: reasoningOutputIndex,
      summary_index: 0,
      text: reasoningText,
    }, state);
    writeSse(res, 'response.reasoning_summary_part.done', {
      type: 'response.reasoning_summary_part.done',
      item_id: reasoningId,
      output_index: reasoningOutputIndex,
      summary_index: 0,
      part: { type: 'summary_text', text: reasoningText },
    }, state);
    const item = {
      type: 'reasoning',
      id: reasoningId,
      summary: [{ type: 'summary_text', text: reasoningText }],
    };
    output[reasoningOutputIndex] = item;
    writeSse(res, 'response.output_item.done', {
      type: 'response.output_item.done',
      output_index: reasoningOutputIndex,
      item,
    }, state);
    reasoningOpen = false;
  }

  function openMessage() {
    if (messageOpen) return;
    messageOpen = true;
    messageOutputIndex = nextOutputIndex++;
    writeSse(res, 'response.output_item.added', {
      type: 'response.output_item.added',
      output_index: messageOutputIndex,
      item: { type: 'message', id: messageId, status: 'in_progress', role: 'assistant', content: [] },
    }, state);
    writeSse(res, 'response.content_part.added', {
      type: 'response.content_part.added',
      item_id: messageId,
      output_index: messageOutputIndex,
      content_index: 0,
      part: { type: 'output_text', text: '', annotations: [], logprobs: [] },
    }, state);
  }

  function closeMessage() {
    if (!messageOpen) return;
    writeSse(res, 'response.output_text.done', {
      type: 'response.output_text.done',
      item_id: messageId,
      output_index: messageOutputIndex,
      content_index: 0,
      text: messageText,
      logprobs: [],
    }, state);
    writeSse(res, 'response.content_part.done', {
      type: 'response.content_part.done',
      item_id: messageId,
      output_index: messageOutputIndex,
      content_index: 0,
      part: { type: 'output_text', text: messageText, annotations: [], logprobs: [] },
    }, state);
    const item = outputMessage(messageId, messageText);
    output[messageOutputIndex] = item;
    writeSse(res, 'response.output_item.done', {
      type: 'response.output_item.done',
      output_index: messageOutputIndex,
      item,
    }, state);
    messageOpen = false;
  }

  function openTool(index, delta) {
    let tool = tools.get(index);
    if (!tool) {
      const hasId = Boolean(delta.id);
      tool = {
        index,
        id: delta.id || `call_${crypto.randomUUID().replaceAll('-', '')}`,
        name: delta.function?.name || '',
        arguments: '',
        outputIndex: nextOutputIndex++,
        idFinal: hasId,
      };
      tools.set(index, tool);
      writeSse(res, 'response.output_item.added', {
        type: 'response.output_item.added',
        output_index: tool.outputIndex,
        item: {
          type: 'function_call',
          id: tool.id,
          call_id: tool.id,
          name: tool.name,
          arguments: '',
          status: 'in_progress',
        },
      }, state);
    }
    if (delta.id && !tool.idFinal) {
      tool.id = delta.id;
      tool.idFinal = true;
    }
    if (delta.function?.name) {
      const fragment = delta.function.name;
      if (fragment !== tool.name) {
        tool.name = fragment.startsWith(tool.name) ? fragment : tool.name + fragment;
      }
    }
    if (delta.function?.arguments) {
      tool.arguments += delta.function.arguments;
      writeSse(res, 'response.function_call_arguments.delta', {
        type: 'response.function_call_arguments.delta',
        item_id: tool.id,
        output_index: tool.outputIndex,
        delta: delta.function.arguments,
      }, state);
    }
  }

  function closeTools() {
    for (const tool of tools.values()) {
      const item = {
        type: 'function_call',
        id: tool.id,
        call_id: tool.id,
        name: tool.name,
        arguments: tool.arguments || '{}',
        status: 'completed',
      };
      output[tool.outputIndex] = item;
      writeSse(res, 'response.function_call_arguments.done', {
        type: 'response.function_call_arguments.done',
        item_id: tool.id,
        output_index: tool.outputIndex,
        arguments: tool.arguments || '{}',
      }, state);
      writeSse(res, 'response.output_item.done', {
        type: 'response.output_item.done',
        output_index: tool.outputIndex,
        item,
      }, state);
    }
  }

  let buffer = '';
  const decoder = new TextDecoder();
  let streamError = null;
  try {
    for await (const chunk of upstreamResponse.body) {
      armIdleTimer();
      buffer += decoder.decode(chunk, { stream: true });
      while (true) {
        const frames = parseSseFrame(buffer);
        if (!frames) break;
        buffer = frames.remainder;
        const data = frames.data;
        if (!data) continue;

        if (data.error) {
          throw new Error(data.error.message || JSON.stringify(data.error));
        }
        if (data.usage) usage = data.usage;
        const choice = data.choices?.[0];
        if (!choice) continue;
        if (choice.finish_reason) finishReason = choice.finish_reason;
        const delta = choice.delta || {};

        const reasoning = delta.reasoning_content || delta.reasoning;
        if (reasoning) {
          openReasoning();
          reasoningText += reasoning;
          writeSse(res, 'response.reasoning_summary_text.delta', {
            type: 'response.reasoning_summary_text.delta',
            item_id: reasoningId,
            output_index: reasoningOutputIndex,
            summary_index: 0,
            delta: reasoning,
          }, state);
        }

        if (delta.content) {
          openMessage();
          messageText += delta.content;
          writeSse(res, 'response.output_text.delta', {
            type: 'response.output_text.delta',
            item_id: messageId,
            output_index: messageOutputIndex,
            content_index: 0,
            delta: delta.content,
            logprobs: [],
          }, state);
        }
        for (const toolCall of delta.tool_calls || []) openTool(toolCall.index || 0, toolCall);
        await waitForDrain(res, state);
      }
    }
    buffer += decoder.decode();
    if (buffer.trim()) {
      const tail = buffer
        .split(/\r?\n/)
        .filter((line) => line.startsWith('data:'))
        .map((line) => line.slice(5).trim())
        .join('\n');
      if (tail && tail !== '[DONE]') {
        try {
          const data = JSON.parse(tail);
          if (data.usage) usage = data.usage;
          if (data.error) throw new Error(data.error.message || JSON.stringify(data.error));
          const choice = data.choices?.[0];
          if (choice?.finish_reason) finishReason = choice.finish_reason;
          const delta = choice?.delta || {};
          if (delta.reasoning_content || delta.reasoning) {
            openReasoning();
            const reasoning = delta.reasoning_content || delta.reasoning;
            reasoningText += reasoning;
            writeSse(res, 'response.reasoning_summary_text.delta', {
              type: 'response.reasoning_summary_text.delta',
              item_id: reasoningId,
              output_index: reasoningOutputIndex,
              summary_index: 0,
              delta: reasoning,
            }, state);
          }
          if (delta.content) {
            openMessage();
            messageText += delta.content;
            writeSse(res, 'response.output_text.delta', {
              type: 'response.output_text.delta',
              item_id: messageId,
              output_index: messageOutputIndex,
              content_index: 0,
              delta: delta.content,
              logprobs: [],
            }, state);
          }
          for (const toolCall of delta.tool_calls || []) openTool(toolCall.index || 0, toolCall);
        } catch (error) {
          if (error instanceof SyntaxError) {
            // 最后一段不是完整 JSON，忽略
          } else {
            throw error;
          }
        }
      }
    }
  } catch (error) {
    streamError = idleError || error;
  } finally {
    clearInterval(heartbeat);
    clearTimeout(idleTimer);
  }

  if (streamError && !res.destroyed && !res.writableEnded) {
    log('流式响应中断', `model=${model} ${streamError.message}`);
    closeReasoning();
    closeMessage();
    closeTools();
    shell.output = output.filter(Boolean);
    shell.usage = usageToResponse(usage);
    shell.status = 'failed';
    shell.error = { code: 'upstream_error', message: streamError.message };
    writeSse(res, 'response.failed', { type: 'response.failed', response: shell }, state);
    res.end();
    return;
  }

  if (res.destroyed || res.writableEnded) return;

  closeReasoning();
  closeMessage();
  closeTools();
  shell.status = finishReason === 'length' ? 'incomplete' : 'completed';
  shell.output = output.filter(Boolean);
  shell.usage = usageToResponse(usage);
  if (finishReason === 'length') shell.incomplete_details = { reason: 'max_output_tokens' };

  if (shell.status === 'completed' && !shell.output.length) {
    shell.status = 'incomplete';
    shell.incomplete_details = { reason: 'max_output_tokens' };
  }

  writeSse(res, 'response.completed', { type: 'response.completed', response: shell }, state);
  res.end();

  const tokens = usage
    ? `in=${usage.prompt_tokens || 0} out=${usage.completion_tokens || 0}`
    : 'usage=n/a';
  log('流式响应完成', `model=${model} status=${shell.status} items=${shell.output.length} ${tokens}`);
}

async function proxyModels(req, res) {
  let upstream;
  try {
    upstream = await fetch(`${UPSTREAM_BASE}/v1/models`, {
      headers: {
        authorization: `Bearer ${UPSTREAM_KEY}`,
        accept: 'application/json',
      },
      signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
    });
  } catch (error) {
    const reason = error.name === 'TimeoutError' || error.name === 'AbortError'
      ? '连接上游 wb2api 超时'
      : `连接 wb2api 失败：${error.message}`;
    sendJson(res, 502, { error: { message: reason, type: 'upstream_error' } });
    return;
  }
  const body = await upstream.text();
  if (!upstream.ok) {
    res.writeHead(upstream.status, {
      'content-type': upstream.headers.get('content-type') || 'application/json',
    });
    res.end(body);
    return;
  }
  let source = null;
  try {
    source = JSON.parse(body).data?.find((model) => model?.id === MODEL) || null;
  } catch {
    source = null;
  }
  sendJson(res, 200, {
    object: 'list',
    data: [{ ...(source || {}), id: MODEL, object: 'model', owned_by: source?.owned_by || 'wb2api' }],
  });
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function requestUpstream(chatRequest, stream, signal) {
  let lastError;
  for (let attempt = 1; attempt <= RETRY_ATTEMPTS; attempt++) {
    try {
      const response = await fetch(`${UPSTREAM_BASE}/v1/chat/completions`, {
        method: 'POST',
        headers: {
          authorization: `Bearer ${UPSTREAM_KEY}`,
          'content-type': 'application/json',
          accept: stream ? 'text/event-stream' : 'application/json',
        },
        body: JSON.stringify(chatRequest),
        signal,
      });
      if (response.ok) return response;
      const retriable = response.status === 429 || response.status >= 500;
      if (!retriable || attempt === RETRY_ATTEMPTS || signal.aborted) return response;
      try {
        await response.body?.cancel();
      } catch {
        // 忽略取消失败，继续重试
      }
      const retryAfter = Number(response.headers.get('retry-after'));
      const delay = retryAfter > 0
        ? Math.min(retryAfter * 1000, 10000)
        : Math.min(500 * 2 ** (attempt - 1), 5000);
      log('上游返回可重试状态', `HTTP ${response.status}，${delay}ms 后第 ${attempt + 1} 次尝试`);
      await sleep(delay);
    } catch (error) {
      lastError = error;
      const retriable = error.name === 'TypeError' || error.code === 'ECONNREFUSED' || error.code === 'ECONNRESET';
      if (!retriable || attempt === RETRY_ATTEMPTS || signal.aborted) throw error;
      log('上游连接失败，重试', `第 ${attempt + 1} 次：${error.message}`);
      await sleep(300);
    }
  }
  throw lastError || new Error('上游请求失败');
}

async function handleResponses(req, res) {
  let body;
  try {
    body = JSON.parse(await readBody(req, res));
  } catch (error) {
    if (res.destroyed || res.writableEnded) return;
    const status = error.statusCode === 413 ? 413 : 400;
    const message = status === 413
      ? error.message
      : `请求体不是有效的 JSON：${error.message}`;
    sendJson(res, status, { error: { message, type: 'invalid_request_error' } });
    return;
  }

  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    sendJson(res, 400, { error: { message: '请求体必须是 JSON 对象', type: 'invalid_request_error' } });
    return;
  }

  const chatRequest = buildChatRequest(body);
  const controller = new AbortController();
  res.on('close', () => {
    if (!res.writableFinished) controller.abort();
  });
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  let upstream;
  try {
    log('收到请求', `stream=${Boolean(body.stream)} model=${MODEL} tools=${Array.isArray(body.tools) ? body.tools.length : 0}`);
    if (LOG_REQUEST_BODY) log('转换后的请求体', JSON.stringify(chatRequest));
    upstream = await requestUpstream(chatRequest, Boolean(body.stream), controller.signal);
  } catch (error) {
    clearTimeout(timeout);
    if (res.destroyed || res.writableEnded) return;
    const reason = error.name === 'TimeoutError' || error.name === 'AbortError' ? '上游请求超时' : `连接 wb2api 失败：${error.message}`;
    sendJson(res, 502, { error: { message: reason, type: 'upstream_error' } });
    return;
  }

  if (!upstream.ok) {
    clearTimeout(timeout);
    const detail = await upstream.text();
    sendJson(res, upstream.status, {
      error: { message: `wb2api 返回 HTTP ${upstream.status}：${detail}`, type: 'upstream_error' },
    });
    return;
  }

  if (body.stream) {
    clearTimeout(timeout);
    await streamChatAsResponses(upstream, res, MODEL, controller);
    return;
  }

  try {
    const payload = await upstream.json();
    clearTimeout(timeout);
    if (payload.error) {
      const message = payload.error.message || JSON.stringify(payload.error);
      sendJson(res, 502, { error: { message: `wb2api 报错：${message}`, type: 'upstream_error' } });
      return;
    }
    sendJson(res, 200, chatToResponse(payload));
    const tokens = payload.usage
      ? `in=${payload.usage.prompt_tokens || 0} out=${payload.usage.completion_tokens || 0}`
      : 'usage=n/a';
    log('响应完成', `model=${MODEL} ${tokens}`);
  } catch (error) {
    clearTimeout(timeout);
    if (res.destroyed || res.writableEnded) return;
    const reason = error.name === 'AbortError' || controller.signal.aborted
      ? '上游请求超时'
      : `wb2api 返回了无效 JSON：${error.message}`;
    sendJson(res, 502, { error: { message: reason, type: 'upstream_error' } });
  }
}

const server = http.createServer(async (req, res) => {
  const startedAt = Date.now();
  res.on('finish', () => {
    log('请求结束', `${req.method} ${req.url} ${res.statusCode} ${Date.now() - startedAt}ms`);
  });

  const url = new URL(req.url, `http://${req.headers.host || '127.0.0.1'}`);

  if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/health')) {
    sendJson(res, 200, { ok: true, service: 'wb2api-codex-bridge-v2', port: PORT, upstream: UPSTREAM_BASE });
    return;
  }

  if (!isAuthorized(req)) {
    sendJson(res, 401, { error: { message: '认证失败：缺少或错误的 Authorization Bearer 密钥', type: 'authentication_error' } });
    return;
  }

  try {
    if (req.method === 'GET' && (url.pathname === '/models' || url.pathname === '/v1/models')) {
      await proxyModels(req, res);
      return;
    }
    if (req.method === 'POST' && (url.pathname === '/responses' || url.pathname === '/v1/responses')) {
      await handleResponses(req, res);
      return;
    }
    sendText(res, 404, '接口不存在。可用接口：GET /health、GET /models、GET /v1/models、POST /responses、POST /v1/responses');
  } catch (error) {
    if (!res.headersSent) {
      sendJson(res, 500, { error: { message: `桥接器内部错误：${error.message}`, type: 'bridge_error' } });
    } else {
      res.destroy(error);
    }
  }
});

server.requestTimeout = REQUEST_TIMEOUT_MS + 1000;
server.headersTimeout = 60000;
server.listen(PORT, HOST, () => {
  log('桥接器已启动', `http://${HOST}:${PORT}`);
  log('上游地址', UPSTREAM_BASE);
  log('安全提示', BRIDGE_KEY === '.' ? '未启用桥接密钥，仅监听本机回环地址' : '已启用桥接密钥认证');
});

server.on('error', (error) => {
  if (error.code === 'EADDRINUSE') {
    console.error(`[错误] 端口 ${PORT} 已被占用。请修改 PORT 或停止占用该端口的程序。`);
  } else {
    console.error(`[错误] 桥接器运行失败：${error.message}`);
  }
  process.exitCode = 1;
});
