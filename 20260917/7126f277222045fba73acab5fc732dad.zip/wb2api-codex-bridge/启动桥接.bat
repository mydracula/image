﻿@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title wb2api Codex Bridge v2

set "PORT=8888"
set "HOST=127.0.0.1"
set "WB2API_BASE=http://127.0.0.1:7863"
set "WB2API_KEY=."
set "CODEX_BRIDGE_KEY=."
set "BRIDGE_TIMEOUT_MS=300000"
set "BRIDGE_MAX_BODY_MB=16"

set "AUTO_RESTART="
if /i "%~1"=="/y" set "AUTO_RESTART=1"
if /i "%~1"=="-y" set "AUTO_RESTART=1"
if /i "%~1"=="restart" set "AUTO_RESTART=1"

set "LISTEN_PID="
for /f %%P in ('powershell -NoProfile -Command "(Get-NetTCPConnection -LocalPort %PORT% -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty OwningProcess)"') do set "LISTEN_PID=%%P"
if not defined LISTEN_PID goto :start_bridge

echo [提示] 端口 %PORT% 已被 PID %LISTEN_PID% 占用。
powershell -NoProfile -Command "$p=Get-Process -Id %LISTEN_PID% -ErrorAction SilentlyContinue; if($p){Write-Host ('[提示] 占用进程：' + $p.ProcessName + ' [' + $p.Path + ']')}"

set "HEALTH_SERVICE="
powershell -NoProfile -Command "try{$s=(Invoke-RestMethod -TimeoutSec 3 -Uri http://127.0.0.1:%PORT%/health).service}catch{}; if($s){Write-Output $s}" > "%~dp0wb2api_health.tmp" 2>nul
set /p "HEALTH_SERVICE=" < "%~dp0wb2api_health.tmp" 2>nul
del "%~dp0wb2api_health.tmp" >nul 2>&1

if /i not "%HEALTH_SERVICE%"=="wb2api-codex-bridge-v2" goto :occupied_other

echo [提示] 检测到旧桥接器实例仍在后台运行（可能已没有窗口）。
if defined AUTO_RESTART goto :kill_old

set "CONFIRM="
set /p "CONFIRM=是否结束旧实例并重新启动？输入 Y 结束并重启，其他键取消："
if /i not "%CONFIRM%"=="Y" goto :keep_old

:kill_old
echo [提示] 正在结束旧实例 PID %LISTEN_PID% ...
taskkill /pid %LISTEN_PID% /f >nul 2>&1
ping -n 2 127.0.0.1 >nul
goto :start_bridge

:keep_old
echo [提示] 已取消：不会结束旧实例，也不会启动第二个实例。
pause
exit /b 0

:occupied_other
echo [提示] 占用进程不是本桥接器，不会自动结束它。
echo [提示] 如确认需要强制结束：taskkill /pid %LISTEN_PID% /f
pause
exit /b 0

:start_bridge
where node >nul 2>&1
if errorlevel 1 (
  set "NODE_EXE=C:\Users\i\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
) else (
  set "NODE_EXE=node"
)

echo [提示] 正在启动：http://%HOST%:%PORT%
echo [提示] 上游 wb2api：%WB2API_BASE%
"%NODE_EXE%" server.js
echo.
echo [提示] 桥接器已退出。
pause
