# wb2api Codex Bridge v2

把 Codex 的 Responses API 请求转换成 wb2api 的 Chat Completions 请求。

## 使用

1. 先启动 wb2api，默认地址：`http://127.0.0.1:7863`。
2. 双击 `启动桥接.bat`。
3. 看到以下提示表示成功：

```text
桥接器已启动 http://127.0.0.1:8888
```

Codex 配置：

```text
base_url = "http://127.0.0.1:8888/v1"
wire_api = "responses"
```

## 环境变量

| 变量 | 默认值 | 说明 |
|---|---:|---|
| `PORT` | `8888` | 监听端口 |
| `HOST` | `127.0.0.1` | 监听地址，不建议暴露到局域网 |
| `WB2API_BASE` | `http://127.0.0.1:7863` | 上游 wb2api 地址 |
| `WB2API_KEY` | `.` | wb2api 密钥 |
| `CODEX_BRIDGE_KEY` | `.` | 桥接器认证密钥，`.` 表示关闭认证 |
| `BRIDGE_TIMEOUT_MS` | `300000` | 上游请求超时，单位毫秒 |
| `BRIDGE_MAX_BODY_MB` | `16` | 请求体大小限制 |
| `BRIDGE_LOG_REQUEST_BODY` | `0` | `1` 表示记录转换后的请求体，可能泄露敏感内容 |
| `BRIDGE_IDLE_TIMEOUT_MS` | `120000` | 上游流式数据空闲超时，超过则中止并返回 `response.failed` |
| `BRIDGE_HEARTBEAT_MS` | `15000` | 流式心跳间隔，发送 SSE 注释防止客户端超时 |
| `BRIDGE_STREAM_REASONING` | `1` | `0` 表示不把上游 `reasoning_content` 转成推理摘要事件 |
| `BRIDGE_MAX_TOKENS_FIELD` | `max_tokens` | 设为 `max_completion_tokens` 可改用新字段名 |
| `BRIDGE_RETRIES` | `3` | 上游连接失败或返回 429/5xx 时的最大尝试次数（含首次，带退避和 `Retry-After`） |

## 模型

固定使用 `cn:glm-5.3`，无论请求里写什么模型名都会被替换为它。

## 接口

- `GET /health`：健康检查，不需要认证。
- `GET /v1/models`：只返回 `cn:glm-5.3`。
- `POST /v1/responses`：转换请求，支持流式输出和函数调用。

## v2 优化

- 默认端口改为 `8888`。
- 启动、日志、错误提示改为中文。
- 增加端口占用检测，不会自动关闭旧桥接器或其他程序。
- 增加上游超时、请求体限制、请求耗时日志。
- 修复 SSE 兼容 `\r\n` 分隔和多行 `data:` 的情况。
- 保持只监听 `127.0.0.1`，默认不暴露到局域网。

## 后续优化

- 客户端断开时立即中止上游请求，不再空烧 token。
- 流式空闲看门狗与心跳，上游卡死时返回 `response.failed` 而不是静默断开。
- 上游 `reasoning_content` 转为 `response.reasoning_summary_text.delta`，思考过程可见。
- 支持 `prompt_cache_key`、`text.format`（json_schema / json_object）透传。
- 上游连接失败自动重试；日志输出 token 用量。
- SSE 写入支持背压，长输出不会撑爆内存。
- 上游 429/5xx 按退避重试（支持 `Retry-After`），次数由 `BRIDGE_RETRIES` 控制。
- `reasoning_effort` 归一化：`minimal`→`low`、`xhigh`/`max`→`high`。
- 无工具时不下发 `tool_choice`；工具调用缺 id 时自动补齐，避免客户端报错。
- 非流式响应中的 `error` 字段会被识别并转为标准错误。
