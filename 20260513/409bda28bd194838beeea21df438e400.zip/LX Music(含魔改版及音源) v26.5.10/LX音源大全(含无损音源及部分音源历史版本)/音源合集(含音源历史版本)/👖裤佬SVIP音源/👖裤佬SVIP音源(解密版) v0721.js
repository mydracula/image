/*!
 * @name 👖裤佬SVIP音源(解密版)
 * @version 0721
 * @author TZB679去混淆，疑似二改全豆要
 */
/* obfuscated build(strong): 1989-06-4 06:06:06 */

const na = 21600000;
const c = 500;
const d = /^https?:\/\//i;
const za = "https://music-api.gdstudio.xyz/api.php?use_xbridge3=true&loader_name=forest&need_sec_link=1&sec_link_scene=im&theme=light";
const La = "https://music-dl.sayqz.com/api/";
const Ma = "https://lxmusicapi.onrender.com";
const h = "share-v3";
const Na = "https://lc.guoyue2010.top/api/music";
const e = "https://oiapi.net/api/QQ_Music";
const f = "oiapi-ef6133b7-ac2f-dc7d-878c-d3e207a82575";
const g = "https://oiapi.net/api/Music_163";
const i = "https://oiapi.net/api/Kuwo";
const j = "https://api.xcvts.cn/api/music/migu";
const k = {
  tx: "http://175.27.166.236/kgqq/qq.php?type=mp3&id={id}&level={level}",
  wy: "http://175.27.166.236/wy/wy.php?type=mp3&id={id}&level={level}",
  kw: "https://musicapi.haitangw.net/music/kw.php?type=mp3&id={id}&level={level}",
  kg: "https://music.haitangw.cc/kgqq/kg.php?type=mp3&id={id}&level={level}",
  mg: "https://music.haitangw.cc/musicapi/mg.php?type=mp3&id={id}&level={level}"
};
const l = {
  tx: "https://music.nxinxz.com/kgqq/tx.php?id={id}&level={level}&type=mp3",
  wy: "http://music.nxinxz.com/wy.php?id={id}&level={level}&type=mp3",
  kw: "http://music.nxinxz.com/kw.php?id={id}&level={level}&type=mp3",
  kg: "https://music.nxinxz.com/kgqq/kg.php?id={id}&level={level}&type=mp3",
  mg: "http://music.nxinxz.com/mg.php?id={id}&level={level}&type=mp3"
};
const m = "qsvip";
const a = "汽水VIP";
const n = "https://api.vsaa.cn/api/music.qishui.vip";
const o = "http://api.vsaa.cn/api/music.qishui.vip";
const b = "https://proxy.qishui.vsaa.cn/qishui/proxy";
const p = {
  wy: ["24bit", "flac", "320k", "192k", "128k"],
  tx: ["24bit", "flac", "320k", "192k", "128k"],
  kw: ["24bit", "flac", "320k", "192k", "128k"],
  kg: ["24bit", "flac", "320k", "192k", "128k"],
  mg: ["24bit", "flac", "320k", "192k", "128k"]
};
const q = {
  wy: "netease",
  tx: "tencent",
  kw: "kuwo",
  kg: "kugou",
  mg: "migu"
};
const r = {
  "128k": "128",
  "192k": "192",
  "320k": "320",
  flac: "740",
  flac24bit: "999",
  "24bit": "999"
};
const s = {
  wy: "netease",
  tx: "qq",
  kw: "kuwo"
};
const t = {
  "128k": 7,
  "320k": 5,
  flac: 4,
  hires: 3,
  atmos: 2,
  master: 1,
  "24bit": 1
};
const u = {
  flac: 1,
  "320k": 5,
  "128k": 7,
  "24bit": 1
};
const v = new Set(["24bit", "flac", "flac24bit", "hires", "master", "atmos"]);
const w = new Set(["24bit", "flac", "flac24bit", "hires", "master", "atmos"]);
const x = new Map();
const {
  EVENT_NAMES: y,
  request: z,
  on: A,
  send: B,
  env: C,
  version: D
} = globalThis.lx;
function E() {}
function F(e, a = {
  method: "GET"
}) {
  return new Promise((f, b) => {
    z(e, {
      timeout: 2000,
      ...a
    }, (c, a) => {
      if (c) {
        return b(new Error("请求失败: " + c.message));
      }
      let d = a?.body;
      if (typeof d === "string") {
        const b = d.trim();
        if (b.startsWith("{") || b.startsWith("[") || b.startsWith("\"")) {
          try {
            d = JSON.parse(b);
          } catch (b) {}
        }
      }
      f({
        statusCode: a?.statusCode ?? 0,
        headers: a?.headers || {},
        body: d
      });
    });
  });
}
async function G(g, h = {}) {
  const a = Object.keys(h).filter(b => h[b] !== undefined && h[b] !== null).map(b => encodeURIComponent(b) + "=" + encodeURIComponent(h[b])).join("&");
  const b = g.includes("?") ? "&" : "?";
  const c = "" + g + (a ? b + a : "");
  const d = await F(c, {
    method: "GET",
    timeout: 2000
  });
  if (d.statusCode >= 400) {
    throw new Error("HTTP " + d.statusCode);
  }
  return d.body;
}
function H(c = {}) {
  const a = Object.keys(c).filter(a => c[a] !== undefined && c[a] !== null).map(a => encodeURIComponent(String(a)) + "=" + encodeURIComponent(String(c[a])));
  if (a.length) {
    return "?" + a.join("&");
  } else {
    return "";
  }
}
async function I(f, g = {}, b = 5000) {
  const a = f === n ? [n, o] : [f];
  let c = null;
  for (const e of a) {
    try {
      const c = "" + e + H(g);
      const a = await F(c, {
        method: "GET",
        timeout: b
      });
      if (a.statusCode >= 400) {
        throw new Error("HTTP " + a.statusCode);
      }
      return a.body;
    } catch (b) {
      c = b;
    }
  }
  throw c || new Error("汽水VIP请求失败");
}
async function J(e, a = {}, b = 5000) {
  const c = await F(e, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: a,
    timeout: b
  });
  if (c.statusCode >= 400) {
    throw new Error("HTTP " + c.statusCode);
  }
  return c.body;
}
function K(b) {
  return (b?.id || b?.songmid || b?.songId || b?.hash || b?.rid || b?.mid || b?.strMediaMid || b?.mediaId || "").toString();
}
function L(b) {
  switch (String(b || "").toLowerCase()) {
    case "128k":
      return "low";
    case "320k":
      return "standard";
    case "flac":
      return "lossless";
    case "flac24bit":
      return "hi_res";
    default:
      return "standard";
  }
}
function M(c) {
  const a = c?.id || c?.vid ? String(c.id || c.vid) : "";
  return {
    id: a,
    songmid: a,
    hash: a,
    name: c?.name ? String(c.name) : "未知歌曲",
    singer: c?.artists ? String(c.artists) : "未知歌手",
    albumName: c?.album ? String(c.album) : "",
    duration: c?.duration ? Math.floor(Number(c.duration) / 1000) : 0,
    pic: c?.cover || c?.pic ? String(c.cover || c.pic) : "",
    _raw: c || {}
  };
}
function N(c) {
  const a = c?.data;
  if (Array.isArray(a)) {
    return a[0] || null;
  }
  if (a && typeof a === "object" && a[0]) {
    return a[0];
  }
  return null;
}
async function O(g, a = 1, b = 30) {
  if (!g) {
    return {
      isEnd: true,
      list: []
    };
  }
  const c = await I(n, {
    act: "search",
    keywords: g,
    page: a,
    pagesize: b,
    type: "music"
  }, 15000);
  const d = Array.isArray(c?.data?.lists) ? c.data.lists : [];
  const e = c?.data?.total ? Number(c.data.total) : d.length;
  return {
    isEnd: d.length < b,
    list: d.map(M),
    total: e
  };
}
async function P(f, a) {
  const g = K(f);
  if (!g) {
    throw new Error("汽水VIP缺少歌曲ID");
  }
  const c = await I(n, {
    act: "song",
    id: g,
    quality: L(a)
  }, 20000);
  const d = N(c);
  if (!d?.url) {
    throw new Error("汽水VIP未返回可用URL");
  }
  if (d.ekey) {
    const c = await J(b, {
      url: d.url,
      key: d.ekey,
      filename: d.name || "KMusic",
      ext: d.codec_type ? String(d.codec_type) : "aac"
    }, 60000);
    if (Number(c?.code) === 200 && c?.url) {
      return String(c.url);
    }
    throw new Error("汽水VIP代理解密失败");
  }
  return String(d.url);
}
async function Q(e) {
  const a = K(e);
  if (!a) {
    return {
      lyric: ""
    };
  }
  const b = await I(n, {
    act: "song",
    id: a
  }, 15000);
  const c = N(b);
  return {
    lyric: c?.lyric ? String(c.lyric) : ""
  };
}
async function R(c, e = {}) {
  if (c === "musicSearch" || c === "search") {
    const b = e?.keyword ? String(e.keyword) : "";
    const a = e?.page ? Number(e.page) : 1;
    const c = e?.limit ? Number(e.limit) : 30;
    return O(b, a, c);
  }
  if (c === "musicUrl") {
    if (!e?.musicInfo) {
      throw new Error("请求参数不完整");
    }
    const b = await P(e.musicInfo, e.type);
    return fa(b, "汽水VIP");
  }
  if (c === "lyric") {
    return Q(e?.musicInfo || {});
  }
  throw new Error("action not support");
}
function S(g, a) {
  if (g === "24bit") {
    return "24bit";
  }
  const b = Array.isArray(a) ? a : ["128k"];
  const c = String(g || "128k").toLowerCase();
  if (b.includes(c)) {
    return c;
  }
  const h = ["flac24bit", "flac", "320k", "192k", "128k"];
  let e = h.indexOf(c);
  if (e < 0) {
    e = h.length - 1;
  }
  for (let c = e; c < h.length; c++) {
    if (b.includes(h[c])) {
      return h[c];
    }
  }
  for (let c = h.length - 1; c >= 0; c--) {
    if (b.includes(h[c])) {
      return h[c];
    }
  }
  return b[0] || "128k";
}
function T(b) {
  if (!b) {
    return "";
  }
  return String(b).replace(/\(\s*Live\s*\)/gi, "").replace(/\([^)]*\)/g, "").replace(/\s+/g, "").replace(/[^\w\u4e00-\u9fa5]/g, "").trim().toLowerCase();
}
function U(f) {
  const g = [];
  const b = f?.name || "";
  const c = f?.albumName || f?.album || "";
  const d = f?.singer || "";
  if (b && c) {
    const d = T(b + c);
    if (d) {
      g.push({
        keyword: d,
        strict: true
      });
    }
  }
  if (b && d) {
    const c = T(b + d);
    if (c) {
      g.push({
        keyword: c,
        strict: true
      });
    }
  }
  if (b) {
    const c = T(b);
    if (c) {
      g.push({
        keyword: c,
        strict: false
      });
    }
  }
  return g;
}
function V(e, a) {
  const b = T(e);
  const c = T(a);
  if (!b || !c) {
    return true;
  }
  return b.includes(c) || c.includes(b);
}
function W(f, a) {
  const b = f?.song || f?.data?.song || "";
  const c = f?.singer || f?.data?.singer || "";
  const d = f?.album || f?.data?.album || "";
  if (!V(b, a?.name || "")) {
    return false;
  }
  if (a?.singer && c && !V(c, a.singer)) {
    return false;
  }
  if ((a?.albumName || a?.album) && d && !V(d, a.albumName || a.album)) {
    return false;
  }
  return true;
}
function X(c, a) {
  if (!V(c?.title || "", a?.name || "")) {
    return false;
  }
  if (a?.singer && c?.artist && !V(c.artist, a.singer)) {
    return false;
  }
  if ((a?.albumName || a?.album) && c?.album && !V(c.album, a.albumName || a.album)) {
    return false;
  }
  return true;
}
function Y(d) {
  if (!d) {
    return null;
  }
  const a = {};
  const b = String(d).split("\n");
  for (const c of b) {
    if (c.includes("歌名：")) {
      a.song = c.replace("歌名：", "").trim();
    }
    if (c.includes("歌手：")) {
      a.singer = c.replace("歌手：", "").trim();
    }
    if (c.includes("专辑：")) {
      a.album = c.replace("专辑：", "").trim();
    }
  }
  if (a.song) {
    return a;
  } else {
    return null;
  }
}
function Z(b) {
  return b?.hash ?? b?.songmid ?? b?.id ?? null;
}
function $(d) {
  const a = d?.meta?.qq?.mid || d?.meta?.mid || d?.songmid || (typeof d?.id === "string" && !/^\d+$/.test(d.id) ? d.id : null);
  if (a) {
    return {
      type: "mid",
      value: a
    };
  }
  const b = d?.meta?.qq?.songid || d?.meta?.songid || (typeof d?.id === "number" ? d.id : typeof d?.id === "string" && /^\d+$/.test(d.id) ? Number(d.id) : null);
  if (b) {
    return {
      type: "songid",
      value: b
    };
  }
  return null;
}
function _(c) {
  const a = String(c || "128k").toLowerCase();
  if (a === "flac" || a === "flac24bit" || a === "hires" || a === "master" || a === "atmos") {
    return "lossless";
  }
  if (a === "320k" || a === "192k") {
    return "exhigh";
  }
  return "standard";
}
function aa(c, d) {
  if (c === "kg") {
    return d?.hash || d?.songmid || d?.id || d?.songId || d?.rid || null;
  }
  if (c === "tx") {
    const b = $(d);
    if (b?.value) {
      return b.value;
    }
  }
  return d?.songmid || d?.id || d?.songId || d?.rid || d?.hash || null;
}
function ba(i, a, b, c, d) {
  const e = c[i];
  if (!e) {
    throw new Error(d + "不支持该平台");
  }
  const f = aa(i, b);
  if (!f) {
    throw new Error(d + "缺少songId");
  }
  const g = _(a);
  return e.replace("{id}", encodeURIComponent(String(f))).replace("{level}", encodeURIComponent(g));
}
function ca(g, a, b = "") {
  const c = a?.name || "";
  const d = a?.singer || "";
  const e = a?.albumName || a?.album || "";
  return g + "_" + c + "_" + d + "_" + e + "_" + b;
}
function da(c) {
  const a = x.get(c);
  if (!a) {
    return null;
  }
  if (Date.now() - a.timestamp >= na) {
    x.delete(c);
    return null;
  }
  return a.url;
}
function ea(d, a) {
  x.set(d, {
    url: a,
    timestamp: Date.now()
  });
  if (x.size > c) {
    const b = x.keys().next().value;
    if (b !== undefined) {
      x.delete(b);
    }
  }
}
function fa(c, a) {
  if (!c || typeof c !== "string") {
    throw new Error(a + " 返回空URL");
  }
  if (!d.test(c.trim())) {
    throw new Error(a + " 返回不安全URL");
  }
  return c;
}
function ga(c) {
  if (!c) {
    return false;
  }
  const a = String(c).toLowerCase();
  if (/\.flac(?:$|[?#])/.test(a) || /\bquflac\b/.test(a)) {
    return false;
  }
  if (/\.mp3(?:$|[?#])/.test(a)) {
    return true;
  }
  if (/\bqu(?:128|192|320)\b/.test(a)) {
    return true;
  }
  return false;
}
function ha(c) {
  if (!c) {
    return false;
  }
  const a = String(c).toLowerCase();
  if (/\.flac(?:$|[?#])/.test(a) || /\bquflac\b/.test(a)) {
    return false;
  }
  if (/\bqu320\b/.test(a) || /(?:[?&]|\b)br=320(?:[&#]|$)/.test(a) || /(?:[?&]|\b)level=exhigh(?:[&#]|$)/.test(a)) {
    return false;
  }
  if (/\bqu(?:128|192)\b/.test(a)) {
    return true;
  }
  if (/(?:[?&]|\b)br=(?:96|128|192)(?:[&#]|$)/.test(a)) {
    return true;
  }
  if (/(?:[?&]|\b)level=standard(?:[&#]|$)/.test(a)) {
    return true;
  }
  return false;
}
function ia() {
  return "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1";
}
async function ja(f, a, b, c) {
  const d = q[f];
  if (!d) {
    throw new Error("星海主API不支持该平台");
  }
  const e = a ?? Z(c);
  if (!e) {
    throw new Error("缺少songId");
  }
  const g = S(b, ["128k", "192k", "320k", "flac", "flac24bit"]);
  const h = r[g];
  if (!h) {
    throw new Error("星海主API音质映射失败");
  }
  const i = za + "&types=url&source=" + d + "&id=" + encodeURIComponent(e) + "&br=" + h;
  const j = await F(i, {
    method: "GET",
    headers: {
      "User-Agent": "LX-Music-Mobile",
      Accept: "application/json"
    }
  });
  const k = j.body;
  if (!k || typeof k !== "object" || !k.url) {
    throw new Error(k?.msg || "星海主API未返回可用URL");
  }
  return k.url;
}
async function ka(g, a, b, c) {
  const d = s[g];
  if (!d) {
    throw new Error("星海备API不支持该平台");
  }
  const e = a ?? Z(c);
  if (!e) {
    throw new Error("缺少songId");
  }
  const f = S(b, ["128k", "192k", "320k", "flac", "flac24bit"]);
  return La + "?source=" + encodeURIComponent(d) + "&id=" + encodeURIComponent(e) + "&type=url&br=" + encodeURIComponent(f);
}
async function la(i, a, b, c) {
  const d = c?.hash ?? c?.songmid;
  if (!d) {
    throw new Error("Huibq缺少hash/songmid");
  }
  const e = S(b, ["320k", "128k"]);
  const f = Ma + "/url/" + i + "/" + encodeURIComponent(d) + "/" + encodeURIComponent(e);
  const g = await F(f, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      "User-Agent": ia(),
      "X-Request-Key": h
    }
  });
  const j = g.body;
  if (!j || typeof j !== "object" || Number.isNaN(Number(j.code))) {
    throw new Error("Huibq返回无效");
  }
  switch (Number(j.code)) {
    case 0:
      if (!j.url) {
        throw new Error("Huibq返回空URL");
      }
      return j.url;
    case 1:
      throw new Error("Huibq block ip");
    case 2:
      throw new Error("Huibq get music url failed");
    case 4:
      throw new Error("Huibq internal server error");
    case 5:
      throw new Error("Huibq too many requests");
    case 6:
      throw new Error("Huibq param error");
    default:
      throw new Error(j.msg || "Huibq unknown error");
  }
}
async function ma(j, a, b, c) {
  const d = c?.hash ?? c?.songmid;
  if (!d) {
    throw new Error("聆川缺少hash/songmid");
  }
  const e = S(b, ["320k", "128k"]);
  const f = Na + "/url?source=" + encodeURIComponent(j) + "&songId=" + encodeURIComponent(d) + "&quality=" + encodeURIComponent(e);
  const g = await F(f, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      "User-Agent": ia()
    },
    follow_max: 5
  });
  const h = g.body;
  if (!h || typeof h !== "object" || Number.isNaN(Number(h.code))) {
    throw new Error("聆川返回无效");
  }
  switch (Number(h.code)) {
    case 200:
      if (!h.url) {
        throw new Error("聆川返回空URL");
      }
      return h.url;
    case 403:
      throw new Error("聆川403 forbidden");
    case 429:
      throw new Error("聆川429 rate limit");
    case 500:
      throw new Error("聆川500 " + (h.message || "server error"));
    default:
      throw new Error(h.message || "聆川未知错误");
  }
}
function oa(c) {
  if (c?.music) {
    return c.music;
  }
  if (c?.url) {
    return c.url;
  }
  if (c?.message) {
    const a = String(c.message).match(/音频链接[：:](.+?)(?:\n|$)/);
    if (a && a[1]) {
      return a[1].trim();
    }
  }
  throw new Error("溯音QQ未找到音频链接");
}
function pa(c) {
  const a = String(c || "128k").toLowerCase();
  if (a === "flac24bit") {
    return "hires";
  }
  if (a === "192k") {
    return "320k";
  }
  if (t[a]) {
    return a;
  }
  return "128k";
}
async function qa(h, a) {
  const i = $(h);
  if (!i) {
    throw new Error("溯音QQ缺少songmid/id");
  }
  const b = pa(a);
  const d = t[b] || t["128k"];
  const c = [d, 4, 5, 7].filter((e, a, b) => b.indexOf(e) === a && e >= d).sort((c, a) => c - a);
  let j = null;
  for (const g of c) {
    try {
      const c = {
        key: f,
        type: "json",
        br: g,
        n: 1
      };
      if (i.type === "mid") {
        c.mid = i.value;
      } else {
        c.songid = i.value;
      }
      const a = await G(e, c);
      return oa(a);
    } catch (b) {
      j = b;
    }
  }
  throw new Error("溯音QQ全部音质尝试失败: " + (j?.message || "unknown"));
}
async function ra(d) {
  const a = d?.songmid || d?.id;
  if (!a) {
    throw new Error("溯音163缺少songmid/id");
  }
  const b = await G(g, {
    id: a
  });
  if (b?.code === 0 && b?.data) {
    const c = Array.isArray(b.data) ? b.data[0] : b.data;
    if (c?.url) {
      return c.url;
    }
  }
  throw new Error("溯音163获取失败");
}
async function sa(e, a, b = null) {
  const c = await G(i, {
    msg: e,
    n: 1,
    br: a
  });
  if (c?.data?.url) {
    if (b && !W(c, b)) {
      throw new Error("溯音酷我歌曲信息不匹配");
    }
    return c.data.url;
  }
  if (c?.message) {
    const d = String(c.message).match(/音乐链接[：:](\S+)/);
    if (d && d[1]) {
      if (b) {
        const d = Y(c.message);
        if (d && !W(d, b)) {
          throw new Error("溯音酷我歌曲信息不匹配");
        }
      }
      return d[1];
    }
  }
  throw new Error("溯音酷我未找到链接");
}
async function ta(i, a) {
  if (!i?.name) {
    throw new Error("溯音酷我需要歌曲名");
  }
  const j = ca("kw", i, a);
  const b = da(j);
  if (b) {
    return b;
  }
  const c = S(a, ["flac", "320k", "128k"]);
  const e = u[c] || 1;
  const f = U(i);
  let d = null;
  for (const c of f) {
    try {
      const a = await sa(c.keyword, e, c.strict ? i : null);
      if (a) {
        ea(j, a);
        return a;
      }
    } catch (b) {
      d = b;
    }
  }
  throw new Error("溯音酷我失败: " + (d?.message || "unknown"));
}
async function ua(f) {
  if (!f?.name) {
    throw new Error("溯音咪咕需要歌曲名");
  }
  const a = ca("mg", f);
  const b = da(a);
  if (b) {
    return b;
  }
  const g = U(f);
  let c = null;
  for (const b of g) {
    try {
      const c = await G(j, {
        gm: b.keyword,
        n: 1,
        num: 1,
        type: "json"
      });
      if (c?.code === 200 && c?.music_url) {
        if (b.strict && !X(c, f)) {
          throw new Error("溯音咪咕歌曲信息不匹配");
        }
        ea(a, c.music_url);
        return c.music_url;
      }
    } catch (b) {
      c = b;
    }
  }
  throw new Error("溯音咪咕失败: " + (c?.message || "unknown"));
}
async function va(e, a, b, c) {
  switch (e) {
    case "tx":
      return qa(c, b);
    case "wy":
      return ra(c);
    case "kw":
      return ta(c, b);
    case "mg":
      return ua(c);
    default:
      throw new Error("溯音不支持该平台");
  }
}
async function wa(e, a, b, c) {
  return ba(e, b, c, k, "长青SVIP");
}
async function xa(e, a, b, c) {
  return ba(e, b, c, l, "念心SVIP");
}
const ya = {
  xinghai: {
    name: "星海主",
    fn: ja
  },
  xinghaiBackup: {
    name: "星海备",
    fn: ka
  },
  huibq: {
    name: "Huibq",
    fn: la
  },
  lingchuan: {
    name: "聆川",
    fn: ma
  },
  suyinQQ: {
    name: "溯音QQ",
    fn: (e, a, b, c) => va("tx", a, b, c)
  },
  suyin163: {
    name: "溯音163",
    fn: (e, a, b, c) => va("wy", a, b, c)
  },
  suyinSearch: {
    name: "溯音搜索",
    fn: (e, a, b, c) => va("kw", a, b, c)
  },
  suyinMigu: {
    name: "溯音咪咕",
    fn: (e, a, b, c) => va("mg", a, b, c)
  },
  changqingVip: {
    name: "长青SVIP",
    fn: wa
  },
  nianxinVip: {
    name: "念心SVIP",
    fn: xa
  }
};
function Aa(c) {
  var a = [];
  if (ya.xinghai) {
    a.push(ya.xinghai);
  }
  if (ya.huibq) {
    a.push(ya.huibq);
  }
  if (c === "wy" && ya.suyin163) {
    a.push(ya.suyin163);
  }
  if (c === "tx" && ya.suyinQQ) {
    a.push(ya.suyinQQ);
  }
  if (c === "kw" && ya.suyinSearch) {
    a.push(ya.suyinSearch);
  }
  if (c === "mg" && ya.suyinMigu) {
    a.push(ya.suyinMigu);
  }
  if (ya.lingchuan) {
    a.push(ya.lingchuan);
  }
  if (ya.changqingVip) {
    a.push(ya.changqingVip);
  }
  if (ya.nianxinVip) {
    a.push(ya.nianxinVip);
  }
  return a;
}
async function Ba(j, a, b) {
  if (!j || typeof j !== "string" || !p[j]) {
    throw new Error("不支持的平台");
  }
  if (!a || typeof a !== "object") {
    throw new Error("缺少歌曲信息");
  }
  const c = b || "128k";
  const k = S(c, p[j]);
  const e = Z(a);
  const d = v.has(c.toLowerCase());
  const f = Aa(j, d, k);
  if (!f.length) {
    throw new Error("未找到可用fallback链");
  }
  const g = [];
  try {
    const b = await Promise.any(f.slice(0, 3).map(async b => {
      const c = await b.fn(j, e, k, a);
      return fa(c, b.name);
    }));
    if (b) {
      return b;
    }
  } catch (b) {
    if (b.errors) {
      b.errors.forEach(b => g.push(b.message));
    }
  }
  for (const h of f.slice(3)) {
    try {
      const b = await h.fn(j, e, k, a);
      return fa(b, h.name);
    } catch (b) {
      g.push(h.name + ": " + b.message);
      continue;
    }
  }
  throw new Error("所有源均失败: " + g.join("; "));
}
const Ca = {};
const Da = {
  wy: "网易云音乐",
  tx: "QQ音乐",
  kw: "酷我音乐",
  kg: "酷狗音乐",
  mg: "咪咕音乐"
};
Object.keys(p).forEach(b => {
  Ca[b] = {
    name: Da[b],
    type: "music",
    actions: ["musicUrl"],
    qualitys: p[b]
  };
});
Ca[m] = {
  name: a,
  type: "music",
  actions: ["musicSearch", "musicUrl", "lyric"],
  qualitys: ["128k", "320k", "flac", "flac24bit"]
};
A(y.request, ({
  action: d,
  source: a,
  info: b
}) => {
  if (a === m) {
    return R(d, b);
  }
  if (d !== "musicUrl") {
    return Promise.reject(new Error("action not support"));
  }
  if (!b?.musicInfo) {
    return Promise.reject(new Error("请求参数不完整"));
  }
  return Ba(a, b.musicInfo, b.type || "128k").then(b => Promise.resolve(b)).catch(b => Promise.reject(b));
});
B(y.inited, {
  openDevTools: false,
  sources: Ca
});
E("初始化完成，聚合音源已就绪");