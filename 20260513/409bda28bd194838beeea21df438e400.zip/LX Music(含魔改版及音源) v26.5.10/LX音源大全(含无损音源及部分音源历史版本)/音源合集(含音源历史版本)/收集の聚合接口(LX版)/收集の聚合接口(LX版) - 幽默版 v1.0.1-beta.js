/*!
 * @name 收集の聚合接口(LX版) - 暖心特供版
 * @id netapis_free
 * @version 1.0.1-beta
 * @description 聚合接口-来源于网络 整理:QZ | 新增：网络请求失败时会安慰你
 * @author QZ & TZB679
 * @support tx wy kw
 * @expire 2099-12-31 23:59:59
 */

const DEV_ENABLE = false
const UPDATE_ENABLE = false                                    // 本接口无更新检查
const SUPPORT_SOURCE = ['tx', 'wy', 'kw']
const QUALITY_MAP = {                                          // 落雪音质 -> 自身音质
  tx: { '128k': '128k', '320k': '320k', 'flac': 'flac', 'flac24bit': 'flac', 'hires': 'flac', 'atmos': 'flac', 'master': 'flac' },
  wy: { '128k': 'standard', '320k': 'exhigh', 'flac': 'lossless', 'flac24bit': 'lossless', 'hires': 'lossless', 'atmos': 'lossless', 'master': 'lossless' },
  kw: { '128k': '128k', '320k': '320k', 'flac': 'lossless', 'flac24bit': 'lossless', 'hires': 'lossless', 'atmos': 'lossless', 'master': 'lossless' }
}

const { EVENT_NAMES, request, on, send, env, version } = globalThis.lx

// --- 🌈 暖心安慰计数器 ---
let comfortCounter = 0
let lastComfortTimes = []

// --- 🌈 幽默安慰函数 ---
function comfortUser(errorContext = "", errorDetails = "") {
  comfortCounter++
  
  const comfortMessages = [
    "🎵 别难过，可能是服务器去摸鱼了，要不换首歌试试？",
    "🍵 网络开小差了，喝口水再听？我等你~",
    "🐱 请求失败，但至少你还有我（和这行安慰文字）",
    "💡 要不...试试重启路由器？或者对电脑唱首歌？",
    "🌚 不是你的问题，是这个世界（的网络）太不稳定了",
    "🎧 听歌不着急，先深呼吸，我再帮你连一次",
    "📡 信号飞走了，但马上飞回来，再等一下下",
    "🤖 我是聚合接口，虽然请求失败了，但我依然爱你",
    "🍻 这一定是Bug，不是你的错，干杯🍻",
    "😭 请求失败了...但没关系，我已经帮你记录了，下次一定行！",
    "🌟 失败是成功之母，这次失败就当给成功当妈妈了",
    "🎈 别灰心，气球飞走了还能再买一个，歌也是",
    "🦄 网络独角兽今天请假了，明天一定上班",
    "☕ 先喝杯咖啡，我等会儿再帮你连一次",
    "📞 要不...打个电话给服务器问问它为什么罢工？",
    "🔧 正在修复中...（其实并没有，但这么说你会好受点）",
    "💝 送你一颗爱心，别因为网络问题影响心情~",
    "🎪 马戏团的小丑都比你遇到的错误少，但没关系，我陪你",
    "🌈 风雨过后是彩虹，网络失败后是我在安慰你",
    "🍪 吃块饼干冷静一下，我已经在想办法了",
    "🎤 唱首歌给自己听吧，我保证比我的请求成功率高",
    "🌙 夜深了？那就当服务器也去睡觉了吧，明天再来"
  ]
  
  // 随机选一条安慰消息
  const randomMessage = comfortMessages[Math.floor(Math.random() * comfortMessages.length)]
  
  // 清理10秒前的记录
  const now = Date.now()
  lastComfortTimes = lastComfortTimes.filter(t => now - t < 10000)
  lastComfortTimes.push(now)
  
  // 构建安慰日志
  let comfortLog = `💚 [安慰 #${comfortCounter}] ${randomMessage}`
  if (errorContext) {
    comfortLog += ` (上下文: ${errorContext})`
  }
  if (errorDetails && errorDetails.length < 80) {
    comfortLog += ` [错误: ${errorDetails}]`
  }
  
  console.log(comfortLog)
  
  // 如果10秒内连续失败超过3次，给个特别安慰
  if (lastComfortTimes.length > 3) {
    console.log("💔 [特别安慰] 哎呀，连续失败好多次了...建议你检查一下网络，或者去骂一下运营商📞")
  }
  
  return randomMessage
}

/* ---------- 工具 ---------- */
const httpFetch = (url, options = { method: 'GET' }) => {
  return new Promise((resolve, reject) => {
    request(url, options, (err, resp) => {
      if (err) {
        // 🌈 网络请求失败时安慰用户
        comfortUser("httpFetch", err.message)
        return reject(err)
      }
      resolve(resp)
    })
  })
}

/* ---------- 核心 ---------- */
const getMusicUrl = async (source, musicInfo, quality) => {
  const songId = musicInfo.hash ?? musicInfo.songmid
  if (!songId) {
    comfortUser("getMusicUrl", "缺少歌曲ID")
    throw new Error('缺少歌曲ID，歌曲可能离家出走了')
  }
  
  const level = QUALITY_MAP[source][quality] || 'lossless'

  let url
  switch (source) {
    case 'tx':
      url = `https://cyapi.top/API/qq_music.php?apikey=1ffdf5733f5d538760e63d7e46ba17438d9f7b9dfc18c51be1109386fd74c3a1&type=json&mid=${songId}`
      break
    case 'wy':
      url = `https://api.cenguigui.cn/api/netease/music_v1.php?id=${songId}&type=json&level=${level}`
      break
    case 'kw':
      url = `https://kw-api.cenguigui.cn?id=${songId}&type=song&format=json&level=${level}`
      break
    default:
      comfortUser("getMusicUrl", `不支持的源: ${source}`)
      throw new Error('不支持的源，要不去问问作者？')
  }

  console.log(`🔍 正在从 ${source} 获取歌曲: ${musicInfo.name || songId} (音质: ${quality || '默认'})`)

  let resp
  try {
    resp = await httpFetch(url, {
      method: 'GET',
      headers: { 'User-Agent': env ? `lx-music-${env}/${version}` : `lx-music-request/${version}` }
    })
  } catch (err) {
    comfortUser(`getMusicUrl ${source}`, err.message)
    throw new Error(`网络请求失败: ${err.message}`)
  }

  const { body, statusCode } = resp
  if (statusCode && statusCode >= 400) {
    comfortUser(`getMusicUrl ${source}`, `HTTP ${statusCode}`)
    throw new Error(`HTTP ${statusCode}，服务器可能去摸鱼了`)
  }
  
  if (!body) {
    comfortUser(`getMusicUrl ${source}`, "空响应")
    throw new Error('空响应，服务器可能在发呆')
  }

  // 统一提取 url
  let realUrl
  try {
    if (source === 'tx') {
      realUrl = body.url
      // 如果直接返回的就是字符串
      if (typeof body === 'string') realUrl = body
    } else if (body.data) {
      realUrl = body.data.url
    } else if (typeof body === 'string' && body.startsWith('http')) {
      realUrl = body
    }
  } catch (e) {
    // 忽略解析错误
  }
  
  if (!realUrl) {
    comfortUser(`getMusicUrl ${source}`, "无法提取播放链接")
    // 输出部分响应内容帮助调试（但限制长度避免刷屏）
    const bodyStr = typeof body === 'string' ? body.substring(0, 200) : JSON.stringify(body || {}).substring(0, 200)
    console.log(`📦 响应内容预览: ${bodyStr}`)
    throw new Error('获取播放链接失败，接口可能改版了')
  }

  console.log(`✅ 成功获取播放链接: ${realUrl.substring(0, 80)}...`)
  return realUrl
}

/* ---------- 注册 ---------- */
const sources = {}
SUPPORT_SOURCE.forEach(s => {
  sources[s] = {
    name: s,
    type: 'music',
    actions: ['musicUrl'],
    qualitys: Object.keys(QUALITY_MAP[s])
  }
})

on(EVENT_NAMES.request, ({ action, source, info }) => {
  if (action !== 'musicUrl') {
    comfortUser("顶层请求", "不支持的操作")
    return Promise.reject('action not support，你是不是在搞事情？')
  }
  
  if (!info?.musicInfo) {
    comfortUser("顶层请求", "缺少musicInfo")
    return Promise.reject('请求参数不完整，可能你忘了传musicInfo')
  }
  
  return getMusicUrl(source, info.musicInfo, info.type)
    .then(url => {
      console.log(`🎉 ${source} 请求成功！`)
      return Promise.resolve(url)
    })
    .catch(err => {
      // 顶层错误也安慰一下
      const errMsg = typeof err === 'string' ? err : (err?.message || '未知错误')
      comfortUser("顶层请求处理", errMsg)
      return Promise.reject(errMsg)
    })
})

// 启动时输出暖心彩蛋
send(EVENT_NAMES.inited, {
  status: true,
  openDevTools: DEV_ENABLE,
  sources
})

console.log("%c🌈 收集の聚合接口 v1.0.1 暖心特供版已加载", "color: #00aa66; font-size: 14px")
console.log("%c💚 新增功能：网络请求失败时会安慰你！", "color: #ff6600; font-size: 12px")
console.log("%c🎵 支持的源: TX(QQ音乐) / WY(网易云) / KW(酷我)", "color: #888888; font-size: 12px")