const express = require('express')
const router = express.Router()
const request = require('request')
const fs = require('fs')
const userName = 'mydracula'
const formidable = require('formidable')
const repositoryName = 'image'
const token = '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'
const { v4: uuidv4 } = require('uuid')

router.get('/github', (req, res) => {
  res.send('看你吗看啊')
})

router.post('/github', (req, res, next) => {
  var form = new formidable.IncomingForm()
  form.parse(req, function (err, fields, files) {
    const name = files.file.originalFilename
    var sExtensionName = name.substring(name.lastIndexOf('.') + 1).toLowerCase()

    fs.readFile(files.file.filepath, (err, data) => {
      if (err) throw err
      const base = data.toString('base64')
      const uuid = uuidv4().replace(/-/g, '')
      const date = new Date()
      date.setMinutes(date.getMinutes() - date.getTimezoneOffset())
      const time = date.toJSON().replace(/[-T]/g, '').substr(0, 8)
      var headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1521.3 Safari/537.36',
        Authorization: `token ${token}`,
        'Content-Type': 'application/json'
      }
      var dataString = { accept: 'application/vnd.github.v3+jso', message: 'init', content: base }

      var options = {
        url: `https://api.github.com/repos/${userName}/${repositoryName}/contents/${time}/${uuid}/${uuid}.${sExtensionName}`,
        method: 'PUT',
        headers: headers,
        body: JSON.stringify(dataString)
      }

      request(options, function (error, response, body) {
        if (!error) {
          console.log('2', Date.now())
          res.json({ code: 200, msg: '请求成功', body, data: `https://cdn.jsdelivr.net/gh/${userName}/${repositoryName}/${time}/${uuid}/${uuid}.${sExtensionName}` })
        }
      })
    })
  })
})

module.exports = router
