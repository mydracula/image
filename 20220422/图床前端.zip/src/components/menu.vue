<template>
  <header>
    <a class="logo" href="#" title="图床">
      <img src="https://q1.qlogo.cn/g?b=qq&nk=2458578637&s=640" alt="logo" @click="open" />
    </a>
    <nav>
      <a href="#">Home</a>
      <a href="#">All</a>
      <a href="#">Help</a>
    </nav>
    <a class="setting" href="#" @click="open">
      <icon name="Setting" :size="20"></icon>
      <span>Setting</span>
    </a>
  </header>
</template>

<script setup lang="ts">
import { ElMessage } from 'element-plus'
const open = () => {
  ElMessage({
    message: 'Your mother is gone.',
    grouping: true,
    type: 'error'
  })
}
</script>

<style scoped>
@media screen and (max-width: 375px) {
  .setting {
    visibility: hidden;
  }
}
.el-icon {
  height: 33px;
  line-height: 33px;
  margin-right: 4px;
}
header {
  position: fixed;
  top: 0;
  right: 0;
  left: 0;
  z-index: 88;
  background: var(--bg-color);
  display: flex;
  padding: 10px var(--body-padding);
  align-items: center;
}

header .logo {
  display: flex;
  align-items: center;
}

header .logo img {
  height: 22px;
}

header a {
  color: #fff;
}

header nav > a {
  margin-left: 30px;
  text-transform: uppercase;
}

header .setting {
  margin-left: auto;
  display: flex;
  align-items: center;
  text-transform: uppercase;
}
</style>
