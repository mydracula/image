<template>
  <transition :name="transitionName">
    <div class="page-component-up" @click="backToTop" v-show="visible" :class="customName">
      <icon name="caretTop" :size="28"></icon>
    </div>
  </transition>
</template>

<script setup lang="ts">
type Props = {
  transitionName: string
  customName?: any
  visibilityHeight: number
  backPosition: number
}

const props = withDefaults(defineProps<Props>(), {
  transitionName: 'fade',
  backPosition: 0
})

const visible = ref<boolean>(false)
const interval = ref<any>(null)

function handleScroll() {
  visible.value = window.pageYOffset > props.visibilityHeight
}

function backToTop() {
  let distanceY = window.pageYOffset
  let i = 0
  interval.value = setInterval(() => {
    let next = Math.floor(easeInOutQuad(10 * i, distanceY, -distanceY, 200))
    if (next <= props.backPosition) {
      window.scrollTo(0, props.backPosition)
      clearInterval(interval.value)
    } else {
      window.scrollTo(0, next)
    }
    i++
  }, 17)
}

function easeInOutQuad(t: any, b: any, c: any, d: any) {
  if ((t /= d / 2) < 1) {
    return (c / 2) * t * t + b
  } else {
    return (-c / 2) * (--t * (t - 2) - 1) + b
  }
}

onMounted(() => {
  window.addEventListener('scroll', handleScroll)
})

onBeforeUnmount(() => {
  window.removeEventListener('scroll', handleScroll)
  if (interval) {
    clearInterval(interval)
  }
})
</script>

<style scoped>
.page-component-up {
  position: fixed;
  right: 24px;
  bottom: 24px;
  cursor: pointer;
  text-align: center;
  transition: 0.3s;
  box-shadow: 0 0 6px rgba(0, 0, 0, 0.12);
  z-index: 99;
}
.circle {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 56px;
  min-width: 56px;
  height: 56px;
  border-radius: 50%;
  color: #fff;
  background: #409eff;
}
</style>
